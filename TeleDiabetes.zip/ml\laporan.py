"""Tahap 3 - Ringkasan hasil pelatihan untuk halaman 'Model & data' di web."""
import numpy as np
from .preprocess import FITUR, laporan_data


def korelasi_teratas(df, pp, n=5):
    x = pp.imputasi(df[FITUR])
    c = x.corr().to_numpy()
    pasangan = []
    for i in range(len(FITUR)):
        for j in range(i + 1, len(FITUR)):
            pasangan.append((FITUR[i], FITUR[j], float(c[i, j])))
    return sorted(pasangan, key=lambda p: -abs(p[2]))[:n]


def pohon_ke_teks(node, nama_fitur, mean, std, indent=0, out=None):
    """Aturan pohon dalam satuan asli (bukan Z-Score)."""
    out = [] if out is None else out
    pad = "|   " * indent
    if node.daun:
        label = "DIABETES" if node.kelas == 1 else "tidak diabetes"
        out.append(f"{pad}=> {label}  [tidak={node.hitung[0]}, ya={node.hitung[1]}]")
        return out
    s = node.split
    nama = nama_fitur[s["fitur"]]
    batas = s["batas"] * std[nama] + mean[nama]
    out.append(f"{pad}{nama} <= {batas:.1f}  (Gini={node.split['g_induk']:.3f}, Gain={s['gain']:.3f})")
    pohon_ke_teks(node.kiri, nama_fitur, mean, std, indent + 1, out)
    out.append(f"{pad}{nama} > {batas:.1f}")
    pohon_ke_teks(node.kanan, nama_fitur, mean, std, indent + 1, out)
    return out


def bangun(df, latih, uji, pp, model, hasil_split, hasil_cv):
    return {
        "data": laporan_data(df),
        "n_latih": len(latih), "n_uji": len(uji),
        "split": hasil_split, "cv": hasil_cv,
        "korelasi": korelasi_teratas(df, pp),
        "importance": {k: float(v) for k, v in model["dt"].importance().items()},
        "svm_bobot": {n: float(w) for n, w in zip(FITUR, model["svm"].w)},
        "pohon": "\n".join(pohon_ke_teks(model["dt"].root, FITUR, pp.mean, pp.std)),
    }
