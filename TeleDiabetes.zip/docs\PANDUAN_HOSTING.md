# Panduan hosting (agar link bisa dibuka dosen)

Pilihan yang saya cek di web (Nov 2026; cek ulang syarat terbarunya sebelum mendaftar):
- **PythonAnywhere akun gratis**: mendukung aplikasi Flask/WSGI, alamat `namaanda.pythonanywhere.com`, tanpa kartu kredit. Akses internet keluar dibatasi dan CPU harian terbatas, tapi aplikasi ini tidak butuh internet keluar dan tidak melatih model saat berjalan, jadi cocok.
- Alternatif: Back4app (container dari GitHub), Google App Engine (kuota harian gratis), atau platform container lain. Hosting gratis kadang "tidur" saat sepi, jadi buka link-nya sehari sebelum batas waktu.

## Langkah di PythonAnywhere
1. Di komputer Anda: letakkan `diabetes.csv` di `data/`, jalankan `pip install -r requirements.txt` lalu `python train.py`. Pastikan `models/artefak.pkl` terbentuk. **Latih di komputer sendiri**, jangan di server gratis.
2. Daftar akun gratis di pythonanywhere.com.
3. Tab **Files**: unggah ZIP proyek lalu buka lewat tab **Consoles → Bash**: `unzip nama.zip`.
4. Di Bash: `mkvirtualenv --python=python3.12 env` (sesuaikan versi Python di akun Anda), lalu `pip install flask numpy pandas`.
5. Tab **Web → Add a new web app → Manual configuration** (pilih versi Python yang sama).
6. Isi **Source code** dan **Working directory** dengan folder proyek, **Virtualenv** dengan `/home/NAMAANDA/.virtualenvs/env`.
7. Buka file WSGI dan ganti isinya:
```python
import sys, os
path = "/home/NAMAANDA/diabetes-telemedicine"
if path not in sys.path:
    sys.path.insert(0, path)
os.environ["SECRET_KEY"] = "isi-acak-panjang-buatan-anda"
os.environ["DOKTER_PASSWORD"] = "password-dokter-yang-kuat"
from app import app as application
```
8. Klik **Reload**, lalu buka `https://NAMAANDA.pythonanywhere.com`.

## Daftar cek sebelum dikumpulkan
- Daftar akun pasien, kirim skrining, buka halaman hasil: perhitungan tampil.
- Masuk sebagai dokter (`dokter@demo.id` dengan password yang Anda atur di `DOKTER_PASSWORD`), balas konsultasi.
- Halaman Model dan data tampil dengan angka dari data asli.
- Ganti password dokter bawaan, dan jangan memakai `SECRET_KEY` bawaan.
