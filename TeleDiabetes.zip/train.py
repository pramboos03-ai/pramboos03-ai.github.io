"""Jalankan: python train.py [path_csv]   (default data/diabetes.csv)
Melatih Naive Bayes, Decision Tree, SVM; evaluasi split 80:20 dan 10-fold CV;
menyimpan semua hasil ke models/artefak.pkl (dipakai langsung oleh web, tanpa melatih ulang)."""
import os, pickle, sys
from ml.preprocess import muat_data, laporan_data, bagi_data, Praproses, FITUR
from ml.naive_bayes import GaussianNB
from ml.decision_tree import DecisionTree
from ml.svm import LinearSVM
from ml.metrics import evaluasi
from ml.cv import cross_validate
from ml.laporan import bangun

path = sys.argv[1] if len(sys.argv) > 1 else "data/diabetes.csv"
df = muat_data(path)
print("Dataset:", laporan_data(df))

MODEL = {
    "Naive Bayes": lambda: GaussianNB(FITUR),
    "Decision Tree": lambda: DecisionTree(FITUR, max_depth=4),
    "SVM (linear, bobot kelas)": lambda: LinearSVM(FITUR),
    "SVM (linear, tanpa bobot kelas)": lambda: LinearSVM(FITUR, bobot_kelas=False),
}

latih, uji = bagi_data(df)
pp = Praproses().fit(latih)
Xl, yl = pp.transform(latih)
Xu, yu = pp.transform(uji)

print("\n=== Split 80:20 ===")
terlatih, hasil_split, hasil_cv = {}, {}, {}
for nama, buat in MODEL.items():
    m = buat().fit(Xl, yl); terlatih[nama] = m
    e = evaluasi(yu, m.predict(Xu)); hasil_split[nama] = e
    print(f"{nama:32s} akurasi={e['akurasi']:.4f} precision={e['precision']:.4f} "
          f"recall={e['recall']:.4f} f1={e['f1']:.4f}  (TP={e['TP']} TN={e['TN']} FP={e['FP']} FN={e['FN']})")

print("\n=== 10-fold cross validation (rata-rata) ===")
for nama, buat in MODEL.items():
    r = cross_validate(df, buat, k=10); hasil_cv[nama] = r
    print(f"{nama:32s} akurasi={r['akurasi']:.4f} precision={r['precision']:.4f} "
          f"recall={r['recall']:.4f} f1={r['f1']:.4f}")

model = {"nb": terlatih["Naive Bayes"], "dt": terlatih["Decision Tree"],
         "svm": terlatih["SVM (linear, bobot kelas)"]}
artefak = {"pp": pp, **model, "laporan": bangun(df, latih, uji, pp, model, hasil_split, hasil_cv)}
os.makedirs("models", exist_ok=True)
with open("models/artefak.pkl", "wb") as f:
    pickle.dump(artefak, f)
print("\nTersimpan: models/artefak.pkl  -> jalankan: python app.py")
print("\nAturan Decision Tree:\n" + artefak["laporan"]["pohon"])
