"""Tahap 1 - Praproses data Pima Indians Diabetes (langkah demi langkah)."""
import numpy as np
import pandas as pd

FITUR = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
         "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"]
TARGET = "Outcome"
# Kolom yang nilai 0-nya sebenarnya data kosong (tidak mungkin 0 secara medis)
KOLOM_NOL_KOSONG = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]


def muat_data(path):
    df = pd.read_csv(path)
    return df[FITUR + [TARGET]].copy()


def laporan_data(df):
    """Ringkasan untuk halaman 'Dataset' di web."""
    return {
        "jumlah_data": int(len(df)),
        "kelas": {int(k): int(v) for k, v in df[TARGET].value_counts().items()},
        "nol_tak_wajar": {k: int((df[k] == 0).sum()) for k in KOLOM_NOL_KOSONG},
    }


def bagi_data(df, rasio_uji=0.2, seed=42):
    """Split stratified: proporsi kelas di data latih & uji dijaga sama."""
    rng = np.random.default_rng(seed)
    idx_uji = []
    for kelas in df[TARGET].unique():
        idx = df.index[df[TARGET] == kelas].to_numpy().copy()
        rng.shuffle(idx)
        idx_uji.extend(idx[: int(round(len(idx) * rasio_uji))])
    uji = df.loc[sorted(idx_uji)]
    latih = df.drop(index=uji.index)
    return latih.reset_index(drop=True), uji.reset_index(drop=True)


class Praproses:
    """Imputasi median + normalisasi Z-Score. Parameter dihitung HANYA dari data latih."""

    def fit(self, latih):
        x = latih[FITUR].copy()
        x[KOLOM_NOL_KOSONG] = x[KOLOM_NOL_KOSONG].replace(0, np.nan)
        self.median = x.median().to_dict()
        x = x.fillna(self.median)
        self.mean = x.mean().to_dict()
        self.std = x.std(ddof=0).to_dict()
        return self

    def imputasi(self, x):
        x = x.copy()
        x[KOLOM_NOL_KOSONG] = x[KOLOM_NOL_KOSONG].replace(0, np.nan)
        return x.fillna(self.median)

    def zscore(self, x):
        x = self.imputasi(x)
        return (x - pd.Series(self.mean)) / pd.Series(self.std)

    def transform(self, df):
        return self.zscore(df[FITUR]).to_numpy(), df[TARGET].to_numpy()
