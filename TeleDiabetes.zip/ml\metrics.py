"""Tahap 1 - Metrik evaluasi dengan angka TP/TN/FP/FN yang bisa ditampilkan di web."""

def confusion(y_true, y_pred, positif=1):
    tp = int(sum((t == positif) and (p == positif) for t, p in zip(y_true, y_pred)))
    tn = int(sum((t != positif) and (p != positif) for t, p in zip(y_true, y_pred)))
    fp = int(sum((t != positif) and (p == positif) for t, p in zip(y_true, y_pred)))
    fn = int(sum((t == positif) and (p != positif) for t, p in zip(y_true, y_pred)))
    return tp, tn, fp, fn


def _bagi(a, b):
    return a / b if b else 0.0


def evaluasi(y_true, y_pred):
    tp, tn, fp, fn = confusion(y_true, y_pred)
    precision = _bagi(tp, tp + fp)
    recall = _bagi(tp, tp + fn)
    return {
        "TP": tp, "TN": tn, "FP": fp, "FN": fn,
        "akurasi": _bagi(tp + tn, tp + tn + fp + fn),
        "precision": precision,
        "recall": recall,
        "f1": _bagi(2 * precision * recall, precision + recall),
        "rumus": {
            "akurasi": f"(TP+TN)/(TP+TN+FP+FN) = ({tp}+{tn})/({tp+tn+fp+fn})",
            "precision": f"TP/(TP+FP) = {tp}/({tp+fp})",
            "recall": f"TP/(TP+FN) = {tp}/({tp+fn})",
        },
    }
