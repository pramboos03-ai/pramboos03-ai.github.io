"""Tahap 2 - SVM linear buatan sendiri (Pegasos: sub-gradient descent pada hinge loss).
Skor keputusan f(x) = w.x + b bisa dipecah per fitur untuk ditampilkan di web."""
import numpy as np


class LinearSVM:
    def __init__(self, nama_fitur, lam=0.01, epoch=60, seed=42, bobot_kelas=True):
        self.nama_fitur, self.lam, self.epoch = nama_fitur, lam, epoch
        self.seed, self.bobot_kelas = seed, bobot_kelas

    def fit(self, X, y):
        rng = np.random.default_rng(self.seed)
        t = np.where(y == 1, 1.0, -1.0)
        Xa = np.hstack([X, np.ones((len(X), 1))])  # kolom 1 = bias
        w = np.zeros(Xa.shape[1])
        # bobot kelas agar kelas minoritas (diabetes) tidak diabaikan
        cw = {1: len(y) / (2 * max((y == 1).sum(), 1)), -1: len(y) / (2 * max((y == 0).sum(), 1))} \
            if self.bobot_kelas else {1: 1.0, -1: 1.0}
        k = 0
        for _ in range(self.epoch):
            for i in rng.permutation(len(Xa)):
                k += 1
                eta = 1.0 / (self.lam * k)
                if t[i] * (w @ Xa[i]) < 1:
                    w = (1 - eta * self.lam) * w + eta * cw[int(t[i])] * t[i] * Xa[i]
                else:
                    w = (1 - eta * self.lam) * w
        self.w, self.b = w[:-1], float(w[-1])
        return self

    def skor(self, X):
        return X @ self.w + self.b

    def predict(self, X):
        return (self.skor(X) > 0).astype(int)

    def jelaskan(self, x):
        kontribusi = [{"fitur": n, "z": float(x[j]), "bobot": float(self.w[j]),
                       "kontribusi": float(self.w[j] * x[j])}
                      for j, n in enumerate(self.nama_fitur)]
        total = float(sum(k["kontribusi"] for k in kontribusi) + self.b)
        return {"kontribusi": kontribusi, "bias": self.b, "skor": total,
                "rumus": "f(x) = (w1*x1 + w2*x2 + ... + w8*x8) + b ; f(x) > 0 -> diabetes",
                "hasil": int(total > 0)}
