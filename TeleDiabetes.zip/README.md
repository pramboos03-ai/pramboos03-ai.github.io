# Telemedicine Skrining Diabetes (Flask)

1. Unduh dataset Pima Indians Diabetes (`diabetes.csv`, 768 baris, kolom: Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age, Outcome) dari Kaggle atau UCI, simpan di `data/diabetes.csv`.
2. `pip install -r requirements.txt`
3. `python train.py` (melatih tiga model, evaluasi, menyimpan `models/artefak.pkl`)
4. `python app.py` lalu buka http://127.0.0.1:5000
5. Akun dokter bawaan: `dokter@demo.id` / `dokter123` (ganti lewat variabel `DOKTER_PASSWORD` atau `flask buat-dokter`). Pasien mendaftar sendiri.

Struktur: `ml/` (algoritma buatan sendiri), `app.py` (web), `templates/`, `static/`, `docs/` (UML, RapidMiner, hosting).
