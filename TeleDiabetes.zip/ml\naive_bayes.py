"""Tahap 1 - Gaussian Naive Bayes buatan sendiri, agar tiap langkah bisa ditampilkan di web."""
import math
import numpy as np

EPS = 1e-9


def pdf_normal(x, mean, std):
    std = max(std, EPS)
    return math.exp(-((x - mean) ** 2) / (2 * std ** 2)) / (math.sqrt(2 * math.pi) * std)


class GaussianNB:
    def __init__(self, nama_fitur):
        self.nama_fitur = nama_fitur

    def fit(self, X, y):
        self.kelas = sorted(set(int(v) for v in y))
        self.prior, self.mean, self.std = {}, {}, {}
        for c in self.kelas:
            Xc = X[y == c]
            self.prior[c] = len(Xc) / len(X)
            self.mean[c] = Xc.mean(axis=0)
            self.std[c] = Xc.std(axis=0, ddof=0)
        return self

    def _log_skor(self, x):
        skor = {}
        for c in self.kelas:
            s = math.log(self.prior[c])
            for j, v in enumerate(x):
                s += math.log(max(pdf_normal(v, self.mean[c][j], self.std[c][j]), 1e-300))
            skor[c] = s
        return skor

    def predict_proba(self, x):
        skor = self._log_skor(x)
        m = max(skor.values())
        eks = {c: math.exp(s - m) for c, s in skor.items()}
        total = sum(eks.values())
        return {c: e / total for c, e in eks.items()}

    def predict(self, X):
        return np.array([max(self.predict_proba(x).items(), key=lambda kv: kv[1])[0] for x in X])

    def jelaskan(self, x):
        """Rincian perhitungan untuk satu pasien (x sudah di-Z-Score)."""
        langkah = {"prior": {c: self.prior[c] for c in self.kelas}, "fitur": [], "log_skor": {}}
        for j, nama in enumerate(self.nama_fitur):
            baris = {"fitur": nama, "z": float(x[j]), "kelas": {}}
            for c in self.kelas:
                baris["kelas"][c] = {
                    "mean": float(self.mean[c][j]),
                    "std": float(self.std[c][j]),
                    "likelihood": pdf_normal(x[j], self.mean[c][j], self.std[c][j]),
                }
            langkah["fitur"].append(baris)
        langkah["log_skor"] = self._log_skor(x)
        langkah["posterior"] = self.predict_proba(x)
        langkah["hasil"] = max(langkah["posterior"], key=langkah["posterior"].get)
        return langkah
