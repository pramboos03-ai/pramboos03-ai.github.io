"""Tahap 3 - Web Telemedicine skrining risiko diabetes (Flask + SQLite).
Jalankan lokal: python app.py   |  Produksi: lihat docs/PANDUAN_HOSTING.md"""
import json, math, os, pickle, secrets, sqlite3
from datetime import datetime
from functools import wraps

import numpy as np
import pandas as pd
from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from ml.preprocess import FITUR, KOLOM_NOL_KOSONG

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "data", "app.db")
ARTEFAK = os.path.join(BASE, "models", "artefak.pkl")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "ganti-nilai-ini-di-produksi")

# ---------------------------------------------------------------- konfigurasi
FORM = [  # nama, label, satuan, min, max, step, bantuan
    ("Pregnancies", "Jumlah kehamilan", "kali", 0, 20, 1, "Isi 0 jika belum pernah hamil."),
    ("Glucose", "Glukosa plasma", "mg/dL", 40, 300, 1, "Hasil tes toleransi glukosa 2 jam."),
    ("BloodPressure", "Tekanan darah diastolik", "mmHg", 30, 140, 1, "Angka bawah pada hasil tensi."),
    ("SkinThickness", "Tebal lipatan kulit trisep", "mm", 5, 100, 1, "Boleh dikosongkan jika tidak diukur."),
    ("Insulin", "Insulin serum 2 jam", "µU/mL", 10, 900, 1, "Boleh dikosongkan jika tidak diukur."),
    ("BMI", "Indeks massa tubuh", "kg/m²", 12, 70, 0.1, "Berat (kg) dibagi tinggi (m) kuadrat."),
    ("DiabetesPedigreeFunction", "Skor riwayat keluarga diabetes", "", 0.05, 2.5, 0.001, "Boleh dikosongkan jika tidak tahu."),
    ("Age", "Usia", "tahun", 21, 90, 1, "Wajib diisi. Data latih hanya memuat usia 21 tahun ke atas."),
]
LABEL = {f[0]: f[1] for f in FORM}
SATUAN = {f[0]: f[2] for f in FORM}
JURNAL = [
    {"kode": "Jurnal 1", "isi": "Decision Tree, SVM, Naive Bayes + Z-Score pada Pima (UCI): SVM terbaik",
     "model": "SVM", "akurasi": 80.73,
     "url": "https://journal.nurulfikri.ac.id/index.php/jtt/article/download/564/283"},
    {"kode": "Jurnal 2", "isi": "Naive Bayes di RapidMiner pada data diabetes",
     "model": "Naive Bayes", "akurasi": 75.51,
     "url": "https://jurnal.pelitabangsa.ac.id/index.php/pelitatekno/article/view/4329"},
]


# ---------------------------------------------------------------- model
_cache = {}


def muat_model():
    if "m" not in _cache:
        if not os.path.exists(ARTEFAK):
            return None
        with open(ARTEFAK, "rb") as f:
            _cache["m"] = pickle.load(f)
    return _cache["m"]


# ---------------------------------------------------------------- database
def db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB), exist_ok=True)
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def tutup_db(_):
    d = g.pop("db", None)
    if d:
        d.close()


SKEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, peran TEXT NOT NULL CHECK(peran IN ('pasien','dokter')));
CREATE TABLE IF NOT EXISTS skrining(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
  waktu TEXT NOT NULL, input_json TEXT NOT NULL, nb_prob REAL, dt_hasil INTEGER,
  svm_skor REAL, jumlah_positif INTEGER);
CREATE TABLE IF NOT EXISTS pesan(
  id INTEGER PRIMARY KEY AUTOINCREMENT, skrining_id INTEGER NOT NULL REFERENCES skrining(id),
  user_id INTEGER NOT NULL REFERENCES users(id), isi TEXT NOT NULL, waktu TEXT NOT NULL);
"""


def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    con = sqlite3.connect(DB)
    con.executescript(SKEMA)
    if not con.execute("SELECT 1 FROM users WHERE peran='dokter'").fetchone():
        sandi = os.environ.get("DOKTER_PASSWORD", "dokter123")
        con.execute("INSERT INTO users(nama,email,password_hash,peran) VALUES(?,?,?,'dokter')",
                    ("dr. Demo", "dokter@demo.id", generate_password_hash(sandi)))
    con.commit(); con.close()


@app.cli.command("buat-dokter")
def buat_dokter():
    """flask buat-dokter  -> tambah akun dokter secara interaktif"""
    import getpass
    nama, email = input("Nama: "), input("Email: ")
    sandi = getpass.getpass("Password: ")
    init_db()
    con = sqlite3.connect(DB)
    con.execute("INSERT INTO users(nama,email,password_hash,peran) VALUES(?,?,?,'dokter')",
                (nama, email.lower(), generate_password_hash(sandi)))
    con.commit(); con.close(); print("Dokter ditambahkan.")


# ---------------------------------------------------------------- sesi, CSRF, filter
@app.before_request
def siapkan():
    g.user = None
    if "uid" in session:
        g.user = db().execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method == "POST" and request.form.get("csrf") != session["csrf"]:
        abort(400, "Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.")


@app.context_processor
def konteks():
    return {"csrf": session.get("csrf", ""), "user": g.get("user")}


def wajib_login(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            flash("Masuk dulu untuk membuka halaman itu.")
            return redirect(url_for("masuk"))
        return f(*a, **k)
    return w


def wajib_peran(peran):
    def dekor(f):
        @wraps(f)
        @wajib_login
        def w(*a, **k):
            if g.user["peran"] != peran:
                abort(403)
            return f(*a, **k)
        return w
    return dekor


@app.template_filter("f2")
def f2(x): return f"{x:.2f}".replace(".", ",")
@app.template_filter("f3")
def f3(x): return f"{x:.3f}".replace(".", ",")
@app.template_filter("f4")
def f4(x): return f"{x:.4f}".replace(".", ",")
@app.template_filter("pct")
def pct(x): return f"{x * 100:.1f}".replace(".", ",") + "%"
@app.template_filter("tgl")
def tgl(s): return datetime.fromisoformat(s).strftime("%d-%m-%Y %H:%M")
@app.template_filter("num")
def num(x):
    x = float(x)
    return str(int(x)) if x == int(x) else f"{x:g}".replace(".", ",")


# ---------------------------------------------------------------- perhitungan
def parse_form(form):
    nilai, galat = {}, []
    for nama, label, _, lo, hi, _, _ in FORM:
        mentah = (form.get(nama) or "").strip().replace(",", ".")
        if mentah == "":
            if nama == "Age":
                galat.append("Usia wajib diisi.")
            nilai[nama] = None
            continue
        try:
            v = float(mentah)
        except ValueError:
            galat.append(f"{label}: isi dengan angka."); continue
        if v == 0 and nama in KOLOM_NOL_KOSONG:
            nilai[nama] = None  # 0 berarti tidak diukur
            continue
        if not (lo <= v <= hi):
            galat.append(f"{label}: nilai harus antara {lo:g} dan {hi:g}."); continue
        nilai[nama] = v
    return nilai, galat


def hitung(nilai):
    M = muat_model(); pp = M["pp"]
    baris = pd.DataFrame([{f: (np.nan if nilai.get(f) is None else float(nilai[f])) for f in FITUR}])
    z = pp.zscore(baris).to_numpy()[0]
    imp = pp.imputasi(baris).iloc[0]
    return M, pp, baris.iloc[0], imp, z


def penjelasan(nilai):
    M, pp, asli, imp, z = hitung(nilai)
    # 1. data & Z-Score
    tabel = [{"nama": LABEL[f], "satuan": SATUAN[f], "asli": asli[f], "dipakai": float(imp[f]),
              "median": bool(np.isnan(asli[f])), "mean": pp.mean[f], "std": pp.std[f], "z": float(z[i])}
             for i, f in enumerate(FITUR)]
    # 2. Naive Bayes
    nb = M["nb"].jelaskan(z)
    baris_nb, s0, s1 = [], 0.0, 0.0
    for i, b in enumerate(nb["fitur"]):
        l0, l1 = b["kelas"][0]["likelihood"], b["kelas"][1]["likelihood"]
        l0, l1 = max(l0, 1e-300), max(l1, 1e-300)
        s0 += math.log(l0); s1 += math.log(l1)
        baris_nb.append({"nama": LABEL[b["fitur"]], "z": b["z"], "m0": b["kelas"][0]["mean"],
                         "s0": b["kelas"][0]["std"], "m1": b["kelas"][1]["mean"], "s1": b["kelas"][1]["std"],
                         "l0": l0, "l1": l1, "lnr": math.log(l1 / l0)})
    nbv = {"baris": baris_nb, "prior0": nb["prior"][0], "prior1": nb["prior"][1],
           "ln_prior0": math.log(nb["prior"][0]), "ln_prior1": math.log(nb["prior"][1]),
           "s0": s0, "s1": s1, "log0": nb["log_skor"][0], "log1": nb["log_skor"][1],
           "p0": nb["posterior"][0], "p1": nb["posterior"][1], "hasil": nb["hasil"],
           "pendorong": sorted(baris_nb, key=lambda r: -r["lnr"])[:3],
           "penahan": sorted(baris_nb, key=lambda r: r["lnr"])[:2]}
    # 3. Decision Tree
    dt = M["dt"].jelaskan(z, pp.mean, pp.std)
    langkah = []
    for j in dt["jalur"]:
        a, b_, n = j["hitung_kelas"][0], j["hitung_kelas"][1], j["n_node"]
        langkah.append({
            "fitur": LABEL[j["fitur"]], "nilai": float(imp[j["fitur"]]), "batas": j["batas_asli"],
            "kiri": j["arah"].startswith("kiri"), "n": n, "a": a, "b": b_,
            "rumus_induk": f"1 − (({a}/{n})² + ({b_}/{n})²) = {j['gini_induk']:.3f}",
            "rumus_tertimbang": (f"({j['n_kiri']}/{n}) × {j['gini_kiri']:.3f} + "
                                 f"({j['n_kanan']}/{n}) × {j['gini_kanan']:.3f} = {j['gini_tertimbang']:.3f}"),
            "rumus_gain": f"{j['gini_induk']:.3f} − {j['gini_tertimbang']:.3f} = {j['gain']:.3f}"})
    dtv = {"langkah": langkah, "daun": dt["daun"], "hasil": dt["hasil"]}
    # 4. SVM
    sv = M["svm"].jelaskan(z)
    mx = max([abs(k["kontribusi"]) for k in sv["kontribusi"]] + [abs(sv["bias"]), 1e-9])
    svv = {"baris": [{"nama": LABEL[k["fitur"]], **k, "lebar": abs(k["kontribusi"]) / mx * 100}
                     for k in sv["kontribusi"]],
           "bias": sv["bias"], "skor": sv["skor"], "hasil": sv["hasil"],
           "jumlah_kontribusi": sum(k["kontribusi"] for k in sv["kontribusi"])}
    suara = int(nb["hasil"]) + int(dt["hasil"]) + int(sv["hasil"])
    return {"data": tabel, "nb": nbv, "dt": dtv, "svm": svv, "suara": suara,
            "ringkas": {"nb_prob": nb["posterior"][1], "dt": dt["hasil"], "svm": sv["skor"], "suara": suara}}


TINGKAT = {0: ("rendah", "Ketiga model tidak menandai risiko diabetes."),
           1: ("ringan", "Satu dari tiga model menandai risiko diabetes."),
           2: ("sedang", "Dua dari tiga model menandai risiko diabetes."),
           3: ("tinggi", "Ketiga model menandai risiko diabetes.")}


# ---------------------------------------------------------------- halaman umum
@app.route("/")
def beranda():
    return render_template("beranda.html", siap=muat_model() is not None)


@app.route("/model")
def model_data():
    M = muat_model()
    if not M:
        return render_template("belum_siap.html")
    L = M["laporan"]
    nama_nb, nama_svm = "Naive Bayes", "SVM (linear, bobot kelas)"
    return render_template("model.html", L=L, LABEL=LABEL, jurnal=JURNAL, nama_nb=nama_nb, nama_svm=nama_svm,
                           akurasi_cv_nb=L["cv"][nama_nb]["akurasi"] * 100,
                           akurasi_cv_svm=L["cv"][nama_svm]["akurasi"] * 100)


# ---------------------------------------------------------------- akun
@app.route("/daftar", methods=["GET", "POST"])
def daftar():
    if request.method == "POST":
        nama, email = request.form["nama"].strip(), request.form["email"].strip().lower()
        sandi = request.form["password"]
        if not nama or "@" not in email:
            flash("Isi nama dan alamat email yang benar.")
        elif len(sandi) < 8:
            flash("Password minimal 8 karakter.")
        elif db().execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            flash("Email itu sudah terdaftar. Silakan masuk.")
        else:
            db().execute("INSERT INTO users(nama,email,password_hash,peran) VALUES(?,?,?,'pasien')",
                         (nama, email, generate_password_hash(sandi)))
            db().commit()
            flash("Akun dibuat. Silakan masuk.")
            return redirect(url_for("masuk"))
    return render_template("daftar.html")


@app.route("/masuk", methods=["GET", "POST"])
def masuk():
    if request.method == "POST":
        u = db().execute("SELECT * FROM users WHERE email=?", (request.form["email"].strip().lower(),)).fetchone()
        if u and check_password_hash(u["password_hash"], request.form["password"]):
            session.clear(); session["uid"] = u["id"]; session["csrf"] = secrets.token_hex(16)
            return redirect(url_for("dokter" if u["peran"] == "dokter" else "skrining"))
        flash("Email atau password salah.")
    return render_template("masuk.html")


@app.route("/keluar", methods=["POST"])
def keluar():
    session.clear()
    return redirect(url_for("beranda"))


# ---------------------------------------------------------------- skrining
@app.route("/skrining", methods=["GET", "POST"])
@wajib_peran("pasien")
def skrining():
    if not muat_model():
        return render_template("belum_siap.html")
    galat, isi = [], {}
    if request.method == "POST":
        isi = request.form
        nilai, galat = parse_form(request.form)
        if not galat:
            p = penjelasan(nilai)["ringkas"]
            cur = db().execute(
                "INSERT INTO skrining(user_id,waktu,input_json,nb_prob,dt_hasil,svm_skor,jumlah_positif)"
                " VALUES(?,?,?,?,?,?,?)",
                (g.user["id"], datetime.now().isoformat(timespec="seconds"), json.dumps(nilai),
                 p["nb_prob"], int(p["dt"]), p["svm"], p["suara"]))
            db().commit()
            return redirect(url_for("hasil", sid=cur.lastrowid))
    return render_template("skrining.html", form=FORM, galat=galat, isi=isi)


def ambil_skrining(sid):
    s = db().execute("SELECT s.*, u.nama AS pasien FROM skrining s JOIN users u ON u.id=s.user_id "
                     "WHERE s.id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    if g.user["peran"] != "dokter" and s["user_id"] != g.user["id"]:
        abort(403)
    return s


@app.route("/hasil/<int:sid>")
@wajib_login
def hasil(sid):
    s = ambil_skrining(sid)
    if not muat_model():
        return render_template("belum_siap.html")
    P = penjelasan(json.loads(s["input_json"]))
    pesan = db().execute("SELECT p.*, u.nama, u.peran FROM pesan p JOIN users u ON u.id=p.user_id "
                         "WHERE skrining_id=? ORDER BY p.id", (sid,)).fetchall()
    return render_template("hasil.html", s=s, P=P, tingkat=TINGKAT[P["suara"]], pesan=pesan)


@app.route("/hasil/<int:sid>/pesan", methods=["POST"])
@wajib_login
def kirim_pesan(sid):
    ambil_skrining(sid)
    isi = request.form.get("isi", "").strip()
    if isi:
        db().execute("INSERT INTO pesan(skrining_id,user_id,isi,waktu) VALUES(?,?,?,?)",
                     (sid, g.user["id"], isi[:1000], datetime.now().isoformat(timespec="seconds")))
        db().commit()
    return redirect(url_for("hasil", sid=sid) + "#konsultasi")


@app.route("/riwayat")
@wajib_peran("pasien")
def riwayat():
    rows = db().execute("SELECT * FROM skrining WHERE user_id=? ORDER BY id DESC", (g.user["id"],)).fetchall()
    return render_template("riwayat.html", rows=rows, tingkat=TINGKAT)


@app.route("/dokter")
@wajib_peran("dokter")
def dokter():
    rows = db().execute(
        "SELECT s.*, u.nama AS pasien, (SELECT COUNT(*) FROM pesan p WHERE p.skrining_id=s.id) AS n_pesan "
        "FROM skrining s JOIN users u ON u.id=s.user_id ORDER BY s.jumlah_positif DESC, s.id DESC").fetchall()
    return render_template("dokter.html", rows=rows, tingkat=TINGKAT)


init_db()

if __name__ == "__main__":
    app.run(debug=True)
