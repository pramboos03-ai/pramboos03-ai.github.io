@echo off
title TeleDiabetes - Skrining Diabetes
echo ====================================================
echo  Menjalankan TeleDiabetes (Flask Web)
echo ====================================================
echo Membuka browser ke http://127.0.0.1:5000 ...
start http://127.0.0.1:5000
python app.py
pause
