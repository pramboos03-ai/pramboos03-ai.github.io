# Panduan RapidMiner (Bab "Pengolahan Algoritma dan Analisis Data")

Tujuan: mengulang eksperimen yang sama dengan `train.py` di RapidMiner, lalu membandingkan angkanya.
Nama operator di bawah sesuai RapidMiner Studio versi umum; jika versi Anda berbeda, cari nama yang mirip di panel Operators.

## Proses (satu alur, dari kiri ke kanan)
1. **Read CSV** (atau Retrieve setelah Import Data): pilih `diabetes.csv`. Pastikan kolom numerik terbaca sebagai `integer`/`real`.
2. **Set Role**: atribut `Outcome` → role `label`.
3. **Numerical to Binominal**: pilih atribut `Outcome` (0 = false, 1 = true), agar menjadi label klasifikasi.
4. **Declare Missing Value**: pilih `Glucose, BloodPressure, SkinThickness, Insulin, BMI`, mode `numeric`, nilai `0`. Ini sama dengan langkah "0 dianggap kosong" di sistem web.
5. **Replace Missing Values**: pilih atribut yang sama, `replace with` = `median`. (Sistem web memakai median.)
6. **Normalize**: `method` = `Z-transformation`, atribut: semua kecuali label. (Sama dengan Z-Score.)
7. **Cross Validation** (number of folds = 10, sampling type = `stratified sampling`). Isi bagian dalam:
   - Training: **Naive Bayes** / **Decision Tree** (`criterion` = `gini_index`, `maximal depth` = 4) / **Support Vector Machine** (kernel `dot` untuk linear).
   - Testing: **Apply Model** → **Performance (Binominal Classification)** atau **Performance (Classification)**, centang accuracy, precision, recall, f_measure.
8. Jalankan tiga kali, satu untuk tiap algoritma (cukup ganti operator di dalam Cross Validation), lalu screenshot: proses, hasil Performance (confusion matrix), dan pohon keputusan.

## Cara membandingkan dengan sistem web
| Yang dibandingkan | RapidMiner | Sistem web (`train.py`) |
|---|---|---|
| Akurasi 10-fold | angka dari Performance | tabel "Validasi silang" di halaman Model dan data |
| Aturan pohon | tampilan Tree | bagian "Aturan Decision Tree" |
| Confusion matrix | tabel di Performance | halaman Model dan data |

Selisih satu atau dua persen wajar: pembagian lipatan acak, penanganan angka desimal, dan parameter bawaan berbeda. Tulis selisih itu dan alasannya di laporan.

## Yang ditulis di laporan
- Gambar alur proses RapidMiner dan penjelasan tiap operator (apa yang dikerjakannya dan kenapa).
- Tabel akurasi, precision, recall, F1 untuk tiga algoritma.
- Analisis: kenapa Naive Bayes sekitar 75% (fitur berkorelasi, asumsi bebas) dan SVM lebih tinggi (tidak berasumsi bebas, margin lebar, Z-Score membantu). Gunakan angka milik Anda sendiri.
