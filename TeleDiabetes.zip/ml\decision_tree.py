"""Tahap 2 - Decision Tree (CART, kriteria Gini) buatan sendiri.
Setiap percabangan menyimpan angka Gini & Gain sehingga bisa ditampilkan di web."""
import numpy as np


def gini(y):
    if len(y) == 0:
        return 0.0
    p = np.bincount(y.astype(int), minlength=2) / len(y)
    return float(1.0 - np.sum(p ** 2))


class Node:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class DecisionTree:
    def __init__(self, nama_fitur, max_depth=4, min_samples=20):
        self.nama_fitur, self.max_depth, self.min_samples = nama_fitur, max_depth, min_samples

    def fit(self, X, y):
        self.root = self._bangun(X, y.astype(int), 0)
        return self

    def _split_terbaik(self, X, y):
        g_induk, n = gini(y), len(y)
        terbaik = None
        for j in range(X.shape[1]):
            nilai = np.unique(X[:, j])
            if len(nilai) < 2:
                continue
            batas = (nilai[:-1] + nilai[1:]) / 2
            if len(batas) > 40:  # percepat: pakai 40 kandidat persentil
                batas = np.unique(np.percentile(X[:, j], np.linspace(2, 98, 40)))
            for b in batas:
                kiri = X[:, j] <= b
                nk, nr = kiri.sum(), (~kiri).sum()
                if nk < 5 or nr < 5:
                    continue
                g_kiri, g_kanan = gini(y[kiri]), gini(y[~kiri])
                g_tertimbang = (nk / n) * g_kiri + (nr / n) * g_kanan
                gain = g_induk - g_tertimbang
                if terbaik is None or gain > terbaik["gain"]:
                    terbaik = dict(fitur=j, batas=float(b), gain=gain, g_induk=g_induk,
                                   g_kiri=g_kiri, g_kanan=g_kanan, g_tertimbang=g_tertimbang,
                                   n_kiri=int(nk), n_kanan=int(nr))
        return terbaik

    def _bangun(self, X, y, depth):
        hitung = [int((y == 0).sum()), int((y == 1).sum())]
        daun = Node(daun=True, hitung=hitung, n=len(y), kelas=int(np.argmax(hitung)),
                    gini=gini(y), depth=depth)
        if depth >= self.max_depth or len(y) < self.min_samples or gini(y) == 0:
            return daun
        s = self._split_terbaik(X, y)
        if s is None or s["gain"] <= 1e-9:
            return daun
        kiri = X[:, s["fitur"]] <= s["batas"]
        return Node(daun=False, hitung=hitung, n=len(y), depth=depth, split=s,
                    kiri=self._bangun(X[kiri], y[kiri], depth + 1),
                    kanan=self._bangun(X[~kiri], y[~kiri], depth + 1))

    def _prediksi_satu(self, x):
        n = self.root
        while not n.daun:
            n = n.kiri if x[n.split["fitur"]] <= n.split["batas"] else n.kanan
        return n.kelas

    def predict(self, X):
        return np.array([self._prediksi_satu(x) for x in X])

    def jelaskan(self, x, mean=None, std=None):
        """Jalur keputusan satu pasien beserta perhitungan Gini tiap langkah.
        mean/std (opsional) dipakai agar batas ditampilkan dalam satuan asli."""
        jalur, n = [], self.root
        while not n.daun:
            s, j = n.split, n.split["fitur"]
            nama = self.nama_fitur[j]
            ke_kiri = bool(x[j] <= s["batas"])
            batas_asli = s["batas"] * std[nama] + mean[nama] if mean else None
            jalur.append({
                "fitur": nama, "nilai_z": float(x[j]), "batas_z": s["batas"],
                "batas_asli": batas_asli, "arah": "kiri (<=)" if ke_kiri else "kanan (>)",
                "n_node": n.n, "hitung_kelas": n.hitung,
                "gini_induk": s["g_induk"], "gini_kiri": s["g_kiri"], "gini_kanan": s["g_kanan"],
                "n_kiri": s["n_kiri"], "n_kanan": s["n_kanan"],
                "gini_tertimbang": s["g_tertimbang"], "gain": s["gain"],
                "rumus_gini": (f"Gini = 1 - (p0^2 + p1^2), induk: p0={n.hitung[0]}/{n.n}, "
                               f"p1={n.hitung[1]}/{n.n}"),
            })
            n = n.kiri if ke_kiri else n.kanan
        return {"jalur": jalur, "daun": {"hitung_kelas": n.hitung, "n": n.n, "gini": n.gini},
                "hasil": n.kelas}

    def importance(self):
        """Pentingnya fitur = total (n/N * gain) tiap split."""
        imp = {f: 0.0 for f in self.nama_fitur}
        N = self.root.n

        def jalan(n):
            if n.daun:
                return
            imp[self.nama_fitur[n.split["fitur"]]] += n.n / N * n.split["gain"]
            jalan(n.kiri); jalan(n.kanan)
        jalan(self.root)
        t = sum(imp.values()) or 1.0
        return {k: v / t for k, v in sorted(imp.items(), key=lambda kv: -kv[1])}
