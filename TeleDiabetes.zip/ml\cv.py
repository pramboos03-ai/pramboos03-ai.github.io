"""Tahap 2 - Stratified k-fold cross validation (agar akurasi tidak bergantung satu kali split)."""
import numpy as np
from .preprocess import Praproses, FITUR, TARGET
from .metrics import evaluasi


def kfold_stratified(df, k=10, seed=42):
    rng = np.random.default_rng(seed)
    lipatan = [[] for _ in range(k)]
    for kelas in df[TARGET].unique():
        idx = df.index[df[TARGET] == kelas].to_numpy().copy()
        rng.shuffle(idx)
        for i, v in enumerate(idx):
            lipatan[i % k].append(v)
    return [sorted(f) for f in lipatan]


def cross_validate(df, buat_model, k=10, seed=42):
    hasil = []
    for fold in kfold_stratified(df, k, seed):
        uji = df.loc[fold].reset_index(drop=True)
        latih = df.drop(index=fold).reset_index(drop=True)
        pp = Praproses().fit(latih)
        Xl, yl = pp.transform(latih); Xu, yu = pp.transform(uji)
        m = buat_model().fit(Xl, yl)
        e = evaluasi(yu, m.predict(Xu))
        hasil.append(e)
    rata = {k_: float(np.mean([h[k_] for h in hasil])) for k_ in ["akurasi", "precision", "recall", "f1"]}
    rata["akurasi_per_fold"] = [round(h["akurasi"], 4) for h in hasil]
    return rata
