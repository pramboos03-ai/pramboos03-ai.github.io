<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Surveilans Epidemiologi & SKDR';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $pkm_id = $_POST['puskesmas_id'];
        $tanggal = $_POST['tanggal'];
        $penyakit = $_POST['penyakit'];
        $kategori = $_POST['kategori'];
        $kasus = (int)$_POST['jumlah_kasus'];
        $meninggal = (int)$_POST['meninggal'];
        $status_alert = $_POST['status_alert'];
        $catatan = trim($_POST['catatan'] ?? '');
        $id = 'SRV-' . date('Y') . '-' . rand(100, 999);

        try {
            $stmt = $pdo->prepare("INSERT INTO surveilans (id, tanggal, puskesmas_id, penyakit, kategori, jumlah_kasus, meninggal, status_alert, catatan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id, $tanggal, $pkm_id, $penyakit, $kategori, $kasus, $meninggal, $status_alert, $catatan]);
            $message = 'Laporan surveilans berhasil disimpan!';
        } catch (Throwable $e) {
            $message = 'Gagal menyimpan: ' . $e->getMessage();
        }
    } elseif ($action === 'delete') {
        $del_id = $_POST['id'] ?? '';
        if ($del_id) {
            $stmt = $pdo->prepare("DELETE FROM surveilans WHERE id = ?");
            $stmt->execute([$del_id]);
            $message = 'Laporan surveilans berhasil dihapus.';
        }
    }
}

$stmt = $pdo->query("SELECT s.*, p.nama as puskesmas_nama FROM surveilans s JOIN puskesmas p ON s.puskesmas_id = p.id ORDER BY s.tanggal DESC");
$surveilans = $stmt->fetchAll();

$stmt_pkm = $pdo->query("SELECT id, nama FROM puskesmas ORDER BY nama ASC");
$all_pkm = $stmt_pkm->fetchAll();

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800">Surveilans & SKDR Penyakit Menular</h3>
    <p class="text-muted mb-0">Deteksi Dini dan Respon Potensi Kejadian Luar Biasa (KLB)</p>
  </div>
  <div>
    <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalSurveilans"><i class="bi bi-bell-fill me-1"></i> Input Kasus Baru</button>
  </div>
</div>

<?php if ($message): ?>
  <div class="alert alert-info alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($message); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<div class="card-dinkes">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-dinkes mb-0">
        <thead>
          <tr>
            <th>ID & Tanggal</th>
            <th>Puskesmas</th>
            <th>Nama Penyakit</th>
            <th class="text-center">Kasus / Meninggal</th>
            <th>Status SKDR</th>
            <th>Catatan Tindakan</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($surveilans as $s): ?>
            <tr>
              <td>
                <span class="font-monospace small fw-bold text-secondary"><?= htmlspecialchars($s['id']); ?></span>
                <div class="small text-muted"><?= htmlspecialchars($s['tanggal']); ?></div>
              </td>
              <td class="fw-bold"><?= htmlspecialchars($s['puskesmas_nama']); ?></td>
              <td>
                <div class="fw-bold"><?= htmlspecialchars($s['penyakit']); ?></div>
                <small class="text-muted"><?= htmlspecialchars($s['kategori']); ?></small>
              </td>
              <td class="text-center">
                <span class="badge bg-danger fs-6"><?= $s['jumlah_kasus']; ?></span>
                <div class="small text-muted"><?= $s['meninggal']; ?> Meninggal</div>
              </td>
              <td>
                <span class="badge <?= ($s['status_alert'] === 'Alert KLB') ? 'badge-alert-klb' : (($s['status_alert'] === 'Waspada') ? 'badge-waspada' : 'badge-normal'); ?>">
                  <?= htmlspecialchars($s['status_alert']); ?>
                </span>
              </td>
              <td><small class="text-secondary"><?= htmlspecialchars($s['catatan'] ?? '-'); ?></small></td>
              <td class="text-end">
                <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus laporan kasus ini?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= htmlspecialchars($s['id']); ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Input Surveilans -->
<div class="modal fade" id="modalSurveilans" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title fw-bold">Input Laporan Kasus Surveilans (SKDR)</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="action" value="create">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small fw-bold">Puskesmas</label>
              <select name="puskesmas_id" class="form-select" required>
                <?php foreach ($all_pkm as $p): ?>
                  <option value="<?= $p['id']; ?>"><?= htmlspecialchars($p['nama']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Tanggal</label>
              <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d'); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Penyakit</label>
              <input type="text" name="penyakit" class="form-control" placeholder="Contoh: Demam Berdarah Dengue (DBD)" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Kategori</label>
              <select name="kategori" class="form-select">
                <option value="Penyakit Menular Potensi KLB">Penyakit Menular Potensi KLB</option>
                <option value="Penyakit Menular Kronis">Penyakit Menular Kronis</option>
                <option value="Penyakit Tidak Menular (PTM)">Penyakit Tidak Menular (PTM)</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Jumlah Kasus</label>
              <input type="number" name="jumlah_kasus" class="form-control" value="5" min="1" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Meninggal</label>
              <input type="number" name="meninggal" class="form-control" value="0" min="0">
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Status Alert</label>
              <select name="status_alert" class="form-select">
                <option value="Normal">Normal</option>
                <option value="Waspada" selected>Waspada</option>
                <option value="Alert KLB">Alert KLB</option>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label small fw-bold">Catatan Penyelidikan / Respon</label>
              <textarea name="catatan" class="form-control" rows="2" placeholder="Tindakan fogging, penyelidikan epidemiologi, dll..."></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">Simpan Laporan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
