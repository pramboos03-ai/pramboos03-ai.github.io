<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Pedoman & SOP Penanganan Penyakit';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800"><i class="bi bi-shield-shaded text-teal me-2"></i> Pedoman Penanganan & Pencegahan Penyakit</h3>
    <p class="text-muted mb-0">Standar Operasional Prosedur (SOP) Tatalaksana Medis, Respon Lapangan TGC, dan Pencegahan Masyarakat</p>
  </div>
  <div>
    <button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer-fill me-1"></i> Cetak Dokumen SOP</button>
  </div>
</div>

<script src="../js/pedoman_data.js"></script>

<div class="card-dinkes">
  <div class="card-body">
    <!-- Disease Buttons -->
    <div class="d-flex flex-wrap gap-2 mb-4 pb-2 border-bottom" id="php-pedoman-buttons"></div>

    <div id="php-pedoman-content">
      <!-- Injected by JS -->
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  if (typeof PEDOMAN_PENYAKIT === 'undefined') return;

  var btnContainer = document.getElementById('php-pedoman-buttons');
  var contentContainer = document.getElementById('php-pedoman-content');

  function renderDisease(idx) {
    var p = PEDOMAN_PENYAKIT[idx] || PEDOMAN_PENYAKIT[0];

    // render buttons
    btnContainer.innerHTML = PEDOMAN_PENYAKIT.map(function(item, i) {
      var active = i === idx;
      return '<button class="btn btn-sm ' + (active ? 'btn-primary' : 'btn-outline-secondary') + '" onclick="renderDisease(' + i + ')">' + item.nama + '</button>';
    }).join(' ');

    contentContainer.innerHTML = `
      <div class="alert alert-light border border-${p.warna_kategori} mb-4">
        <span class="badge bg-${p.warna_kategori} mb-1">${p.kategori}</span>
        <h4 class="fw-bold mb-1">${p.nama} (${p.kode})</h4>
        <p class="small text-muted mb-0"><strong>Patogen / Vektor:</strong> ${p.vektor_patogen} &bull; <strong>Masa Inkubasi:</strong> ${p.masa_inkubasi}</p>
      </div>

      <div class="row g-4">
        <div class="col-12 col-lg-6">
          <div class="p-3 bg-white border rounded-3 h-100">
            <h6 class="fw-bold text-primary"><i class="bi bi-heart-pulse-fill me-1"></i> 1. Tatalaksana Klinis & Medis</h6>
            <h6 class="small text-muted text-uppercase fw-bold mt-2">Gejala Klinis:</h6>
            <ul class="small ps-3">${p.gejala_klinis.map(g => '<li>' + g + '</li>').join('')}</ul>
            <h6 class="small text-muted text-uppercase fw-bold mt-3 border-top pt-2">Langkah Pengobatan:</h6>
            <ol class="small ps-3">${p.tatalaksana_medis.map(m => '<li class="' + (m.indexOf('KONTRAINDIKASI') !== -1 ? 'text-danger fw-bold' : '') + '">' + m + '</li>').join('')}</ol>
          </div>
        </div>

        <div class="col-12 col-lg-6">
          <div class="p-3 bg-white border rounded-3 h-100">
            <h6 class="fw-bold text-danger"><i class="bi bi-bell-fill me-1"></i> 2. SOP Respon Cepat TGC Dinkes</h6>
            <ol class="small ps-3 mt-2">${p.sop_respon_dinkes.map(s => '<li class="mb-1.5">' + s + '</li>').join('')}</ol>
          </div>
        </div>

        <div class="col-12 col-lg-6">
          <div class="p-3 bg-white border rounded-3 h-100">
            <h6 class="fw-bold text-success"><i class="bi bi-shield-check me-1"></i> 3. Pencegahan & Edukasi Masyarakat</h6>
            <ul class="small ps-3 mt-2">${p.pencegahan_masyarakat.map(pm => '<li class="mb-1">' + pm + '</li>').join('')}</ul>
          </div>
        </div>

        <div class="col-12 col-lg-6">
          <div class="p-3 bg-white border rounded-3 h-100">
            <h6 class="fw-bold text-warning text-dark"><i class="bi bi-box-seam-fill me-1"></i> 4. Logistik Obat GFK Terkait</h6>
            <div class="p-2.5 bg-light rounded-2 mt-2">
              <strong class="small text-dark">${p.logistik_terkait}</strong>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  window.renderDisease = renderDisease;
  renderDisease(0);
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
