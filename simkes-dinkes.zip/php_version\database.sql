-- ========================================================
-- SISTEM INFORMASI MANAJEMEN KESEHATAN (SIMKES DINKES)
-- DATABASE SCHEMA & DEFAULT SEED DATA
-- Kompatibel dengan MySQL 5.7+ / MariaDB / SQLite
-- ========================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `distribusi`;
DROP TABLE IF EXISTS `obat_gfk`;
DROP TABLE IF EXISTS `stunting`;
DROP TABLE IF EXISTS `surveilans`;
DROP TABLE IF EXISTS `puskesmas`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. TABEL PENGGUNA (USERS & HAK AKSES)
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(100) NOT NULL,
  `role` ENUM('superadmin', 'p2p', 'kesmas', 'farmasi', 'puskesmas') NOT NULL DEFAULT 'superadmin',
  `puskesmas_id` VARCHAR(20) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password default: "admin123" (dihash dengan password_hash BCRYPT)
INSERT INTO `users` (`username`, `password`, `nama_lengkap`, `role`) VALUES
('kadis', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dr. H. Rahmat Hidayat, M.Kes (Kepala Dinas)', 'superadmin'),
('admin_p2p', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dr. Irfan Maulana (Kabid P2P & Surveilans)', 'p2p'),
('admin_kesmas', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Hj. Nurlaila, S.KM, M.Kes (Kabid Kesmas & Gizi)', 'kesmas'),
('admin_farmasi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Apt. Wahyu Pratama, S.Farm (Pengelola GFK)', 'farmasi');

-- 2. TABEL PUSKESMAS & FASILITAS KESEHATAN
CREATE TABLE `puskesmas` (
  `id` VARCHAR(20) PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `kecamatan` VARCHAR(80) NOT NULL,
  `tipe` VARCHAR(50) NOT NULL DEFAULT 'Rawat Inap',
  `akreditasi` VARCHAR(50) NOT NULL DEFAULT 'Paripurna',
  `kepala` VARCHAR(100) NOT NULL,
  `kontak` VARCHAR(50) DEFAULT NULL,
  `jml_dokter` INT DEFAULT 4,
  `jml_perawat` INT DEFAULT 12,
  `jml_bidan` INT DEFAULT 10,
  `wilayah_desa` INT DEFAULT 6,
  `populasi` INT DEFAULT 35000,
  `status` VARCHAR(20) DEFAULT 'Aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `puskesmas` (`id`, `nama`, `kecamatan`, `tipe`, `akreditasi`, `kepala`, `kontak`, `jml_dokter`, `jml_perawat`, `jml_bidan`, `wilayah_desa`, `populasi`, `status`) VALUES
('PKM001', 'Puskesmas Sukamaju', 'Kec. Sukamaju', 'Rawat Inap', 'Paripurna', 'dr. Anita Wijaya', '0812-1111-2222', 5, 14, 12, 6, 48500, 'Aktif'),
('PKM002', 'Puskesmas Mentari Indah', 'Kec. Mentari', 'Non Rawat Inap', 'Paripurna', 'dr. Budi Santoso', '0812-2222-3333', 4, 10, 9, 5, 36200, 'Aktif'),
('PKM003', 'Puskesmas Cibadak Sehat', 'Kec. Cibadak', 'Rawat Inap', 'Utama', 'dr. Hendra Kusuma', '0813-3333-4444', 6, 16, 14, 8, 54300, 'Aktif'),
('PKM004', 'Puskesmas Harapan Jaya', 'Kec. Harapan', 'Non Rawat Inap', 'Utama', 'dr. Siti Rahmawati', '0813-4444-5555', 3, 9, 8, 4, 29800, 'Aktif'),
('PKM005', 'Puskesmas Danau Sari', 'Kec. Danau', 'Rawat Inap', 'Madya', 'dr. Dimas Pratama', '0815-5555-6666', 4, 12, 11, 7, 41200, 'Aktif'),
('PKM006', 'Puskesmas Gunung Kencana', 'Kec. Gunung', 'Non Rawat Inap', 'Madya', 'dr. Ratna Dewi', '0815-6666-7777', 3, 8, 7, 5, 25400, 'Aktif'),
('PKM007', 'Puskesmas Karang Sari', 'Kec. Karang', 'Rawat Inap', 'Utama', 'dr. Eko Prasetyo', '0816-7777-8888', 5, 15, 13, 6, 47600, 'Aktif'),
('PKM008', 'Puskesmas Pesisir Raya', 'Kec. Pesisir', 'Non Rawat Inap', 'Paripurna', 'dr. Maya Safitri', '0817-8888-9999', 4, 11, 10, 5, 33900, 'Aktif');

-- 3. TABEL SURVEILANS EPIDEMIOLOGI & SKDR (P2P)
CREATE TABLE `surveilans` (
  `id` VARCHAR(30) PRIMARY KEY,
  `tanggal` DATE NOT NULL,
  `puskesmas_id` VARCHAR(20) NOT NULL,
  `penyakit` VARCHAR(100) NOT NULL,
  `kategori` VARCHAR(80) NOT NULL,
  `jumlah_kasus` INT NOT NULL DEFAULT 1,
  `meninggal` INT NOT NULL DEFAULT 0,
  `status_alert` ENUM('Normal', 'Waspada', 'Alert KLB') NOT NULL DEFAULT 'Normal',
  `catatan` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`puskesmas_id`) REFERENCES `puskesmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `surveilans` (`id`, `tanggal`, `puskesmas_id`, `penyakit`, `kategori`, `jumlah_kasus`, `meninggal`, `status_alert`, `catatan`) VALUES
('SRV-2026-001', '2026-11-20', 'PKM001', 'Demam Berdarah Dengue (DBD)', 'Penyakit Menular Potensi KLB', 28, 0, 'Waspada', 'Peningkatan kasus di Desa Sukaresmi RT 03/04.'),
('SRV-2026-002', '2026-11-21', 'PKM003', 'Demam Berdarah Dengue (DBD)', 'Penyakit Menular Potensi KLB', 34, 1, 'Alert KLB', 'Melebihi ambang batas epidemik minggu 46. Tim Gerak Cepat diterjunkan.'),
('SRV-2026-003', '2026-11-22', 'PKM002', 'Infeksi Saluran Pernapasan Akut (ISPA)', 'Penyakit Menular', 142, 0, 'Normal', 'Dominan balita dan lansia karena cuaca ekstrem pancaroba.'),
('SRV-2026-004', '2026-11-22', 'PKM004', 'Diare Akut', 'Penyakit Menular Potensi KLB', 45, 0, 'Waspada', 'Penyuluhan sanitasi air bersih digiatkan.'),
('SRV-2026-005', '2026-11-23', 'PKM005', 'Tuberkulosis (TBC)', 'Penyakit Menular Kronis', 18, 0, 'Normal', 'Skrining kontak serumah aktif dengan TCM.'),
('SRV-2026-006', '2026-11-24', 'PKM007', 'Hipertensi Esensial', 'Penyakit Tidak Menular (PTM)', 188, 0, 'Normal', 'Skrining Posbindu PTM rutin 6 desa.'),
('SRV-2026-007', '2026-11-25', 'PKM008', 'Suspek Campak / Morbili', 'Penyakit Menular Potensi KLB', 7, 0, 'Waspada', 'Sampel serum dikirim ke Balai Labkesda.');

-- 4. TABEL STUNTING & KESMAS
CREATE TABLE `stunting` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `puskesmas_id` VARCHAR(20) NOT NULL,
  `total_balita` INT NOT NULL,
  `balita_ditimbang` INT NOT NULL,
  `balita_stunting` INT NOT NULL,
  `balita_wasting` INT NOT NULL DEFAULT 0,
  `persen_stunting` DECIMAL(5,2) NOT NULL,
  `cakupan_imunisasi` DECIMAL(5,2) NOT NULL DEFAULT 90.0,
  `periode` VARCHAR(20) DEFAULT '2026-11',
  FOREIGN KEY (`puskesmas_id`) REFERENCES `puskesmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `stunting` (`puskesmas_id`, `total_balita`, `balita_ditimbang`, `balita_stunting`, `balita_wasting`, `persen_stunting`, `cakupan_imunisasi`) VALUES
('PKM001', 3420, 3180, 268, 84, 8.40, 94.20),
('PKM002', 2840, 2650, 215, 62, 8.10, 96.00),
('PKM003', 4100, 3750, 495, 128, 13.20, 88.50),
('PKM004', 2150, 1980, 178, 46, 9.00, 92.40),
('PKM005', 3200, 2890, 390, 110, 13.50, 86.80),
('PKM006', 1920, 1740, 242, 55, 13.90, 85.10),
('PKM007', 3650, 3410, 358, 89, 10.50, 93.70),
('PKM008', 2600, 2390, 265, 71, 11.10, 91.20);

-- 5. TABEL GUDANG FARMASI KABUPATEN (GFK)
CREATE TABLE `obat_gfk` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kode` VARCHAR(30) NOT NULL UNIQUE,
  `nama_obat` VARCHAR(150) NOT NULL,
  `kategori` VARCHAR(80) NOT NULL,
  `stok_dinkes` INT NOT NULL DEFAULT 0,
  `satuan` VARCHAR(50) NOT NULL,
  `batch` VARCHAR(50) NOT NULL,
  `exp_date` DATE NOT NULL,
  `buffer_minimal` INT NOT NULL DEFAULT 1000,
  `status_stok` ENUM('Aman', 'Menipis', 'Kritis') NOT NULL DEFAULT 'Aman'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `obat_gfk` (`kode`, `nama_obat`, `kategori`, `stok_dinkes`, `satuan`, `batch`, `exp_date`, `buffer_minimal`, `status_stok`) VALUES
('FAR-001', 'Paracetamol Tab 500 mg', 'Analgesik & Antipiretik', 145000, 'Tablet', 'BCH-2025-081', '2027-08-30', 30000, 'Aman'),
('FAR-002', 'Amoxicillin Trihydrate 500 mg', 'Antibiotik', 85000, 'Kaplet', 'BCH-2025-119', '2027-03-15', 25000, 'Aman'),
('FAR-003', 'Oralit Serbuk 200 ml', 'Rehidrasi Cairan', 62000, 'Sachet', 'BCH-2025-204', '2028-01-10', 20000, 'Aman'),
('FAR-004', 'Vaksin DPT-HB-Hib (Pentabio)', 'Vaksin Imunisasi Dasar', 2400, 'Vial (5 dosis)', 'VAC-2026-012', '2026-12-15', 2000, 'Menipis'),
('FAR-005', 'Tablet Tambah Darah (Fe + Folat)', 'Suplemen Anemia Bumil', 190000, 'Tablet', 'BCH-2025-331', '2027-10-20', 40000, 'Aman'),
('FAR-006', 'Larutan Ringer Laktat (RL) 500 ml', 'Cairan Infus Emergensi', 3200, 'Kolf / Botol', 'BCH-2025-095', '2027-06-30', 5000, 'Menipis'),
('FAR-007', 'Insektisida Malathion 96% (Fogging DBD)', 'Vektor & P2P', 85, 'Drum (20 Liter)', 'PST-2025-004', '2028-05-18', 50, 'Aman'),
('FAR-008', 'Oseltamivir Cap 75 mg', 'Antivirus Influenza / ISPA', 1800, 'Kapsul', 'BCH-2024-811', '2026-12-30', 3000, 'Kritis');

-- 6. TABEL DISTRIBUSI OBAT KE PUSKESMAS (SBBK)
CREATE TABLE `distribusi` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `no_sbbk` VARCHAR(50) NOT NULL UNIQUE,
  `tanggal` DATE NOT NULL,
  `puskesmas_id` VARCHAR(20) NOT NULL,
  `item_obat` TEXT NOT NULL,
  `tujuan` VARCHAR(200) NOT NULL,
  `petugas_gfk` VARCHAR(100) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Terkirim & Diterima',
  FOREIGN KEY (`puskesmas_id`) REFERENCES `puskesmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `distribusi` (`no_sbbk`, `tanggal`, `puskesmas_id`, `item_obat`, `tujuan`, `petugas_gfk`, `status`) VALUES
('SBBK/GFK/XI/2026/081', '2026-11-18', 'PKM003', 'Paracetamol 500mg (15.000 tab), RL Infus (300 kolf), Abate (25 kg)', 'Antisipasi Peningkatan Kasus DBD', 'Apt. Wahyu Pratama, S.Farm', 'Terkirim & Diterima'),
('SBBK/GFK/XI/2026/082', '2026-11-20', 'PKM001', 'Tablet Tambah Darah (20.000 tab), Vaksin Pentabio (150 vial)', 'Alokasi Rutin Program Posyandu & Bumil', 'Apt. Wahyu Pratama, S.Farm', 'Terkirim & Diterima'),
('SBBK/GFK/XI/2026/083', '2026-11-24', 'PKM002', 'Amoxicillin 500mg (10.000 kaplet), Oralit (5.000 sachet)', 'Buffer Stock Triwulan IV', 'Apt. Wahyu Pratama, S.Farm', 'Dalam Perjalanan');
