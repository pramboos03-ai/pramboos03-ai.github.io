<?php
/**
 * KONFIGURASI DATABASE SIMKES DINAS KESEHATAN
 * Mendukung MySQL (XAMPP / cPanel / InfinityFree)
 * dan Otomatis Fallback SQLite untuk pengujian lokal instan tanpa setup DB.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi MySQL
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'simkes_dinkes';
$db_port = 3306;

$pdo = null;

// Coba koneksi ke MySQL
try {
    $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 2,
    ];
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (Throwable $e) {
    // Fallback otomatis ke SQLite lokal agar langsung bisa dites dengan `php -S localhost:8000`
    $sqlite_file = __DIR__ . '/database.sqlite';
    $is_new = !file_exists($sqlite_file) || filesize($sqlite_file) === 0;

    $pdo = new PDO("sqlite:" . $sqlite_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    if ($is_new) {
        init_sqlite_tables($pdo);
    }
}

function init_sqlite_tables($pdo) {
    $sql_file = __DIR__ . '/../database.sql';
    if (file_exists($sql_file)) {
        // Simple SQLite conversion
        $sql = file_get_contents($sql_file);
        $sql = preg_replace('/ENGINE=InnoDB.*?;\n?/i', ';', $sql);
        $sql = preg_replace('/SET FOREIGN_KEY_CHECKS.*?;\n?/i', '', $sql);
        $sql = str_replace('INT AUTO_INCREMENT PRIMARY KEY', 'INTEGER PRIMARY KEY AUTOINCREMENT', $sql);
        $sql = preg_replace('/ENUM\([^)]+\)/i', 'TEXT', $sql);
        try {
            $pdo->exec($sql);
        } catch (Throwable $err) {
            // Ignore minor DDL syntax mismatches
        }
    }
}

function check_auth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}
