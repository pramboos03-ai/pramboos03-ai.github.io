/**
 * GEOJSON BATAS WILAYAH KECAMATAN & TITIK FASILITAS KESEHATAN (PUSKESMAS)
 * Sistem Informasi Geografis (GIS) SIMKES Dinkes Daerah
 */

const KECAMATAN_GEOJSON = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "id": "PKM001",
        "kecamatan": "Kecamatan Sukamaju",
        "puskesmas": "Puskesmas Sukamaju",
        "tipe": "Rawat Inap",
        "akreditasi": "Paripurna",
        "lat": -6.852,
        "lng": 107.612,
        "populasi": 48500,
        "penyakit_dominan": "Demam Berdarah Dengue (DBD)",
        "kasus": 28,
        "kematian": 0,
        "stunting_pct": 8.4,
        "status_alert": "Waspada",
        "catatan": "Peningkatan kasus di Desa Sukaresmi RT 03/04. Fogging fokus dijadwalkan."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.595, -6.835],
          [107.630, -6.838],
          [107.635, -6.868],
          [107.605, -6.872],
          [107.590, -6.855],
          [107.595, -6.835]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM002",
        "kecamatan": "Kecamatan Mentari",
        "puskesmas": "Puskesmas Mentari Indah",
        "tipe": "Non Rawat Inap",
        "akreditasi": "Paripurna",
        "lat": -6.865,
        "lng": 107.658,
        "populasi": 36200,
        "penyakit_dominan": "ISPA Akut",
        "kasus": 142,
        "kematian": 0,
        "stunting_pct": 8.1,
        "status_alert": "Normal",
        "catatan": "Kondisi terkendali, dominan ISPA ringan musiman."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.635, -6.840],
          [107.675, -6.845],
          [107.685, -6.885],
          [107.640, -6.880],
          [107.635, -6.840]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM003",
        "kecamatan": "Kecamatan Cibadak",
        "puskesmas": "Puskesmas Cibadak Sehat",
        "tipe": "Rawat Inap",
        "akreditasi": "Utama",
        "lat": -6.882,
        "lng": 107.582,
        "populasi": 54300,
        "penyakit_dominan": "Demam Berdarah Dengue (DBD)",
        "kasus": 34,
        "kematian": 1,
        "stunting_pct": 13.2,
        "status_alert": "Alert KLB",
        "catatan": "MELEBIHI AMBANG EPIDEMIK. 1 Kematian anak balita. Tim Gerak Cepat (TGC) Dinkes diterjunkan."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.560, -6.865],
          [107.605, -6.870],
          [107.610, -6.905],
          [107.565, -6.910],
          [107.550, -6.885],
          [107.560, -6.865]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM004",
        "kecamatan": "Kecamatan Harapan",
        "puskesmas": "Puskesmas Harapan Jaya",
        "tipe": "Non Rawat Inap",
        "akreditasi": "Utama",
        "lat": -6.908,
        "lng": 107.648,
        "populasi": 29800,
        "penyakit_dominan": "Diare Akut",
        "kasus": 45,
        "kematian": 0,
        "stunting_pct": 9.0,
        "status_alert": "Waspada",
        "catatan": "Kluster diare di RW 04 bantaran kali. Kaporitisasi sumur warga dilakukan."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.630, -6.885],
          [107.680, -6.890],
          [107.670, -6.930],
          [107.625, -6.925],
          [107.630, -6.885]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM005",
        "kecamatan": "Kecamatan Danau",
        "puskesmas": "Puskesmas Danau Sari",
        "tipe": "Rawat Inap",
        "akreditasi": "Madya",
        "lat": -6.928,
        "lng": 107.592,
        "populasi": 41200,
        "penyakit_dominan": "Tuberkulosis (TBC)",
        "kasus": 18,
        "kematian": 0,
        "stunting_pct": 13.5,
        "status_alert": "Normal",
        "catatan": "Kondisi stabil, skrining kontak erat TBC aktif."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.565, -6.910],
          [107.615, -6.910],
          [107.620, -6.955],
          [107.570, -6.950],
          [107.565, -6.910]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM006",
        "kecamatan": "Kecamatan Gunung",
        "puskesmas": "Puskesmas Gunung Kencana",
        "tipe": "Non Rawat Inap",
        "akreditasi": "Madya",
        "lat": -6.818,
        "lng": 107.572,
        "populasi": 25400,
        "penyakit_dominan": "ISPA & Rematik",
        "kasus": 52,
        "kematian": 0,
        "stunting_pct": 13.9,
        "status_alert": "Normal",
        "catatan": "Wilayah dataran tinggi, kasus menular relatif rendah."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.550, -6.795],
          [107.600, -6.800],
          [107.595, -6.840],
          [107.545, -6.835],
          [107.550, -6.795]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM007",
        "kecamatan": "Kecamatan Karang",
        "puskesmas": "Puskesmas Karang Sari",
        "tipe": "Rawat Inap",
        "akreditasi": "Utama",
        "lat": -6.942,
        "lng": 107.642,
        "populasi": 47600,
        "penyakit_dominan": "Hipertensi & DM",
        "kasus": 188,
        "kematian": 0,
        "stunting_pct": 10.5,
        "status_alert": "Normal",
        "catatan": "Kewaspadaan menular aman, program Posbindu PTM berjalan baik."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.620, -6.925],
          [107.670, -6.930],
          [107.665, -6.970],
          [107.615, -6.965],
          [107.620, -6.925]
        ]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "id": "PKM008",
        "kecamatan": "Kecamatan Pesisir",
        "puskesmas": "Puskesmas Pesisir Raya",
        "tipe": "Non Rawat Inap",
        "akreditasi": "Paripurna",
        "lat": -6.892,
        "lng": 107.522,
        "populasi": 33900,
        "penyakit_dominan": "Suspek Campak & Diare",
        "kasus": 7,
        "kematian": 0,
        "stunting_pct": 11.1,
        "status_alert": "Waspada",
        "catatan": "Ditemukan 7 anak suspek campak. Pelacakan imunisasi sedang berlangsung."
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [107.495, -6.870],
          [107.550, -6.875],
          [107.555, -6.920],
          [107.500, -6.915],
          [107.495, -6.870]
        ]]
      }
    }
  ]
};
