# SIMKES DINKES - Sistem Informasi Manajemen Kesehatan Dinas Kesehatan Daerah

Sistem Informasi Manajemen Kesehatan (SIMKES) berbasis web yang dirancang khusus untuk **Dinas Kesehatan Daerah (Tingkat Kabupaten / Kota)**. Aplikasi ini berfungsi sebagai pusat kendali (*command center*) untuk memantau Unit Pelaksana Teknis (UPT) Puskesmas, sistem kewaspadaan dini wabah penyakit (EWARS / SKDR), pemantauan stunting & kesehatan balita, serta logistik obat Gudang Farmasi Kabupaten (GFK).

Tersedia dalam **2 Mode**:
1. **Interactive Static Web Demo (Siap Hosting Gratis di GitHub Pages)**: Berjalan 100% di browser tanpa perlu sewa server, dengan data tersimpan di LocalStorage, grafik interaktif Chart.js, ekspor CSV, dan cetak laporan PDF resmi ber-KOP Dinas.
2. **Native PHP & MySQL Version**: Terletak di folder `php_version/`, siap dipasang di XAMPP lokal atau hosting PHP gratis (seperti InfinityFree / cPanel).

---

## 🌟 Modul & Fitur Utama

1. **Dashboard Eksekutif & Surveilans Wilayah**
   - Indikator utama kesehatan daerah (Total Puskesmas terakreditasi, jumlah dokter/perawat/bidan, total kasus kesakitan, dan ketersediaan obat).
   - Grafik tren mingguan kasus penyakit menular potensi KLB (Demam Berdarah Dengue / DBD, ISPA, Diare).
   - Matriks Sebaran Peta Status Kewaspadaan Dini (Normal, Waspada, Alert KLB) per wilayah kecamatan.
   - Peringkat 10 Besar Penyakit Terbanyak di Daerah beserta tren perubahannya.

2. **Manajemen Puskesmas & Tenaga Kesehatan (SDMK)**
   - Pendataan UPT Puskesmas (Rawat Inap & Non-Rawat Inap) se-kabupaten.
   - Status akreditasi (Paripurna, Utama, Madya), wilayah kerja desa binaan, dan jumlah populasi penduduk yang dilayani.
   - Pendataan dokter, perawat, dan bidan pada masing-masing faskes.
   - CRUD data Puskesmas (Tambah, Edit, Hapus, Pencarian instan & Filter akreditasi).

3. **Surveilans Epidemiologi & SKDR (P2P)**
   - Input laporan mingguan/harian penyakit menular dari Puskesmas.
   - Sistem deteksi sinyal waspada & batas ambang Kejadian Luar Biasa (KLB).
   - Banner peringatan dini otomatis jika ada kecamatan dengan status **Alert KLB**.
   - Dokumentasi respon tindakan lapangan dan Penyelidikan Epidemiologi (PE).

4. **Kesehatan Masyarakat & Program Stunting (Kesmas)**
   - Rekapitulasi status gizi balita: total balita ditimbang, balita stunting (pendek), dan balita wasting (gizi kurang).
   - Kalkulasi otomatis persentase prevalensi stunting per wilayah kerja Puskesmas dibandingkan dengan target batas toleransi daerah (&le; 11.5%).
   - Pemantauan capaian Imunisasi Dasar Lengkap (IDL).

5. **Gudang Farmasi Kabupaten (GFK) & Logistik Obat**
   - Monitoring stok obat penting, cairan infus emergensi, insektisida DBD, dan vaksin dasar.
   - Deteksi otomatis status stok: **Aman**, **Menipis**, atau **Kritis**.
   - Peringatan dini tanggal kadaluarsa obat (*expiry date alert*).
   - Penerbitan Surat Bukti Barang Keluar (SBBK) untuk alokasi distribusi obat ke Puskesmas.

6. **Laporan Resmi Ber-KOP Dinas Kesehatan & Ekspor Data**
   - Format cetak resmi ber-KOP Surat Pemerintah Daerah & Dinas Kesehatan, lengkap dengan tanda tangan Kepala Dinas Kesehatan.
   - Format Print-ready untuk cetak langsung ke kertas atau **Simpan ke PDF**.
   - Fitur **Ekspor Data ke File CSV / Excel** dalam satu klik.

7. **Multi-Role Access Simulation**
   - Kepala Dinas / Super Admin
   - Bidang P2P (Wabah & Surveilans)
   - Bidang Kesmas (Gizi & Stunting)
   - Bidang Farmasi & Alkes (GFK)
   - Petugas UPT Puskesmas

---

## 🚀 Panduan Hosting Gratis di GitHub Pages (Langkah Demi Langkah)

Anda dapat mengaktifkan demo website ini secara **100% GRATIS** melalui GitHub Pages dalam waktu kurang dari 3 menit:

### Langkah 1: Buat Repositori Baru di GitHub
1. Masuk ke akun GitHub Anda di [https://github.com](https://github.com).
2. Klik tombol **New** (Buat repositori baru).
3. Beri nama repositori, misalnya: `simkes-dinkes` atau `sistem-informasi-kesehatan`.
4. Pilih **Public**, lalu klik **Create repository**.

### Langkah 2: Upload File Proyek
Anda bisa mengupload langsung lewat Git Bash / Terminal atau via web GitHub:

**Cara Lewat Terminal (Git):**
```bash
cd simkes-dinkes
git init
git add .
git commit -m "Initial release SIMKES Dinkes Web Demo"
git branch -M main
git remote add origin https://github.com/USERNAME-ANDA/NAMA-REPO-ANDA.git
git push -u origin main
```

**Cara Lewat Web GitHub (Drag & Drop):**
1. Buka halaman repository baru Anda di browser.
2. Klik **uploading an existing file**.
3. Tarik semua isi dalam folder `simkes-dinkes/` (`index.html`, folder `css`, folder `js`, dll).
4. Klik **Commit changes**.

### Langkah 3: Aktifkan Fitur GitHub Pages
1. Di repository GitHub Anda, klik menu **Settings** (tab kanan atas).
2. Di menu sebelah kiri, klik **Pages**.
3. Di bagian **Build and deployment** -> **Branch**:
   - Pilih branch: **`main`**
   - Pilih folder: **`/(root)`**
4. Klik tombol **Save**.
5. Tunggu sekitar 1 menit. GitHub akan menampilkan link website Anda, contohnya:  
   👉 `https://USERNAME-ANDA.github.io/simkes-dinkes/`

Sekarang demo aplikasi SIMKES Dinas Kesehatan sudah **LIVE di internet dan dapat diakses siapa saja secara gratis!**

---

## 💻 Menjalankan Versi PHP & MySQL

Bagi Anda yang ingin menjalankan versi backend PHP & database MySQL:

### A. Jalankan Secara Lokal (XAMPP / Laragon)
1. Salin folder `simkes-dinkes/php_version` ke dalam folder `htdocs` (di XAMPP: `C:\xampp\htdocs\simkes_dinkes`).
2. Buka browser dan buka phpMyAdmin (`http://localhost/phpmyadmin`).
3. Buat database baru dengan nama `simkes_dinkes`.
4. Import file `php_version/database.sql` ke database tersebut.
5. Sesuaikan konfigurasi di `php_version/config/koneksi.php` jika password database Anda berbeda.
6. Buka di browser: `http://localhost/simkes_dinkes/`

### B. Uji Coba Cepat Tanpa Setup DB (Built-in Server)
Folder `php_version/` dilengkapi otomatis dengan fitur SQLite fallback. Anda bisa langsung menjalankannya lewat terminal:
```bash
cd simkes-dinkes/php_version
php -S localhost:8000
```
Lalu buka di browser: `http://localhost:8000`

### C. Akun Login Default Versi PHP
- **Username**: `kadis`
- **Password**: `admin123`

---

## 📁 Struktur Folder Proyek

```text
simkes-dinkes/
├── index.html              # Main Demo Application (GitHub Pages Ready)
├── README.md               # Dokumentasi lengkap & panduan hosting
├── css/
│   └── style.css           # Custom styling Dinkes, badges, print stylesheet
├── js/
│   ├── data.js             # Data master default (Puskesmas, Penyakit, Stunting, GFK)
│   └── app.js              # State management, router, Chart.js, modal CRUD & cetak
└── php_version/            # Versi Backend Lengkap PHP & MySQL
    ├── database.sql        # Skrip struktur tabel & seed data awal
    ├── index.php           # Entry point & auth redirection
    ├── login.php           # Halaman otentikasi multi-role
    ├── logout.php          # Proses keluar sesi
    ├── dashboard.php       # Dashboard eksekutif berbasis PHP & DB
    ├── puskesmas.php       # Manajemen CRUD Puskesmas & Nakes
    ├── surveilans.php      # Laporan surveilans & alert SKDR
    ├── farmasi.php         # Gudang farmasi & distribusi SBBK
    ├── laporan.php         # Cetak laporan resmi ber-kop Dinas
    ├── config/
    │   └── koneksi.php     # Koneksi PDO MySQL & Fallback SQLite
    └── includes/
        ├── header.php
        ├── sidebar.php
        └── footer.php
```

---

## 📜 Lisensi & Penggunaan
Sistem ini dibuat untuk keperluan demonstrasi sistem informasi kesehatan daerah, portofolio, dan implementasi instansi kesehatan. Bebas dikembangkan dan dimodifikasi sesuai kebutuhan daerah Anda.
