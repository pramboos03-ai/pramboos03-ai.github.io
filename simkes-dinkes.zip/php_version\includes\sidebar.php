<?php
$current_page = basename($_SERVER['PHP_SELF']);
$user_role = $_SESSION['user_role'] ?? 'superadmin';
$user_name = $_SESSION['user_name'] ?? 'dr. Rahmat Hidayat';
?>
<aside id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon">
      <i class="bi bi-hospital"></i>
    </div>
    <div>
      <div class="brand-title">SIMKES DINKES</div>
      <div class="brand-subtitle">PHP & MySQL Backend</div>
    </div>
  </div>

  <div class="sidebar-nav">
    <div class="nav-section-title">Menu Utama</div>
    <a href="dashboard.php" class="nav-link-custom <?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
      <i class="bi bi-grid-1x2-fill"></i>
      <span>Dashboard Eksekutif</span>
    </a>
    <a href="puskesmas.php" class="nav-link-custom <?= ($current_page == 'puskesmas.php') ? 'active' : ''; ?>">
      <i class="bi bi-hospital-fill"></i>
      <span>Puskesmas & Faskes</span>
    </a>

    <div class="nav-section-title">Program & Bidang</div>
    <a href="surveilans.php" class="nav-link-custom <?= ($current_page == 'surveilans.php') ? 'active' : ''; ?>">
      <i class="bi bi-activity"></i>
      <span>Surveilans & SKDR (P2P)</span>
    </a>
    <a href="pedoman.php" class="nav-link-custom <?= ($current_page == 'pedoman.php') ? 'active' : ''; ?>">
      <i class="bi bi-shield-shaded text-success"></i>
      <span>SOP Penanganan & Cegah</span>
    </a>
    <a href="farmasi.php" class="nav-link-custom <?= ($current_page == 'farmasi.php') ? 'active' : ''; ?>">
      <i class="bi bi-capsule-pill"></i>
      <span>Gudang Farmasi (GFK)</span>
    </a>

    <div class="nav-section-title">Output & Administrasi</div>
    <a href="laporan.php" class="nav-link-custom <?= ($current_page == 'laporan.php') ? 'active' : ''; ?>">
      <i class="bi bi-file-earmark-bar-graph-fill"></i>
      <span>Laporan & Cetak Resmi</span>
    </a>
  </div>

  <div class="p-3 border-top border-secondary border-opacity-25 small text-secondary">
    <div class="d-flex align-items-center justify-content-between mb-2">
      <span class="text-white fw-semibold"><i class="bi bi-person-circle"></i> <?= htmlspecialchars($user_name); ?></span>
    </div>
    <a href="logout.php" class="btn btn-sm btn-outline-danger w-100"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
  </div>
</aside>

<main id="main-content">
  <header class="topbar">
    <div class="d-flex align-items-center gap-3">
      <span class="fw-bold text-dark"><i class="bi bi-shield-check text-success me-1"></i> Dinas Kesehatan Daerah</span>
      <span class="badge bg-primary-subtle text-primary border">PHP & MySQL Native</span>
    </div>
    <div class="d-flex align-items-center gap-3">
      <a href="../index.html" class="btn btn-sm btn-outline-success"><i class="bi bi-globe me-1"></i> Buka Versi GitHub Pages</a>
    </div>
  </header>
  <div class="p-3 p-md-4">
