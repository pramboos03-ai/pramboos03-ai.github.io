<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Manajemen Puskesmas & Faskes';
$message = '';

// Handle Tambah / Edit / Hapus
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $id = trim($_POST['id']);
        $nama = trim($_POST['nama']);
        $kecamatan = trim($_POST['kecamatan']);
        $tipe = $_POST['tipe'];
        $akreditasi = $_POST['akreditasi'];
        $kepala = trim($_POST['kepala']);
        $kontak = trim($_POST['kontak']);
        $jml_dokter = (int)$_POST['jml_dokter'];
        $jml_perawat = (int)$_POST['jml_perawat'];
        $jml_bidan = (int)$_POST['jml_bidan'];
        $wilayah_desa = (int)$_POST['wilayah_desa'];
        $populasi = (int)$_POST['populasi'];

        try {
            $stmt = $pdo->prepare("INSERT INTO puskesmas (id, nama, kecamatan, tipe, akreditasi, kepala, kontak, jml_dokter, jml_perawat, jml_bidan, wilayah_desa, populasi, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Aktif')");
            $stmt->execute([$id, $nama, $kecamatan, $tipe, $akreditasi, $kepala, $kontak, $jml_dokter, $jml_perawat, $jml_bidan, $wilayah_desa, $populasi]);
            $message = 'Puskesmas berhasil ditambahkan!';
        } catch (Throwable $e) {
            $message = 'Gagal menambahkan: ' . $e->getMessage();
        }
    } elseif ($action === 'delete') {
        $del_id = $_POST['id'] ?? '';
        if ($del_id) {
            $stmt = $pdo->prepare("DELETE FROM puskesmas WHERE id = ?");
            $stmt->execute([$del_id]);
            $message = 'Puskesmas berhasil dihapus.';
        }
    }
}

$stmt = $pdo->query("SELECT * FROM puskesmas ORDER BY id ASC");
$puskesmas = $stmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800">Manajemen Puskesmas & Faskes</h3>
    <p class="text-muted mb-0">Pendataan UPT Puskesmas dan Tenaga Medis (PHP & MySQL)</p>
  </div>
  <div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah"><i class="bi bi-plus-circle me-1"></i> Tambah Puskesmas</button>
  </div>
</div>

<?php if ($message): ?>
  <div class="alert alert-info alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($message); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<div class="card-dinkes">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-dinkes mb-0">
        <thead>
          <tr>
            <th>Kode & Nama</th>
            <th>Kecamatan</th>
            <th>Tipe & Akreditasi</th>
            <th>Kepala Puskesmas</th>
            <th>SDM Kesehatan</th>
            <th>Populasi</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($puskesmas as $p): ?>
            <tr>
              <td>
                <span class="badge bg-secondary-subtle text-secondary font-monospace"><?= htmlspecialchars($p['id']); ?></span>
                <div class="fw-bold mt-1"><?= htmlspecialchars($p['nama']); ?></div>
                <small class="text-muted"><?= htmlspecialchars($p['kontak']); ?></small>
              </td>
              <td><?= htmlspecialchars($p['kecamatan']); ?></td>
              <td>
                <span class="badge bg-light text-dark border"><?= htmlspecialchars($p['tipe']); ?></span>
                <div class="mt-1">
                  <span class="badge bg-info-subtle text-info fw-bold"><?= htmlspecialchars($p['akreditasi']); ?></span>
                </div>
              </td>
              <td><?= htmlspecialchars($p['kepala']); ?></td>
              <td>
                <div class="small">
                  <div><strong><?= $p['jml_dokter']; ?></strong> Dokter</div>
                  <div class="text-muted"><?= $p['jml_perawat']; ?> Perawat &bull; <?= $p['jml_bidan']; ?> Bidan</div>
                </div>
              </td>
              <td><?= number_format($p['populasi'], 0, ',', '.'); ?> Jiwa</td>
              <td class="text-end">
                <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus data puskesmas ini?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= htmlspecialchars($p['id']); ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Puskesmas -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Tambah Puskesmas Baru</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="action" value="create">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label small fw-bold">Kode Faskes</label>
              <input type="text" name="id" class="form-control" value="PKM00<?= count($puskesmas)+1; ?>" required>
            </div>
            <div class="col-md-8">
              <label class="form-label small fw-bold">Nama Puskesmas</label>
              <input type="text" name="nama" class="form-control" placeholder="Puskesmas ..." required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Kecamatan</label>
              <input type="text" name="kecamatan" class="form-control" placeholder="Kec. ..." required>
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-bold">Tipe</label>
              <select name="tipe" class="form-select">
                <option value="Rawat Inap">Rawat Inap</option>
                <option value="Non Rawat Inap">Non Rawat Inap</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-bold">Akreditasi</label>
              <select name="akreditasi" class="form-select">
                <option value="Paripurna">Paripurna</option>
                <option value="Utama">Utama</option>
                <option value="Madya">Madya</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Kepala Puskesmas</label>
              <input type="text" name="kepala" class="form-control" placeholder="dr. ..." required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Kontak</label>
              <input type="text" name="kontak" class="form-control" placeholder="0812-xxxx-xxxx" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Jml Dokter</label>
              <input type="number" name="jml_dokter" class="form-control" value="4" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Jml Perawat</label>
              <input type="number" name="jml_perawat" class="form-control" value="12" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-bold">Jml Bidan</label>
              <input type="number" name="jml_bidan" class="form-control" value="10" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Desa Binaan</label>
              <input type="number" name="wilayah_desa" class="form-control" value="5" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Populasi (Jiwa)</label>
              <input type="number" name="populasi" class="form-control" value="35000" required>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan Puskesmas</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
