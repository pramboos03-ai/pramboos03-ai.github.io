<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Dashboard Eksekutif Dinkes';

// Ambil data statistik dari DB
$pkm_count = 0;
$total_dokter = 0;
$total_nakes = 0;
$kasus_count = 0;
$alert_count = 0;
$obat_count = 0;

try {
    $stmt = $pdo->query("SELECT COUNT(*) as c, SUM(jml_dokter) as d, SUM(jml_dokter + jml_perawat + jml_bidan) as n FROM puskesmas");
    $r = $stmt->fetch();
    $pkm_count = $r['c'] ?? 0;
    $total_dokter = $r['d'] ?? 0;
    $total_nakes = $r['n'] ?? 0;

    $stmt2 = $pdo->query("SELECT COUNT(*) as c, SUM(jumlah_kasus) as k, SUM(CASE WHEN status_alert != 'Normal' THEN 1 ELSE 0 END) as a FROM surveilans");
    $r2 = $stmt2->fetch();
    $kasus_count = $r2['k'] ?? 0;
    $alert_count = $r2['a'] ?? 0;

    $stmt3 = $pdo->query("SELECT COUNT(*) as c FROM obat_gfk");
    $obat_count = $stmt3->fetch()['c'] ?? 0;

    $stmt4 = $pdo->query("SELECT s.*, p.nama as puskesmas_nama FROM surveilans s JOIN puskesmas p ON s.puskesmas_id = p.id ORDER BY s.tanggal DESC LIMIT 5");
    $recent_surveilans = $stmt4->fetchAll();

    $stmt5 = $pdo->query("SELECT * FROM puskesmas ORDER BY id ASC");
    $puskesmas_list = $stmt5->fetchAll();
} catch (Throwable $e) {
    $recent_surveilans = [];
    $puskesmas_list = [];
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800">Dashboard Eksekutif Dinkes</h3>
    <p class="text-muted mb-0"><i class="bi bi-geo-alt-fill text-danger me-1"></i> Dinas Kesehatan Kabupaten Sehat Sejahtera &bull; Database Aktif</p>
  </div>
  <div>
    <a href="laporan.php" class="btn btn-primary btn-sm"><i class="bi bi-printer me-1"></i> Cetak Laporan Resmi</a>
  </div>
</div>

<!-- STAT CARDS -->
<div class="row g-3 mb-4">
  <div class="col-12 col-sm-6 col-xl-3">
    <div class="stat-card">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <span class="text-muted small fw-semibold">FASILITAS KESEHATAN</span>
          <h3 class="fw-bold my-1"><?= $pkm_count; ?> Puskesmas</h3>
          <span class="trend-badge bg-success-subtle text-success"><i class="bi bi-check2-circle"></i> Terintegrasi</span>
        </div>
        <div class="stat-icon bg-teal text-white" style="background:#0d9488">
          <i class="bi bi-hospital"></i>
        </div>
      </div>
      <div class="small text-muted mt-2 pt-2 border-top">
        <strong><?= $total_dokter; ?></strong> Dokter &bull; <strong><?= $total_nakes; ?></strong> Total Nakes
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-xl-3">
    <div class="stat-card">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <span class="text-muted small fw-semibold">SURVEILANS & SKDR</span>
          <h3 class="fw-bold my-1"><?= $kasus_count; ?> Kasus</h3>
          <span class="trend-badge <?= ($alert_count > 0) ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'; ?>">
            <i class="bi bi-exclamation-triangle-fill"></i> <?= $alert_count; ?> Sinyal Waspada
          </span>
        </div>
        <div class="stat-icon bg-danger text-white">
          <i class="bi bi-activity"></i>
        </div>
      </div>
      <div class="small text-muted mt-2 pt-2 border-top">
        Sistem Peringatan Dini KLB
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-xl-3">
    <div class="stat-card">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <span class="text-muted small fw-semibold">PREVALENSI STUNTING</span>
          <h3 class="fw-bold my-1">10.8%</h3>
          <span class="trend-badge bg-primary-subtle text-primary"><i class="bi bi-shield-check"></i> Target: &le; 11.5%</span>
        </div>
        <div class="stat-icon bg-info text-white">
          <i class="bi bi-heart-pulse"></i>
        </div>
      </div>
      <div class="small text-muted mt-2 pt-2 border-top">
        Capaian Intervensi Gizi Terpadu
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-xl-3">
    <div class="stat-card">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <span class="text-muted small fw-semibold">LOGISTIK FARMASI GFK</span>
          <h3 class="fw-bold my-1"><?= $obat_count; ?> Item</h3>
          <span class="trend-badge bg-success-subtle text-success"><i class="bi bi-capsule"></i> Buffer Stock Siap</span>
        </div>
        <div class="stat-icon bg-warning text-white">
          <i class="bi bi-box-seam"></i>
        </div>
      </div>
      <div class="small text-muted mt-2 pt-2 border-top">
        Distribusi Rutin ke Puskesmas
      </div>
    </div>
  </div>
</div>

<!-- LEAFLET GIS MAP ROW -->
<div class="card-dinkes mb-4">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
      <i class="bi bi-map-fill text-danger"></i>
      <span class="fw-bold">Peta GIS Kewaspadaan Dini & KLB Wilayah (Leaflet GeoJSON)</span>
    </div>
    <div class="d-flex gap-2">
      <span class="badge bg-danger-subtle text-danger"><i class="bi bi-circle-fill"></i> Alert KLB (Merah)</span>
      <span class="badge bg-warning-subtle text-warning text-dark"><i class="bi bi-circle-fill"></i> Waspada (Kuning)</span>
      <span class="badge bg-success-subtle text-success"><i class="bi bi-circle-fill"></i> Normal (Hijau)</span>
    </div>
  </div>
  <div class="card-body p-2">
    <div id="gis-map-dashboard" style="height: 420px; width: 100%; border-radius: 10px;"></div>
    <div class="d-flex justify-content-between align-items-center mt-2 px-2 small text-muted">
      <span><i class="bi bi-cursor-fill text-primary"></i> Arahkan kursor atau klik poligon kecamatan untuk melihat data epidemiologi & Puskesmas pembina</span>
      <span>Peta Interaktif OpenStreetMap & GeoJSON Terpadu</span>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  if (typeof L !== 'undefined' && typeof KECAMATAN_GEOJSON !== 'undefined') {
    var map = L.map('gis-map-dashboard', {
      center: [-6.885, 107.595],
      zoom: 12,
      scrollWheelZoom: false
    });

    var googleStreets = L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
      attribution: '&copy; Google Maps',
      maxZoom: 20
    });

    var googleHybrid = L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
      attribution: '&copy; Google Maps Satellite',
      maxZoom: 20
    });

    var googleTerrain = L.tileLayer('https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}', {
      attribution: '&copy; Google Maps Terrain',
      maxZoom: 20
    });

    var osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap',
      maxZoom: 19
    });

    googleStreets.addTo(map);

    var baseMaps = {
      "🗺️ Google Maps (Jalan)": googleStreets,
      "🛰️ Google Satelit (Hybrid)": googleHybrid,
      "⛰️ Google Terrain": googleTerrain,
      "🌐 OpenStreetMap": osm
    };

    function getStyle(f) {
      var a = f.properties.status_alert;
      if (a === 'Alert KLB') {
        return { fillColor: '#ef4444', color: '#b91c1c', weight: 3, fillOpacity: 0.65 };
      } else if (a === 'Waspada') {
        return { fillColor: '#f59e0b', color: '#d97706', weight: 2, fillOpacity: 0.50 };
      }
      return { fillColor: '#10b981', color: '#059669', weight: 1.5, fillOpacity: 0.35 };
    }

    L.geoJSON(KECAMATAN_GEOJSON, {
      style: getStyle,
      onEachFeature: function(feature, layer) {
        var p = feature.properties;
        layer.bindTooltip('<strong>' + p.kecamatan + '</strong><br>Status: ' + p.status_alert, { sticky: true });
        layer.bindPopup(
          '<div style="min-width: 220px;">' +
          '<h6 class="fw-bold mb-1">' + p.kecamatan + '</h6>' +
          '<div class="small text-muted mb-2">' + p.puskesmas + ' (' + p.akreditasi + ')</div>' +
          '<div class="border-top pt-2 small">' +
          '<div><strong>Penyakit:</strong> ' + p.penyakit_dominan + '</div>' +
          '<div class="text-danger fw-bold">Kasus: ' + p.kasus + (p.kematian > 0 ? ' (' + p.kematian + ' Meninggal)' : '') + '</div>' +
          '<div><strong>Stunting:</strong> ' + p.stunting_pct + '%</div>' +
          '<div class="mt-1 text-muted" style="font-size:11px;"><em>' + p.catatan + '</em></div>' +
          '</div></div>'
        );
        if (p.lat && p.lng) {
          L.marker([p.lat, p.lng]).addTo(map).bindPopup('<strong>' + p.puskesmas + '</strong><br>' + p.kecamatan);
        }
      }
    }).addTo(map);

    L.control.layers(baseMaps, null, { position: 'topright' }).addTo(map);
  }
});
</script>

<!-- SURVEILANS RECENT TABLE -->
<div class="card-dinkes">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
      <i class="bi bi-activity text-danger"></i>
      <span class="fw-bold">Laporan Kasus Penyakit Terkini (SKDR)</span>
    </div>
    <a href="surveilans.php" class="btn btn-sm btn-link text-decoration-none">Kelola Seluruh Surveilans &rarr;</a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-dinkes mb-0">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Puskesmas</th>
            <th>Penyakit</th>
            <th class="text-center">Kasus / Meninggal</th>
            <th>Status Alert</th>
            <th>Catatan Tindakan</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent_surveilans)): ?>
            <tr><td colspan="6" class="text-center py-3 text-muted">Belum ada data surveilans.</td></tr>
          <?php else: ?>
            <?php foreach ($recent_surveilans as $s): ?>
              <tr>
                <td><?= htmlspecialchars($s['tanggal']); ?></td>
                <td class="fw-semibold"><?= htmlspecialchars($s['puskesmas_nama']); ?></td>
                <td class="fw-bold text-slate-800"><?= htmlspecialchars($s['penyakit']); ?></td>
                <td class="text-center">
                  <span class="badge bg-danger"><?= $s['jumlah_kasus']; ?></span>
                  <?php if ($s['meninggal'] > 0): ?>
                    <span class="badge bg-dark ms-1"><?= $s['meninggal']; ?> Meninggal</span>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge <?= ($s['status_alert'] === 'Alert KLB') ? 'badge-alert-klb' : (($s['status_alert'] === 'Waspada') ? 'badge-waspada' : 'badge-normal'); ?>">
                    <?= htmlspecialchars($s['status_alert']); ?>
                  </span>
                </td>
                <td><small class="text-secondary"><?= htmlspecialchars($s['catatan'] ?? '-'); ?></small></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
