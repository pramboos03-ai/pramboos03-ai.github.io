<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Gudang Farmasi Kabupaten (GFK)';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create_obat') {
        $kode = trim($_POST['kode']);
        $nama = trim($_POST['nama_obat']);
        $kategori = trim($_POST['kategori']);
        $stok = (int)$_POST['stok_dinkes'];
        $satuan = trim($_POST['satuan']);
        $batch = trim($_POST['batch']);
        $exp_date = $_POST['exp_date'];
        $buffer = (int)$_POST['buffer_minimal'];

        $status = 'Aman';
        if ($stok < $buffer * 0.5) $status = 'Kritis';
        elseif ($stok <= $buffer) $status = 'Menipis';

        try {
            $stmt = $pdo->prepare("INSERT INTO obat_gfk (kode, nama_obat, kategori, stok_dinkes, satuan, batch, exp_date, buffer_minimal, status_stok) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$kode, $nama, $kategori, $stok, $satuan, $batch, $exp_date, $buffer, $status]);
            $message = 'Item obat berhasil ditambahkan!';
        } catch (Throwable $e) {
            $message = 'Gagal menambahkan obat: ' . $e->getMessage();
        }
    } elseif ($action === 'delete_obat') {
        $del_id = $_POST['id'] ?? '';
        if ($del_id) {
            $stmt = $pdo->prepare("DELETE FROM obat_gfk WHERE id = ?");
            $stmt->execute([$del_id]);
            $message = 'Item obat berhasil dihapus.';
        }
    }
}

$stmt_obat = $pdo->query("SELECT * FROM obat_gfk ORDER BY id DESC");
$obat_list = $stmt_obat->fetchAll();

$stmt_dst = $pdo->query("SELECT d.*, p.nama as puskesmas_nama FROM distribusi d JOIN puskesmas p ON d.puskesmas_id = p.id ORDER BY d.id DESC");
$distribusi_list = $stmt_dst->fetchAll();

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800">Gudang Farmasi Kabupaten (GFK)</h3>
    <p class="text-muted mb-0">Logistik Obat Esensial, Buffer Stock & Distribusi (SBBK)</p>
  </div>
  <div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalObat"><i class="bi bi-plus-circle me-1"></i> Tambah Obat GFK</button>
  </div>
</div>

<?php if ($message): ?>
  <div class="alert alert-info alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($message); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<div class="card-dinkes">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-dinkes mb-0">
        <thead>
          <tr>
            <th>Kode & Nama Obat</th>
            <th>Kategori</th>
            <th class="text-end">Stok Tersedia</th>
            <th>Satuan</th>
            <th>Batch & Kadaluarsa</th>
            <th>Status Buffer</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($obat_list as $o): ?>
            <tr>
              <td>
                <span class="font-monospace small text-muted"><?= htmlspecialchars($o['kode']); ?></span>
                <div class="fw-bold"><?= htmlspecialchars($o['nama_obat']); ?></div>
              </td>
              <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($o['kategori']); ?></span></td>
              <td class="text-end fw-bold"><?= number_format($o['stok_dinkes'], 0, ',', '.'); ?></td>
              <td><?= htmlspecialchars($o['satuan']); ?></td>
              <td>
                <div><small class="fw-semibold"><?= htmlspecialchars($o['batch']); ?></small></div>
                <small class="text-muted"><i class="bi bi-calendar-event"></i> Exp: <?= htmlspecialchars($o['exp_date']); ?></small>
              </td>
              <td>
                <span class="badge <?= ($o['status_stok'] === 'Aman') ? 'bg-success' : (($o['status_stok'] === 'Menipis') ? 'bg-warning text-dark' : 'bg-danger'); ?>">
                  <?= htmlspecialchars($o['status_stok']); ?>
                </span>
              </td>
              <td class="text-end">
                <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus obat ini?');">
                  <input type="hidden" name="action" value="delete_obat">
                  <input type="hidden" name="id" value="<?= $o['id']; ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Obat -->
<div class="modal fade" id="modalObat" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Tambah Obat / Vaksin ke GFK</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="action" value="create_obat">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label small fw-bold">Kode Obat</label>
              <input type="text" name="kode" class="form-control" value="FAR-00<?= count($obat_list)+1; ?>" required>
            </div>
            <div class="col-md-8">
              <label class="form-label small fw-bold">Nama Obat</label>
              <input type="text" name="nama_obat" class="form-control" placeholder="Contoh: Amoxicillin 500mg" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Kategori</label>
              <input type="text" name="kategori" class="form-control" placeholder="Antibiotik / Vaksin" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Satuan</label>
              <input type="text" name="satuan" class="form-control" placeholder="Tablet / Vial / Botol" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Stok Masuk</label>
              <input type="number" name="stok_dinkes" class="form-control" value="10000" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Buffer Minimal</label>
              <input type="number" name="buffer_minimal" class="form-control" value="2000" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">No. Batch</label>
              <input type="text" name="batch" class="form-control" value="BCH-2026-001" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Exp Date</label>
              <input type="date" name="exp_date" class="form-control" value="2028-12-31" required>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan Stok</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
