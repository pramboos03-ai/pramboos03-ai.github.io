/**
 * PEDOMAN & STANDAR OPERASIONAL PROSEDUR (SOP)
 * PENANGANAN DAN PENCEGAHAN PENYAKIT PRIORITAS DINKES
 * Berdasarkan Pedoman Teknis Kemenkes RI & WHO
 */

const PEDOMAN_PENYAKIT = [
  {
    id: "P001",
    kode: "DBD",
    nama: "Demam Berdarah Dengue (DBD)",
    vektor_patogen: "Virus Dengue melalui gigitan nyamuk Aedes aegypti / Aedes albopictus",
    masa_inkubasi: "4 - 10 hari setelah gigitan nyamuk infeksius",
    kategori: "Penyakit Menular Potensi KLB",
    warna_kategori: "danger",
    gejala_klinis: [
      "Demam tinggi mendadak terus menerus selama 2-7 hari tanpa sebab jelas",
      "Nyeri kepala hebat, nyeri belakang bola mata (retro-orbital), nyeri otot dan sendi",
      "Manifestasi perdarahan: uji bendung (Rumple Leede) positif, bintik merah (petekie), mimisan, gusi berdarah",
      "Pembesaran hati (hepatomegali)",
      "Pemeriksaan Lab: Trombositopenia (< 100.000/µL) dan Hemokonsentrasi (peningkatan Hematokrit ≥ 20%)",
      "TANDA BAHAYA (Warning Signs): Sakit perut hebat, muntah terus-menerus, lemas/gelisah, perdarahan mukosa, ekstremitas dingin (Dengue Shock Syndrome)"
    ],
    tatalaksana_medis: [
      "Rehidrasi cairan yang adekuat: Berikan cairan oral (jus, oralit, susu, air putih) jika mampu minum",
      "Jika terjadi tanda dehidrasi/warning signs: Terapi infus kristaloid (Ringer Laktat / NaCl 0.9%) dengan dosis 5-7 ml/kgBB/jam dalam 1-2 jam pertama",
      "Antipiretik pilihan HANYA Paracetamol (10-15 mg/kgBB/kali tiap 6 jam jika demam > 38.5°C)",
      "KONTRAINDIKASI KERAS: Dilarang memberikan Aspirin, Ibuprofen, atau NSAID lain karena memicu perdarahan lambung hebat",
      "Monitoring ketat tanda-tanda vital, urin output (minimal 0.5 - 1 ml/kgBB/jam), serta cek berkala Hematokrit dan Trombosit setiap 6-12 jam",
      "Rujuk segera ke RSUD terdekat bila didapatkan tanda-tanda syok / perdarahan masif"
    ],
    sop_respon_dinkes: [
      "Notifikasi 1x24 Jam: Petugas Surveilans Puskesmas wajib lapor Sistem Kewaspadaan Dini (SKDR) Dinkes saat ditemukan suspek DBD",
      "Penyelidikan Epidemiologi (PE): Tim Gerak Cepat (TGC) turun ke lokasi dalam waktu maksimal 24 jam dengan radius minimal 200 meter (sekitar 20-30 rumah di sekitar rumah penderita)",
      "Pemeriksaan Jentik: Menghitung Angka Bebas Jentik (ABJ). Jika ABJ < 95% atau ditemukan penderita lain / demam, wilayah dinyatakan berstatus WASPADA/ALERT",
      "Pelaksanaan Fogging Fokus: Dilakukan 2 siklus dengan interval 7 hari menggunakan insektisida Malathion / Cynoff 25 EC",
      "Pemberian Larvasida (Abatisasi selektif) untuk tempat penampungan air (TPA) yang sulit dikuras (1 gram Abate per 10 liter air)"
    ],
    pencegahan_masyarakat: [
      "Pemberantasan Sarang Nyamuk (PSN 3M Plus) minimal 1 kali seminggu:",
      "1. MENGURAS dan menyikat bak mandi, drum penampungan air, dan tempat minum hewan peliharaan",
      "2. MENUTUP rapat tempat-tempat penampungan air",
      "3. MENDAUR ULANG / memanfaatkan barang bekas yang dapat menampung air hujan (ban bekas, kaleng, botol plastik)",
      "PLUS: Menaburkan bubuk larvasida (Abate), memasang kawat kasa di ventilasi rumah, menggunakan lotion anti nyamuk, memelihara ikan pemakan jentik, menanam tanaman pengusir nyamuk (serai, lavender)",
      "Gerakan 1 Rumah 1 Jumantik (Juru Pemantau Jentik) melibatkan peran aktif keluarga"
    ],
    logistik_terkait: "Ringer Laktat Infus (500 ml), Paracetamol 500 mg, Abate 1G, Insektisida Malathion 96%, Rapid Test Dengue NS1 / IgM-IgG"
  },
  {
    id: "P002",
    kode: "DIARE",
    nama: "Diare Akut & Gastroenteritis",
    vektor_patogen: "Bakteri (E. coli, Shigella, Salmonella, Vibrio cholerae), Virus (Rotavirus), atau Parasit",
    masa_inkubasi: "Beberapa jam hingga 5 hari",
    kategori: "Penyakit Menular Potensi KLB",
    warna_kategori: "warning",
    gejala_klinis: [
      "Buang air besar cair/lembek ≥ 3 kali dalam 24 jam",
      "Dapat disertai muntah, mual, demam, dan kram perut",
      "Derajat Dehidrasi: Tanpa dehidrasi (anak aktif, minum biasa), Dehidrasi Ringan/Sedang (gelisah, haus, mata cekung, turgor kulit kembali lambat), Dehidrasi Berat (lemas/tidak sadar, tidak bisa minum, turgor kulit sangat lambat > 2 detik)"
    ],
    tatalaksana_medis: [
      "Penerapan LINTAS Diare (Lima Langkah Tuntaskan Diare):",
      "1. Berikan Oralit formula baru (osmolaritas rendah) segera setelah setiap kali BAB (100 ml untuk usia < 1 tahun, 200 ml untuk usia ≥ 1 tahun)",
      "2. Berikan Tablet ZINC selama 10 hari berturut-turut meskipun diare sudah berhenti (10 mg/hari usia < 6 bulan, 20 mg/hari usia ≥ 6 bulan) untuk mempercepat perbaikan dinding usus dan mencegah diare berulang",
      "3. Teruskan pemberian ASI dan makanan bergizi seimbang (tidak boleh dipuasakan)",
      "4. Berikan Antibiotik HANYA ATAS INDIKASI: Jika diare berdarah (disentri) atau kolera/giardiasis, BUKAN untuk semua diare cair",
      "5. Edukasi keluarga mengenai tanda bahaya untuk segera kembali ke Puskesmas",
      "Untuk dehidrasi berat: Berikan cairan intravena Ringer Laktat 100 ml/kgBB sesuai rencana terapi C"
    ],
    sop_respon_dinkes: [
      "Surveilans Aktif: Deteksi sinyal peningkatan kasus mingguan di puskesmas (> 2 kali rata-rata minggu sebelumnya)",
      "Inspeksi Kesehatan Lingkungan (IKL): Uji laboratorium sampel air bersih dan makanan di lokasi wabah",
      "Kaporitisasi Sumber Air: Kaporitisasi sumur gali dan tandon air komunal warga (takaran: 1 sendok makan bubuk kaporit 70% per 1.000 liter air)",
      "Penyediaan pos hidrasi oral darurat dan pembagian kaporit/oralit massal di tingkat desa binaan"
    ],
    pencegahan_masyarakat: [
      "Cuci Tangan Pakai Sabun (CTPS) dengan air mengalir pada 5 waktu penting (sebelum makan, sebelum mengolah makanan, setelah BAB/BAK, setelah menceboki anak, sebelum menyusui)",
      "Mengonsumsi air minum yang sudah dimasak mendidih atau air higienis teruji",
      "Mengolah makanan secara bersih dan menutup makanan agar tidak dihinggapi lalat",
      "Pemberian ASI Eksklusif 6 bulan pertama kehidupan untuk antibodi usus bayi",
      "Stop Buang Air Besar Sembarangan (Open Defecation Free / ODF) dan wajib menggunakan jamban sehat berleher angsa"
    ],
    logistik_terkait: "Oralit Serbuk 200 ml, Tablet Zinc 20 mg, Kaporit bubuk 70%, Infus RL, Metronidazole Tab, Kotrimoksazol Suspensi"
  },
  {
    id: "P003",
    kode: "ISPA",
    nama: "ISPA Akut & Pneumonia Balita",
    vektor_patogen: "Bakteri (Streptococcus pneumoniae, Haemophilus influenzae) dan Virus (RSV, Influenza, Rhinovirus)",
    masa_inkubasi: "1 - 3 hari",
    kategori: "Penyakit Menular",
    warna_kategori: "primary",
    gejala_klinis: [
      "Batuk, pilek, hidung tersumbat, dan demam",
      "Klasifikasi Pneumonia: Batuk dengan NAPAS CEPAT (Usia <2 bln: ≥60x/menit; 2-11 bln: ≥50x/menit; 1-5 thn: ≥40x/menit)",
      "TANDA PNEUMONIA BERAT: Tarikan dinding dada bagian bawah ke dalam (chest indrawing), stridor saat tenang, saturasi O2 < 90%, sianosis (kebiruan di bibir/kuku), anak tidak mau menyusu/minum"
    ],
    tatalaksana_medis: [
      "Pneumonia Ringan/Sedang: Rawat jalan dengan Antibiotik lini pertama Amoxicillin oral dosis 40-50 mg/kgBB/kali dua kali sehari selama 3-5 hari",
      "Pemberian antipiretik Paracetamol jika demam > 38°C",
      "Teruskan ASI dan cairan hangat; bersihkan sumbatan lendir hidung dengan tetes larutan garam fisiologis",
      "Pneumonia Berat: Rujuk segera ke RSUD, posisikan anak semi-duduk, pasang oksigen nasal kanul 1-2 liter/menit, berikan dosis pertama antibiotik injeksi (Ampisilin + Gentamisin)"
    ],
    sop_respon_dinkes: [
      "Surveilans Tren ISPA bulanan dari seluruh poli umum dan poli KIA puskesmas",
      "Pemantauan kualitas udara di sekitar sentra industri dan permukiman padat",
      "Pelatihan tatalaksana MTBS (Manajemen Terpadu Balita Sakit) bagi tenaga bidan dan perawat desa",
      "Pemberian edukasi isolasi mandiri bagi pasien bergejala batuk aktif di lingkungan padat"
    ],
    pencegahan_masyarakat: [
      "Melengkapi Imunisasi Dasar: Vaksin PCV (Pneumokokus) dan Vaksin Pentabio (DPT-HB-Hib)",
      "Menjaga ventilasi dan pencahayaan alami di dalam rumah agar sirkulasi udara lancar",
      "JAUHKAN BALITA DARI ASAP ROKOK dan asap pembakaran sampah di lingkungan rumah (zona tanpa rokok)",
      "Menerapkan etika batuk yang benar: tutup hidung dan mulut dengan tisu atau lengan baju bagian dalam",
      "Gunakan masker saat menderita flu agar tidak menularkan ke anggota keluarga lain terutama bayi/lansia"
    ],
    logistik_terkait: "Amoxicillin Sirup Kering / Kaplet 500 mg, Oseltamivir 75 mg, Salbutamol Nebulizer, Oksigen Tabung, Pulse Oximeter Anak"
  },
  {
    id: "P004",
    kode: "CAMPAK",
    nama: "Suspek Campak / Morbili (Morbilli)",
    vektor_patogen: "Virus Morbilli (Morbillivirus) melalui droplet udara batuk/bersin",
    masa_inkubasi: "10 - 14 hari",
    kategori: "Penyakit Menular Potensi KLB",
    warna_kategori: "danger",
    gejala_klinis: [
      "Demam tinggi mendadak (dapat mencapai 39-40°C)",
      "Trias 3C: Coryza (pilek), Cough (batuk), Conjunctivitis (mata merah berair dan sensitif cahaya)",
      "Bercak Koplik (bintik putih keabuan dengan dasar merah di dalam mukosa pipi) muncul 1-2 hari sebelum ruam",
      "Ruam makulopapular kemerahan khas: Muncul dari belakang telinga, menyebar ke dahi, wajah, leher, dada, punggung, hingga seluruh tubuh",
      "Komplikasi Berbahaya: Pneumonia, diare berat, kebutaan (akibat defisiensi vit A), ensefalitis (radang otak)"
    ],
    tatalaksana_medis: [
      "PEMBERIAN VITAMIN A DOSIS TINGGI SEGERA (Wajib Kemenkes):",
      "- Usia < 6 bulan: 50.000 IU (kapsul biru 1/2 dosis)",
      "- Usia 6 - 11 bulan: 100.000 IU (kapsul biru)",
      "- Usia ≥ 12 bulan: 200.000 IU (kapsul merah)",
      "Diberikan 2 dosis: Hari ke-1 saat diagnosis dan Hari ke-2 berikutnya untuk mencegah kebutaan & kerusakan epitel",
      "Isolasi pasien di rumah selama 4 hari sejak ruam pertama muncul",
      "Simtomatik: Paracetamol untuk demam, hidrasi cukup, dan nutrisi bergizi tinggi"
    ],
    sop_respon_dinkes: [
      "Pelaporan Kasus CBMS (Case-Based Measles Surveillance): Pengambilan sampel serum darah dalam kurun waktu 0 - 28 hari sejak muncul ruam untuk uji serologi IgM di Labkesda/BBLK",
      "Pelacakan Kontak Erat (Contact Tracing): Menelusuri seluruh anak di sekitar radius rumah, PAUD, atau sekolah pasien",
      "Penyelidikan KLB: Jika ditemukan ≥ 2 kasus konfirmasi campak dalam 1 wilayah, status dinyatakan KLB Campak",
      "Pelaksanaan ORI (Outbreak Response Immunization): Vaksinasi massal campak (MR) tanpa memandang status imunisasi sebelumnya pada anak usia sasaran di wilayah terdampak"
    ],
    pencegahan_masyarakat: [
      "Imunisasi Rutin Campak-Rubella (MR) Lengkap:",
      "- Dosis 1: Usia 9 bulan",
      "- Dosis 2: Usia 18 bulan",
      "- Dosis 3: Kelas 1 SD (program BIAS / Bulan Imunisasi Anak Sekolah)",
      "Hindari kontak langsung antara balita dengan orang yang sedang menderita demam dan ruam kulit",
      "Segera bawa anak ke faskes bila timbul demam disertai mata merah dan ruam kemerahan"
    ],
    logistik_terkait: "Vaksin MR (Campak Rubella), Vitamin A 100.000 IU & 200.000 IU, Spuit AD 0.5 ml, Tabung Vakum Serum Darah, Paracetamol Sirup"
  },
  {
    id: "P005",
    kode: "TBC",
    nama: "Tuberkulosis (TBC Paru)",
    vektor_patogen: "Bakteri Mycobacterium tuberculosis melalui droplet dahak melayang di udara",
    masa_inkubasi: "Beberapa minggu hingga tahunan (status laten)",
    kategori: "Penyakit Menular Kronis",
    warna_kategori: "secondary",
    gejala_klinis: [
      "Batuk berdahak terus-menerus ≥ 2 minggu (dapat bercampur darah / batuk darah)",
      "Demam sumeng/meriang subfebris terutama pada malam hari",
      "Keringat dingin malam hari tanpa beraktivitas fisik",
      "Penurunan nafsu makan dan penurunan berat badan secara drastis",
      "Nyeri dada dan sesak napas jika lesi paru sudah meluas"
    ],
    tatalaksana_medis: [
      "Penegakan Diagnosis Utama: Tes Cepat Molekuler (TCM) GeneXpert untuk mendeteksi DNA kuman dan resistensi Rifampisin",
      "Pengobatan Standar OAT (Obat Anti Tuberkulosis) Kategori 1 (FDC / Fixed Dose Combination):",
      "- Tahap Intensif (2 bulan): 4FDC (Rifampisin, Isoniazid, Pirazinamid, Etambutol) diminum setiap hari",
      "- Tahap Lanjutan (4 bulan): 2FDC (Rifampisin dan Isoniazid) diminum setiap hari atau 3x seminggu sesuai panduan",
      "Wajib didampingi Pengawas Menelan Obat (PMO) keluarga/kader untuk memastikan kepatuhan obat dan mencegah TBC Resisten Obat (TBC-RO / MDR)",
      "Monitoring evaluasi dahak mikroskopis pada akhir bulan ke-2, ke-5, dan ke-6 pengobatan"
    ],
    sop_respon_dinkes: [
      "Investigasi Kontak (IK): Petugas Puskesmas wajib melakukan skrining gejala dan rontgen/uji Mantoux pada minimal 10-15 orang kontak serumah & kontak erat pasien TBC aktif",
      "Pemberian Terapi Pencegahan Tuberkulosis (TPT): Diberikan kepada kontak serumah (terutama anak < 5 tahun dan orang dengan HIV) yang tidak terbukti sakit TBC aktif",
      "Integrasi Sistem Informasi Tuberkulosis (SITB) Kemenkes untuk pemantauan kepatuhan minum obat secara real-time"
    ],
    pencegahan_masyarakat: [
      "Imunisasi BCG pada bayi usia 0 - 1 bulan untuk mencegah TBC berat (meningitis TBC)",
      "Membuka jendela kamar dan rumah setiap pagi agar sirkulasi udara lancar dan sinar matahari UV masuk (kuman TBC mati terpapar sinar matahari)",
      "Menerapkan etika batuk: Gunakan masker, buang dahak di wadah tertutup yang telah diberi cairan disinfektan (karbol/pemutih) atau di jamban",
      "Menjaga asupan gizi seimbang dan daya tahan tubuh prima"
    ],
    logistik_terkait: "Paket OAT Kategori 1 (FDC Dewasa & Anak), Cartridge TCM GeneXpert, Masker N95, Pot Dahak Steril, Obat TPT (Isoniazid/Rifapentin)"
  },
  {
    id: "P006",
    kode: "STUNTING",
    nama: "Stunting & Gizi Buruk Balita",
    vektor_patogen: "Masalah gizi kronis akibat kurang asupan gizi dalam waktu lama & infeksi berulang",
    masa_inkubasi: "Terakumulasi selama 1.000 Hari Pertama Kehidupan (HPK)",
    kategori: "Masalah Kesehatan Masyarakat (Kesmas)",
    warna_kategori: "info",
    gejala_klinis: [
      "Tinggi/Panjang Badan menurut Umur (TB/U atau PB/U) < -2 Standar Deviasi (SD) dari kurva standar pertumbuhan WHO",
      "Pertumbuhan fisik terhambat dibandingkan anak seusianya",
      "Perkembangan kognitif, motorik, dan kemampuan bicara terlambat",
      "Daya tahan tubuh rendah, mudah terserang penyakit infeksi berulang (diare, batuk/pneumonia)",
      "Tanda Gizi Buruk Akut (Wasting): Edema kedua punggung kaki, otot mengecil (baggy pants), wajah seperti orang tua"
    ],
    tatalaksana_medis: [
      "Rujukan Berjenjang ke Dokter Spesialis Anak (Sp.A) di RSUD untuk evaluasi penyakit penyerta (Red Flags: alergi susu sapi, TBC anak, kelainan jantung bawaan, kelainan metabolik)",
      "Pemberian Pangan Olahan untuk Keperluan Medis Khusus (PKMK) / formula padat kalori (F75 / F100) atas resep dokter spesialis",
      "Tata laksana segera untuk infeksi penyerta (obati TBC atau diare kronis anak)",
      "Pemantauan berat badan mingguan dan tinggi badan bulanan dengan antropometri terstandar Kemenkes"
    ],
    sop_respon_dinkes: [
      "Program Pemberian Makanan Tambahan (PMT) Berbahan Pangan Lokal Kaya Protein Hewani selama 90 hari terpantau bagi balita gizi kurang dan ibu hamil KEK",
      "Pendampingan Tim Audit Kasus Stunting (AKS) melibatkan dokter spesialis anak, spesialis kandungan, ahli gizi, dan psikolog",
      "Kunjungan rumah (home visit) oleh Bidan Desa dan Kader Pembangunan Manusia (KPM) untuk memastikan makanan tambahan benar-benar dikonsumsi balita sasaran",
      "Rembuk Stunting Tingkat Kecamatan dan Desa untuk alokasi dana desa dalam perbaikan gizi dan sanitasi"
    ],
    pencegahan_masyarakat: [
      "Intervensi 1.000 Hari Pertama Kehidupan (HPK) - Dari konsepsi janin hingga usia 2 tahun:",
      "1. Remaja Putri & Ibu Hamil: Konsumsi rutin Tablet Tambah Darah (TTD) minimal 90 tablet selama kehamilan untuk cegah anemia",
      "2. Ibu Hamil: Periksa kehamilan minimal 6 kali (termasuk 2 kali USG oleh dokter) dan asupan nutrisi protein hewani cukup",
      "3. Bayi Baru Lahir: Inisiasi Menyusu Dini (IMD) dan ASI Eksklusif selama 6 bulan pertama",
      "4. Usia 6-23 Bulan: Berikan Makanan Pendamping ASI (MP-ASI) bergizi kaya PROTEIN HEWANI (telur, ikan, daging ayam, hati ayam, susu) setiap hari",
      "5. Imunisasi Dasar Lengkap (IDL) dan penimbangan rutin setiap bulan di Posyandu",
      "6. Akses air bersih dan sanitasi jamban sehat di setiap rumah tangga"
    ],
    logistik_terkait: "Antropometri Kit Terstandar Kemenkes (Stadiometer, Infantometer, Timbangan Digital), Paket PMT Balita & Bumil KEK, Formula F75/F100, Tablet Tambah Darah (Fe+Folat)"
  }
];
