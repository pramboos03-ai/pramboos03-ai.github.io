<?php
require_once __DIR__ . '/config/koneksi.php';
check_auth();

$page_title = 'Laporan Rekapitulasi Eksekutif';

$stmt_pkm = $pdo->query("SELECT * FROM puskesmas ORDER BY id ASC");
$puskesmas = $stmt_pkm->fetchAll();

$stmt_srv = $pdo->query("SELECT s.*, p.nama as puskesmas_nama FROM surveilans s JOIN puskesmas p ON s.puskesmas_id = p.id ORDER BY s.tanggal DESC");
$surveilans = $stmt_srv->fetchAll();

$stmt_stn = $pdo->query("SELECT st.*, p.nama as puskesmas_nama, p.kecamatan FROM stunting st JOIN puskesmas p ON st.puskesmas_id = p.id ORDER BY st.id ASC");
$stunting = $stmt_stn->fetchAll();

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-slate-800">Laporan Eksekutif Daerah</h3>
    <p class="text-muted mb-0">Cetak Laporan Ber-KOP Resmi Dinas Kesehatan & Simpan PDF</p>
  </div>
  <div>
    <button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer-fill me-1"></i> Cetak / Simpan PDF</button>
  </div>
</div>

<div class="card-dinkes p-4 bg-white border shadow-sm">
  <div class="kop-surat">
    <div class="kop-logo d-flex align-items-center justify-content-center bg-teal text-white rounded-3 fs-1 fw-bold" style="background:#0d9488">
      <i class="bi bi-hospital"></i>
    </div>
    <div class="kop-text">
      <h4>PEMERINTAH DAERAH PROVINSI JAWA BARAT</h4>
      <h2>DINAS KESEHATAN KABUPATEN SEHAT SEJAHTERA</h2>
      <p>Jl. Kesehatan No. 45, Kompleks Perkantoran Pemda | Telp: (021) 8765-4321 | Email: kontak@dinkes-sehat.go.id</p>
    </div>
  </div>

  <div class="text-center my-4">
    <h5 class="fw-bold text-decoration-underline mb-1">LAPORAN MONITORING SITUASI KESEHATAN DAERAH</h5>
    <div class="text-muted small">Periode: <?= date('F Y'); ?> | Wilayah Kerja Seluruh UPT Puskesmas</div>
  </div>

  <h6 class="fw-bold border-bottom pb-2 mt-4 text-primary"><i class="bi bi-1-circle-fill me-1"></i> Rekapitulasi Puskesmas & Tenaga Medis</h6>
  <table class="table table-bordered table-sm mb-4 small">
    <thead class="table-light">
      <tr>
        <th>Kode</th>
        <th>Nama Puskesmas</th>
        <th>Kecamatan</th>
        <th>Tipe</th>
        <th>Akreditasi</th>
        <th class="text-center">Dokter</th>
        <th class="text-center">Perawat</th>
        <th class="text-center">Bidan</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($puskesmas as $p): ?>
        <tr>
          <td><?= htmlspecialchars($p['id']); ?></td>
          <td class="fw-semibold"><?= htmlspecialchars($p['nama']); ?></td>
          <td><?= htmlspecialchars($p['kecamatan']); ?></td>
          <td><?= htmlspecialchars($p['tipe']); ?></td>
          <td><?= htmlspecialchars($p['akreditasi']); ?></td>
          <td align="center"><?= $p['jml_dokter']; ?></td>
          <td align="center"><?= $p['jml_perawat']; ?></td>
          <td align="center"><?= $p['jml_bidan']; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <h6 class="fw-bold border-bottom pb-2 mt-4 text-danger"><i class="bi bi-2-circle-fill me-1"></i> Surveilans Penyakit Potensi KLB</h6>
  <table class="table table-bordered table-sm mb-4 small">
    <thead class="table-light">
      <tr>
        <th>Tanggal</th>
        <th>Puskesmas</th>
        <th>Penyakit</th>
        <th class="text-center">Kasus</th>
        <th>Status SKDR</th>
        <th>Catatan Respon</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($surveilans as $s): ?>
        <tr>
          <td><?= htmlspecialchars($s['tanggal']); ?></td>
          <td class="fw-semibold"><?= htmlspecialchars($s['puskesmas_nama']); ?></td>
          <td><?= htmlspecialchars($s['penyakit']); ?></td>
          <td align="center" class="fw-bold"><?= $s['jumlah_kasus']; ?></td>
          <td><span class="badge <?= ($s['status_alert'] === 'Alert KLB') ? 'bg-danger' : 'bg-warning text-dark'; ?>"><?= htmlspecialchars($s['status_alert']); ?></span></td>
          <td><?= htmlspecialchars($s['catatan'] ?? '-'); ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="row mt-5 pt-3">
    <div class="col-6"></div>
    <div class="col-6 text-center">
      <p class="mb-1">Ditetapkan di: Kabupaten Sehat Sejahtera</p>
      <p class="mb-5">Pada tanggal: <?= date('d F Y'); ?><br><strong>KEPALA DINAS KESEHATAN</strong></p>
      <br><br>
      <p class="fw-bold text-decoration-underline mb-0">dr. H. Rahmat Hidayat, M.Kes, Sp.KKLP</p>
      <p class="text-muted small">NIP. 19750812 200212 1 003</p>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
