/**
 * SIMKES DINAS KESEHATAN DAERAH - APPLICATION LOGIC
 * Full Interactive Offline-First Demo Engine
 */

const STORAGE_KEY = 'SIMKES_DINKES_DATA_V1';

// Global State
let appData = null;
let currentView = 'dashboard';
let currentRole = 'superadmin';
let trendChartInstance = null;
let stuntingChartInstance = null;
let gisMapInstance = null;
let gisDashboardMapInstance = null;

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  setupEventListeners();
  renderCurrentView();
  updateClock();
  setInterval(updateClock, 1000);
});

// Load Data from LocalStorage or Default
function loadData() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      appData = JSON.parse(saved);
    } catch (e) {
      console.error("Gagal membaca storage, reset ke default", e);
      appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
      saveData();
    }
  } else {
    appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
    saveData();
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
}

function resetDemoData() {
  if (confirm("Apakah Anda yakin ingin mereset seluruh data kembali ke data demo awal?")) {
    appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
    saveData();
    showToast("Data demo berhasil direset ke pengaturan awal!", "success");
    renderCurrentView();
  }
}

// Event Listeners
function setupEventListeners() {
  // Navigation
  document.querySelectorAll('.nav-link-custom').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const view = link.getAttribute('data-view');
      if (view) {
        switchView(view);
      }
    });
  });

  // Role Switcher
  const roleSelect = document.getElementById('role-selector');
  if (roleSelect) {
    roleSelect.addEventListener('change', (e) => {
      currentRole = e.target.value;
      updateRoleUI();
      showToast(`Beralih ke mode hak akses: ${roleSelect.options[roleSelect.selectedIndex].text}`, 'info');
    });
  }

  // Mobile sidebar toggle
  const menuToggle = document.getElementById('menu-toggle');
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebar-backdrop');
  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('show');
      if (backdrop) backdrop.classList.toggle('show');
    });
  }
  if (backdrop) {
    backdrop.addEventListener('click', () => {
      sidebar.classList.remove('show');
      backdrop.classList.remove('show');
    });
  }
}

function updateClock() {
  const clockEl = document.getElementById('realtime-clock');
  if (clockEl) {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
    clockEl.textContent = now.toLocaleDateString('id-ID', options);
  }
}

function switchView(viewName) {
  currentView = viewName;
  document.querySelectorAll('.nav-link-custom').forEach(l => {
    l.classList.toggle('active', l.getAttribute('data-view') === viewName);
  });

  // Close mobile sidebar if open
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebar-backdrop');
  if (sidebar && sidebar.classList.contains('show')) {
    sidebar.classList.remove('show');
    if (backdrop) backdrop.classList.remove('show');
  }

  renderCurrentView();
}

function updateRoleUI() {
  const badge = document.getElementById('active-role-badge');
  if (!badge) return;

  const roleNames = {
    'superadmin': 'Kepala Dinas / Super Admin',
    'p2p': 'Bidang P2P (Surveilans & KLB)',
    'kesmas': 'Bidang Kesmas (Gizi & KIA)',
    'farmasi': 'Bidang Farmasi & GFK',
    'puskesmas': 'Petugas Puskesmas'
  };

  badge.textContent = roleNames[currentRole] || 'Pengguna';
}

// View Renderer Router
function renderCurrentView() {
  const container = document.getElementById('view-container');
  if (!container) return;

  // Clean old charts & maps
  if (trendChartInstance) {
    trendChartInstance.destroy();
    trendChartInstance = null;
  }
  if (stuntingChartInstance) {
    stuntingChartInstance.destroy();
    stuntingChartInstance = null;
  }
  if (gisMapInstance) {
    gisMapInstance.remove();
    gisMapInstance = null;
  }
  if (gisDashboardMapInstance) {
    gisDashboardMapInstance.remove();
    gisDashboardMapInstance = null;
  }

  switch (currentView) {
    case 'dashboard':
      renderDashboard(container);
      break;
    case 'gis':
      renderGISMap(container);
      break;
    case 'puskesmas':
      renderPuskesmas(container);
      break;
    case 'surveilans':
      renderSurveilans(container);
      break;
    case 'pedoman':
      renderPedoman(container);
      break;
    case 'kesmas':
      renderKesmas(container);
      break;
    case 'farmasi':
      renderFarmasi(container);
      break;
    case 'laporan':
      renderLaporan(container);
      break;
    default:
      renderDashboard(container);
  }
}

// -------------------------------------------------------------
// 1. DASHBOARD VIEW
// -------------------------------------------------------------
function renderDashboard(container) {
  // Calculate Totals
  const totalPuskesmas = appData.puskesmas.length;
  const totalDokter = appData.puskesmas.reduce((acc, p) => acc + (parseInt(p.jml_dokter) || 0), 0);
  const totalNakes = appData.puskesmas.reduce((acc, p) => acc + (parseInt(p.jml_dokter) || 0) + (parseInt(p.jml_perawat) || 0) + (parseInt(p.jml_bidan) || 0), 0);
  
  const totalKasusSurveilans = appData.surveilans.reduce((acc, s) => acc + (parseInt(s.jumlah_kasus) || 0), 0);
  const alertCount = appData.surveilans.filter(s => s.status_alert === 'Alert KLB' || s.status_alert === 'Waspada').length;

  const avgStunting = (appData.stunting.reduce((acc, s) => acc + s.persen_stunting, 0) / (appData.stunting.length || 1)).toFixed(1);
  const obatKritis = appData.obat_gfk.filter(o => o.status_stok === 'Kritis' || o.status_stok === 'Menipis').length;

  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Dashboard Eksekutif Dinkes</h3>
        <p class="text-muted mb-0"><i class="bi bi-geo-alt-fill text-danger me-1"></i> ${appData.profil_dinkes.nama_instansi} &bull; Tahun Anggaran ${appData.profil_dinkes.tahun_anggaran}</p>
      </div>
      <div class="d-flex gap-2 mt-2 mt-md-0">
        <button class="btn btn-outline-secondary btn-sm" onclick="resetDemoData()"><i class="bi bi-arrow-counterclockwise me-1"></i> Reset Data Demo</button>
        <button class="btn btn-primary btn-sm" onclick="switchView('laporan')"><i class="bi bi-printer me-1"></i> Cetak Ringkasan</button>
      </div>
    </div>

    <!-- KPI STAT CARDS -->
    <div class="row g-3 mb-4">
      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <span class="text-muted small fw-semibold">FASILITAS KESEHATAN</span>
              <h3 class="fw-bold my-1">${totalPuskesmas} Puskesmas</h3>
              <span class="trend-badge bg-success-subtle text-success"><i class="bi bi-check2-circle"></i> 100% Terakreditasi</span>
            </div>
            <div class="stat-icon bg-teal text-white" style="background:#0d9488">
              <i class="bi bi-hospital"></i>
            </div>
          </div>
          <div class="small text-muted mt-2 pt-2 border-top">
            <i class="bi bi-people-fill me-1"></i> <strong>${totalDokter}</strong> Dokter &bull; <strong>${totalNakes}</strong> Total Nakes
          </div>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <span class="text-muted small fw-semibold">SURVEILANS & SKDR</span>
              <h3 class="fw-bold my-1">${totalKasusSurveilans} Kasus</h3>
              <span class="trend-badge ${alertCount > 0 ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">
                <i class="bi bi-exclamation-triangle-fill"></i> ${alertCount} Sinyal Waspada
              </span>
            </div>
            <div class="stat-icon bg-danger text-white">
              <i class="bi bi-activity"></i>
            </div>
          </div>
          <div class="small text-muted mt-2 pt-2 border-top">
            Fokus: DBD, ISPA, Diare & Campak
          </div>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <span class="text-muted small fw-semibold">PREVALENSI STUNTING</span>
              <h3 class="fw-bold my-1">${avgStunting}%</h3>
              <span class="trend-badge bg-primary-subtle text-primary"><i class="bi bi-shield-check"></i> Target: &le; 11.5%</span>
            </div>
            <div class="stat-icon bg-info text-white">
              <i class="bi bi-heart-pulse"></i>
            </div>
          </div>
          <div class="small text-muted mt-2 pt-2 border-top">
            Rata-rata 8 Wilayah Kerja Puskesmas
          </div>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <span class="text-muted small fw-semibold">LOGISTIK FARMASI GFK</span>
              <h3 class="fw-bold my-1">${appData.obat_gfk.length} Item Obat</h3>
              <span class="trend-badge ${obatKritis > 0 ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success'}">
                <i class="bi bi-capsule"></i> ${obatKritis} Perlu Buffer Stock
              </span>
            </div>
            <div class="stat-icon bg-warning text-white">
              <i class="bi bi-box-seam"></i>
            </div>
          </div>
          <div class="small text-muted mt-2 pt-2 border-top">
            Ketersediaan Obat Esensial: <strong>96.4%</strong>
          </div>
        </div>
      </div>
    </div>

    <!-- CHARTS & EWARS MAP ROW -->
    <div class="row g-4 mb-4">
      <div class="col-12 col-lg-8">
        <div class="card-dinkes h-100">
          <div class="card-header">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-graph-up-arrow text-primary"></i>
              <span>Tren Kasus Penyakit Menular Potensi KLB (Mingguan)</span>
            </div>
            <span class="badge bg-light text-dark border">P2P Dinkes</span>
          </div>
          <div class="card-body">
            <canvas id="trendChart" height="230"></canvas>
          </div>
        </div>
      </div>

      <div class="col-12 col-lg-4">
        <div class="card-dinkes h-100">
          <div class="card-header">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-pie-chart text-success"></i>
              <span>Status Kinerja Stunting per PKM</span>
            </div>
          </div>
          <div class="card-body">
            <canvas id="stuntingChart" height="230"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- EWARS GIS MAP & 10 BESAR PENYAKIT -->
    <div class="row g-4">
      <div class="col-12 col-lg-7">
        <div class="card-dinkes">
          <div class="card-header">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-map-fill text-danger"></i>
              <span>Peta GIS Kewaspadaan Dini Wilayah (EWARS / SKDR)</span>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-primary" onclick="switchView('gis')">
                <i class="bi bi-arrows-fullscreen me-1"></i> Buka Peta Penuh
              </button>
            </div>
          </div>
          <div class="card-body p-2">
            <div id="gis-map-dashboard"></div>
            <div class="d-flex flex-wrap justify-content-between align-items-center mt-2 px-2 small text-muted">
              <span><i class="bi bi-cursor-fill text-primary"></i> Klik poligon kecamatan atau ikon faskes untuk detail kasus</span>
              <div class="d-flex gap-2">
                <span class="badge bg-danger-subtle text-danger"><i class="bi bi-circle-fill"></i> Alert KLB</span>
                <span class="badge bg-warning-subtle text-warning text-dark"><i class="bi bi-circle-fill"></i> Waspada</span>
                <span class="badge bg-success-subtle text-success"><i class="bi bi-circle-fill"></i> Aman</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12 col-lg-5">
        <div class="card-dinkes">
          <div class="card-header">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-bar-chart-line text-warning"></i>
              <span>10 Besar Penyakit Terbanyak (Daerah)</span>
            </div>
          </div>
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover table-dinkes mb-0">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama Penyakit</th>
                    <th class="text-end">Jumlah</th>
                    <th class="text-end">Tren</th>
                  </tr>
                </thead>
                <tbody>
                  ${appData.top_penyakit.slice(0, 7).map(tp => `
                    <tr>
                      <td class="fw-bold text-muted">${tp.rank}</td>
                      <td>
                        <div class="fw-semibold">${tp.nama}</div>
                      </td>
                      <td class="text-end fw-bold">${tp.kasus.toLocaleString('id-ID')}</td>
                      <td class="text-end">
                        <span class="badge ${tp.tren.startsWith('+') ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">
                          ${tp.tren}
                        </span>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Init Charts
  setTimeout(() => {
    initDashboardCharts();
  }, 50);
}

function initDashboardCharts() {
  const ctxTrend = document.getElementById('trendChart');
  if (ctxTrend) {
    trendChartInstance = new Chart(ctxTrend, {
      type: 'line',
      data: {
        labels: ['Mgg 41', 'Mgg 42', 'Mgg 43', 'Mgg 44', 'Mgg 45', 'Mgg 46 (Kini)'],
        datasets: [
          {
            label: 'Demam Berdarah (DBD)',
            data: [12, 18, 25, 31, 48, 62],
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            fill: true,
            tension: 0.35,
            borderWidth: 2.5
          },
          {
            label: 'ISPA Akut',
            data: [110, 135, 125, 140, 158, 172],
            borderColor: '#0284c7',
            backgroundColor: 'transparent',
            tension: 0.35,
            borderWidth: 2
          },
          {
            label: 'Diare Akut',
            data: [35, 42, 38, 40, 52, 60],
            borderColor: '#f59e0b',
            backgroundColor: 'transparent',
            tension: 0.35,
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'top' },
          tooltip: {
            mode: 'index',
            intersect: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: '#f1f5f9' }
          },
          x: {
            grid: { display: false }
          }
        }
      }
    });
  }

  const ctxStunting = document.getElementById('stuntingChart');
  if (ctxStunting) {
    const underTarget = appData.stunting.filter(s => s.persen_stunting <= s.target_kab).length;
    const overTarget = appData.stunting.filter(s => s.persen_stunting > s.target_kab).length;

    stuntingChartInstance = new Chart(ctxStunting, {
      type: 'doughnut',
      data: {
        labels: ['Di Bawah Target (Aman)', 'Perlu Intervensi Khusus'],
        datasets: [{
          data: [underTarget, overTarget],
          backgroundColor: ['#10b981', '#f59e0b'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom' }
        },
        cutout: '68%'
      }
    });
  }

  // Init Dashboard GIS Map
  setTimeout(() => {
    gisDashboardMapInstance = initGISMap('gis-map-dashboard', 'all');
  }, 100);
}

// -------------------------------------------------------------
// HELPER: INIT LEAFLET GIS MAP WITH GEOJSON & COLOR CODING
// -------------------------------------------------------------
function initGISMap(containerId, filterMode = 'all') {
  const mapEl = document.getElementById(containerId);
  if (!mapEl || typeof L === 'undefined') return null;

  const map = L.map(containerId, {
    center: [-6.885, 107.595],
    zoom: 12,
    zoomControl: true,
    scrollWheelZoom: false
  });

  // Base Map Layers: Google Maps & OpenStreetMap
  const googleStreets = L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
    attribution: '&copy; <a href="https://maps.google.com">Google Maps</a>',
    maxZoom: 20
  });

  const googleHybrid = L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
    attribution: '&copy; <a href="https://maps.google.com">Google Maps Satellite</a>',
    maxZoom: 20
  });

  const googleTerrain = L.tileLayer('https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}', {
    attribution: '&copy; <a href="https://maps.google.com">Google Maps Terrain</a>',
    maxZoom: 20
  });

  const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 19
  });

  // Pasang Google Maps Jalan sebagai layer default
  googleStreets.addTo(map);

  const baseMaps = {
    "🗺️ Google Maps (Jalan)": googleStreets,
    "🛰️ Google Satelit (Hybrid)": googleHybrid,
    "⛰️ Google Medan (Terrain)": googleTerrain,
    "🌐 OpenStreetMap": osm
  };

  if (typeof KECAMATAN_GEOJSON === 'undefined') return map;

  // Filter Features if needed
  let geojsonData = KECAMATAN_GEOJSON;
  if (filterMode === 'klb_only') {
    geojsonData = {
      type: 'FeatureCollection',
      features: KECAMATAN_GEOJSON.features.filter(f => f.properties.status_alert === 'Alert KLB' || f.properties.status_alert === 'Waspada')
    };
  } else if (filterMode === 'stunting_high') {
    geojsonData = {
      type: 'FeatureCollection',
      features: KECAMATAN_GEOJSON.features.filter(f => f.properties.stunting_pct > 11.5)
    };
  }

  // GeoJSON Styling Function
  function getFeatureStyle(feature) {
    const alert = feature.properties.status_alert;
    if (alert === 'Alert KLB') {
      return {
        fillColor: '#ef4444', // Red Alert
        weight: 3,
        opacity: 1,
        color: '#b91c1c',
        dashArray: '',
        fillOpacity: 0.65
      };
    } else if (alert === 'Waspada') {
      return {
        fillColor: '#f59e0b', // Yellow / Amber Warning
        weight: 2,
        opacity: 1,
        color: '#d97706',
        dashArray: '',
        fillOpacity: 0.50
      };
    } else {
      return {
        fillColor: '#10b981', // Green Normal
        weight: 1.5,
        opacity: 1,
        color: '#059669',
        dashArray: '',
        fillOpacity: 0.35
      };
    }
  }

  // GeoJSON Layer with Interactive Hover & Popup
  const geojsonLayer = L.geoJSON(geojsonData, {
    style: getFeatureStyle,
    onEachFeature: function(feature, layer) {
      const p = feature.properties;

      // Tooltip on Hover
      layer.bindTooltip(`
        <div class="fw-bold">${p.kecamatan}</div>
        <div class="small">Status: <strong class="${p.status_alert === 'Alert KLB' ? 'text-danger' : (p.status_alert === 'Waspada' ? 'text-warning text-dark' : 'text-success')}">${p.status_alert}</strong></div>
      `, { sticky: true });

      // Highlight on Hover
      layer.on({
        mouseover: function(e) {
          const l = e.target;
          l.setStyle({
            weight: 4,
            color: '#0f172a',
            fillOpacity: 0.8
          });
          if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
            l.bringToFront();
          }
        },
        mouseout: function(e) {
          geojsonLayer.resetStyle(e.target);
        },
        click: function(e) {
          map.fitBounds(e.target.getBounds());
          // Update details panel if exists
          updateGISDetailsPanel(p);
        }
      });

      // Rich Click Popup
      const popupHtml = `
        <div style="min-width: 230px; font-family: Inter, sans-serif;">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <h6 class="fw-bold mb-0 text-slate-800">${p.kecamatan}</h6>
            <span class="badge ${p.status_alert === 'Alert KLB' ? 'badge-alert-klb' : (p.status_alert === 'Waspada' ? 'badge-waspada' : 'badge-normal')}">${p.status_alert}</span>
          </div>
          <div class="small text-muted mb-2"><i class="bi bi-hospital text-teal"></i> ${p.puskesmas} &bull; <em>${p.akreditasi}</em></div>
          <div class="border-top pt-2 small">
            <div><strong>Penyakit Dominan:</strong> ${p.penyakit_dominan}</div>
            <div class="${p.status_alert === 'Alert KLB' ? 'text-danger fw-bold' : 'text-dark'}">
              Jumlah Kasus: <strong>${p.kasus}</strong> ${p.kematian > 0 ? `<span class="badge bg-danger ms-1">${p.kematian} Meninggal</span>` : ''}
            </div>
            <div><strong>Prevalensi Stunting:</strong> ${p.stunting_pct}% (Target: &le;11.5%)</div>
            <div class="mt-2 p-1.5 bg-light rounded text-secondary" style="font-size: 11px;">
              <i class="bi bi-info-circle-fill me-1"></i> ${p.catatan}
            </div>
          </div>
        </div>
      `;
      layer.bindPopup(popupHtml);

      // Puskesmas Pin Marker
      if (p.lat && p.lng) {
        const isKlb = p.status_alert === 'Alert KLB';
        const markerIcon = L.divIcon({
          className: `custom-pkm-icon ${isKlb ? 'pkm-klb' : ''}`,
          html: `<i class="bi bi-hospital-fill"></i>`,
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        });

        L.marker([p.lat, p.lng], { icon: markerIcon })
          .addTo(map)
          .bindPopup(popupHtml);
      }
    }
  }).addTo(map);

  // Layer Control Switcher (Google Maps Jalan, Satelit Hybrid, Terrain, OSM)
  L.control.layers(baseMaps, {
    "🛡️ Batas Kecamatan (GeoJSON)": geojsonLayer
  }, { position: 'topright', collapsed: false }).addTo(map);

  // Map Legend Control
  const legend = L.control({ position: 'bottomright' });
  legend.onAdd = function() {
    const div = L.DomUtil.create('div', 'map-legend');
    div.innerHTML = `
      <div class="fw-bold mb-1 border-bottom pb-1" style="font-size: 11px;">Status Kewaspadaan SKDR</div>
      <div><i style="background: #ef4444;"></i> <strong>Alert KLB</strong> (Melebihi Ambang)</div>
      <div><i style="background: #f59e0b;"></i> <strong>Waspada</strong> (Observasi Ketat)</div>
      <div><i style="background: #10b981;"></i> <strong>Normal</strong> (Terkendali)</div>
    `;
    return div;
  };
  legend.addTo(map);

  return map;
}

function updateGISDetailsPanel(p) {
  const panel = document.getElementById('gis-details-panel');
  if (!panel) return;

  panel.innerHTML = `
    <div class="card-dinkes h-100 border-start border-4 ${p.status_alert === 'Alert KLB' ? 'border-danger' : (p.status_alert === 'Waspada' ? 'border-warning' : 'border-success')}">
      <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <div>
          <span class="badge ${p.status_alert === 'Alert KLB' ? 'badge-alert-klb' : (p.status_alert === 'Waspada' ? 'badge-waspada' : 'badge-normal')} me-2">${p.status_alert}</span>
          <strong class="fs-6">${p.kecamatan}</strong>
        </div>
        <span class="small text-muted font-monospace">${p.id}</span>
      </div>
      <div class="card-body">
        <h6 class="fw-bold mb-1">${p.puskesmas}</h6>
        <p class="text-muted small mb-3"><i class="bi bi-star-fill text-warning me-1"></i> Akreditasi: <strong>${p.akreditasi}</strong> &bull; Tipe: ${p.tipe} &bull; Populasi: ${p.populasi.toLocaleString('id-ID')} Jiwa</p>

        <div class="row g-2 mb-3">
          <div class="col-6">
            <div class="p-2.5 bg-light rounded-3">
              <span class="text-muted small">Penyakit Terbanyak</span>
              <div class="fw-bold text-slate-800">${p.penyakit_dominan}</div>
              <div class="fw-bold ${p.status_alert === 'Alert KLB' ? 'text-danger fs-5' : 'text-primary'}">${p.kasus} Kasus</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-2.5 bg-light rounded-3">
              <span class="text-muted small">Prevalensi Stunting</span>
              <div class="fw-bold fs-5 ${p.stunting_pct > 11.5 ? 'text-warning' : 'text-success'}">${p.stunting_pct}%</div>
              <div class="small text-muted">Target: &le; 11.5%</div>
            </div>
          </div>
        </div>

        <div class="alert ${p.status_alert === 'Alert KLB' ? 'alert-danger' : 'alert-light border'} py-2 px-3 small mb-3">
          <strong>Laporan Petugas Lapangan:</strong><br>
          ${p.catatan}
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-outline-danger w-50" onclick="filterSurveilansByPkm('${p.id}')">
            <i class="bi bi-activity me-1"></i> Lihat Rekap Kasus
          </button>
          <button class="btn btn-sm btn-primary w-50" onclick="switchView('puskesmas')">
            <i class="bi bi-hospital me-1"></i> Profil Puskesmas
          </button>
        </div>
      </div>
    </div>
  `;
}

// -------------------------------------------------------------
// DEDICATED GIS MAP FULL VIEW
// -------------------------------------------------------------
function renderGISMap(container) {
  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800"><i class="bi bi-map-fill text-teal me-2"></i> Peta GIS Kewaspadaan Dini & KLB Wilayah</h3>
        <p class="text-muted mb-0">Visualisasi Geografis Poligon Batas Kecamatan, Titik Puskesmas & Status Ambang Epidemik (EWARS / SKDR)</p>
      </div>
      <div class="d-flex gap-2 mt-2 mt-md-0">
        <select id="gis-filter-select" class="form-select form-select-sm" onchange="filterGISView(this.value)">
          <option value="all">Semua Wilayah Kecamatan (8)</option>
          <option value="klb_only">Hanya Status KLB & Waspada (3)</option>
          <option value="stunting_high">Wilayah Prevalensi Stunting Tinggi</option>
        </select>
        <button class="btn btn-outline-secondary btn-sm" onclick="switchView('dashboard')"><i class="bi bi-grid me-1"></i> Kembali ke Dashboard</button>
      </div>
    </div>

    <!-- GIS STAT HIGHLIGHT BANNER -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-md-3">
        <div class="p-2.5 bg-white border rounded-3 d-flex align-items-center gap-2 shadow-sm">
          <div class="w-8 h-8 rounded-2 bg-danger text-white d-flex align-items-center justify-content-center fw-bold" style="width:36px;height:36px;">
            <i class="bi bi-exclamation-octagon-fill"></i>
          </div>
          <div>
            <div class="small text-muted" style="font-size:11px;">ALERT KLB (MERAH)</div>
            <strong class="text-danger">1 Kecamatan (Cibadak)</strong>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="p-2.5 bg-white border rounded-3 d-flex align-items-center gap-2 shadow-sm">
          <div class="w-8 h-8 rounded-2 bg-warning text-dark d-flex align-items-center justify-content-center fw-bold" style="width:36px;height:36px;">
            <i class="bi bi-exclamation-triangle-fill"></i>
          </div>
          <div>
            <div class="small text-muted" style="font-size:11px;">WASPADA (KUNING)</div>
            <strong class="text-warning text-dark">3 Kecamatan</strong>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="p-2.5 bg-white border rounded-3 d-flex align-items-center gap-2 shadow-sm">
          <div class="w-8 h-8 rounded-2 bg-success text-white d-flex align-items-center justify-content-center fw-bold" style="width:36px;height:36px;">
            <i class="bi bi-shield-check"></i>
          </div>
          <div>
            <div class="small text-muted" style="font-size:11px;">TERKENDALI (HIJAU)</div>
            <strong class="text-success">4 Kecamatan</strong>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="p-2.5 bg-white border rounded-3 d-flex align-items-center gap-2 shadow-sm">
          <div class="w-8 h-8 rounded-2 bg-teal text-white d-flex align-items-center justify-content-center fw-bold" style="background:#0d9488;width:36px;height:36px;">
            <i class="bi bi-hospital"></i>
          </div>
          <div>
            <div class="small text-muted" style="font-size:11px;">TOTAL PUSKESMAS</div>
            <strong>8 UPT Pembina</strong>
          </div>
        </div>
      </div>
    </div>

    <!-- MAIN GIS MAP & DETAILS ROW -->
    <div class="row g-3">
      <div class="col-12 col-lg-8">
        <div class="card-dinkes p-2">
          <div id="gis-map"></div>
        </div>
      </div>
      <div class="col-12 col-lg-4" id="gis-details-panel">
        <!-- Default selected district Cibadak (KLB) -->
        <div class="card-dinkes h-100 border-start border-4 border-danger">
          <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <div>
              <span class="badge badge-alert-klb me-2">Alert KLB</span>
              <strong class="fs-6">Kecamatan Cibadak</strong>
            </div>
            <span class="small text-muted font-monospace">PKM003</span>
          </div>
          <div class="card-body">
            <h6 class="fw-bold mb-1">Puskesmas Cibadak Sehat</h6>
            <p class="text-muted small mb-3"><i class="bi bi-star-fill text-warning me-1"></i> Akreditasi: <strong>Utama</strong> &bull; Rawat Inap &bull; 54.300 Jiwa</p>

            <div class="row g-2 mb-3">
              <div class="col-6">
                <div class="p-2.5 bg-light rounded-3">
                  <span class="text-muted small">Penyakit Terbanyak</span>
                  <div class="fw-bold text-slate-800">DBD (Demam Berdarah)</div>
                  <div class="fw-bold text-danger fs-5">34 Kasus <small class="fs-6 text-dark">(1 Wafat)</small></div>
                </div>
              </div>
              <div class="col-6">
                <div class="p-2.5 bg-light rounded-3">
                  <span class="text-muted small">Prevalensi Stunting</span>
                  <div class="fw-bold text-warning fs-5">13.2%</div>
                  <div class="small text-muted">Di Atas Target (&le; 11.5%)</div>
                </div>
              </div>
            </div>

            <div class="alert alert-danger py-2 px-3 small mb-3">
              <strong><i class="bi bi-exclamation-octagon-fill me-1"></i> Peringatan Sinyal KLB:</strong><br>
              Melebihi batas ambang epidemik minggu ke-46. Telah dilakukan Penyelidikan Epidemiologi (PE) radius 200m di Desa Sukaresmi & Cibadak Girang. Fogging fokus dan pembagian abate massal sedang berjalan.
            </div>

            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-danger w-50" onclick="filterSurveilansByPkm('PKM003')">
                <i class="bi bi-activity me-1"></i> Buka Surveilans
              </button>
              <button class="btn btn-sm btn-primary w-50" onclick="switchView('puskesmas')">
                <i class="bi bi-hospital me-1"></i> Detail Puskesmas
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  setTimeout(() => {
    gisMapInstance = initGISMap('gis-map', 'all');
  }, 100);
}

function filterGISView(mode) {
  if (gisMapInstance) {
    gisMapInstance.remove();
    gisMapInstance = null;
  }
  gisMapInstance = initGISMap('gis-map', mode);
}

// -------------------------------------------------------------
// 2. FASILITAS KESEHATAN (PUSKESMAS & NAKES)
// -------------------------------------------------------------
function renderPuskesmas(container) {
  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Manajemen Puskesmas & Faskes Daerah</h3>
        <p class="text-muted mb-0">Pendataan Unit Pelaksana Teknis (UPT) Puskesmas & Tenaga Kesehatan Se-Kabupaten</p>
      </div>
      <div>
        <button class="btn btn-primary" onclick="openPuskesmasModal()"><i class="bi bi-plus-circle me-1"></i> Tambah Puskesmas</button>
      </div>
    </div>

    <div class="card-dinkes">
      <div class="card-header bg-white">
        <div class="row g-2 w-100 align-items-center">
          <div class="col-12 col-md-5">
            <div class="input-group input-group-sm">
              <span class="input-group-text bg-light border-end-0"><i class="bi bi-search"></i></span>
              <input type="text" id="search-pkm" class="form-control border-start-0" placeholder="Cari nama puskesmas, kecamatan, kepala..." onkeyup="filterPuskesmasTable()">
            </div>
          </div>
          <div class="col-6 col-md-3">
            <select id="filter-akreditasi" class="form-select form-select-sm" onchange="filterPuskesmasTable()">
              <option value="">Semua Akreditasi</option>
              <option value="Paripurna">Paripurna</option>
              <option value="Utama">Utama</option>
              <option value="Madya">Madya</option>
            </select>
          </div>
          <div class="col-6 col-md-4 text-md-end">
            <span class="badge bg-light text-dark border">Total: <strong id="pkm-count">${appData.puskesmas.length}</strong> Faskes</span>
          </div>
        </div>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover table-dinkes mb-0" id="table-pkm">
            <thead>
              <tr>
                <th>Kode & Nama Puskesmas</th>
                <th>Kecamatan</th>
                <th>Tipe & Akreditasi</th>
                <th>Kepala Puskesmas</th>
                <th>SDM Kesehatan</th>
                <th>Wilayah / Populasi</th>
                <th class="text-end">Aksi</th>
              </tr>
            </thead>
            <tbody>
              ${appData.puskesmas.map(p => `
                <tr data-id="${p.id}">
                  <td>
                    <span class="badge bg-secondary-subtle text-secondary font-monospace">${p.id}</span>
                    <div class="fw-bold mt-1 text-slate-800">${p.nama}</div>
                    <small class="text-muted"><i class="bi bi-telephone"></i> ${p.kontak}</small>
                  </td>
                  <td>${p.kecamatan}</td>
                  <td>
                    <div><span class="badge ${p.tipe === 'Rawat Inap' ? 'bg-primary-subtle text-primary' : 'bg-light text-secondary border'}">${p.tipe}</span></div>
                    <div class="mt-1">
                      <span class="badge ${p.akreditasi === 'Paripurna' ? 'badge-paripurna' : (p.akreditasi === 'Utama' ? 'badge-utama' : 'badge-madya')}">
                        <i class="bi bi-star-fill text-warning me-1"></i>${p.akreditasi}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div class="fw-semibold">${p.kepala}</div>
                    <small class="text-success"><i class="bi bi-check-circle-fill"></i> ${p.status}</small>
                  </td>
                  <td>
                    <div class="small">
                      <div><strong>${p.jml_dokter}</strong> Dokter Umum/Gigi</div>
                      <div class="text-muted">${p.jml_perawat} Perawat &bull; ${p.jml_bidan} Bidan</div>
                    </div>
                  </td>
                  <td>
                    <div class="small">
                      <div><i class="bi bi-geo"></i> ${p.wilayah_desa} Desa Binaan</div>
                      <div class="text-muted"><i class="bi bi-people"></i> ${(p.populasi || 0).toLocaleString('id-ID')} Jiwa</div>
                    </div>
                  </td>
                  <td class="text-end">
                    <div class="btn-group btn-group-sm">
                      <button class="btn btn-outline-secondary" title="Edit" onclick="editPuskesmas('${p.id}')"><i class="bi bi-pencil"></i></button>
                      <button class="btn btn-outline-danger" title="Hapus" onclick="deletePuskesmas('${p.id}')"><i class="bi bi-trash"></i></button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

function filterPuskesmasTable() {
  const query = document.getElementById('search-pkm').value.toLowerCase();
  const akreditasi = document.getElementById('filter-akreditasi').value;
  const rows = document.querySelectorAll('#table-pkm tbody tr');

  let count = 0;
  rows.forEach(row => {
    const text = row.innerText.toLowerCase();
    const matchQuery = !query || text.includes(query);
    const matchAkr = !akreditasi || text.includes(akreditasi.toLowerCase());

    if (matchQuery && matchAkr) {
      row.style.display = '';
      count++;
    } else {
      row.style.display = 'none';
    }
  });

  const countBadge = document.getElementById('pkm-count');
  if (countBadge) countBadge.textContent = count;
}

function openPuskesmasModal(item = null) {
  const isEdit = !!item;
  const modalHtml = `
    <div class="modal fade" id="pkmModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fw-bold">${isEdit ? 'Edit Data Puskesmas' : 'Tambah Faskes / Puskesmas Baru'}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <form id="pkmForm" onsubmit="savePuskesmasForm(event, '${isEdit ? item.id : ''}')">
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Kode Faskes</label>
                  <input type="text" class="form-control" name="id" value="${isEdit ? item.id : 'PKM' + String(appData.puskesmas.length + 1).padStart(3, '0')}" required ${isEdit ? 'readonly' : ''}>
                </div>
                <div class="col-md-8">
                  <label class="form-label small fw-bold">Nama Puskesmas</label>
                  <input type="text" class="form-control" name="nama" value="${isEdit ? item.nama : ''}" placeholder="Contoh: Puskesmas Sejahtera" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Kecamatan</label>
                  <input type="text" class="form-control" name="kecamatan" value="${isEdit ? item.kecamatan : ''}" placeholder="Contoh: Kec. Sukamaju" required>
                </div>
                <div class="col-md-3">
                  <label class="form-label small fw-bold">Tipe Layanan</label>
                  <select class="form-select" name="tipe">
                    <option value="Rawat Inap" ${isEdit && item.tipe === 'Rawat Inap' ? 'selected' : ''}>Rawat Inap</option>
                    <option value="Non Rawat Inap" ${isEdit && item.tipe === 'Non Rawat Inap' ? 'selected' : ''}>Non Rawat Inap</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <label class="form-label small fw-bold">Tingkat Akreditasi</label>
                  <select class="form-select" name="akreditasi">
                    <option value="Paripurna" ${isEdit && item.akreditasi === 'Paripurna' ? 'selected' : ''}>Paripurna</option>
                    <option value="Utama" ${isEdit && item.akreditasi === 'Utama' ? 'selected' : ''}>Utama</option>
                    <option value="Madya" ${isEdit && item.akreditasi === 'Madya' ? 'selected' : ''}>Madya</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Kepala Puskesmas</label>
                  <input type="text" class="form-control" name="kepala" value="${isEdit ? item.kepala : ''}" placeholder="dr. Nama Kepala" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Kontak / Telepon</label>
                  <input type="text" class="form-control" name="kontak" value="${isEdit ? item.kontak : ''}" placeholder="0812-xxxx-xxxx" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Jml Dokter</label>
                  <input type="number" class="form-control" name="jml_dokter" value="${isEdit ? item.jml_dokter : 3}" min="1" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Jml Perawat</label>
                  <input type="number" class="form-control" name="jml_perawat" value="${isEdit ? item.jml_perawat : 10}" min="1" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Jml Bidan</label>
                  <input type="number" class="form-control" name="jml_bidan" value="${isEdit ? item.jml_bidan : 8}" min="1" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Jumlah Desa Binaan</label>
                  <input type="number" class="form-control" name="wilayah_desa" value="${isEdit ? item.wilayah_desa : 5}" min="1" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Total Populasi (Jiwa)</label>
                  <input type="number" class="form-control" name="populasi" value="${isEdit ? item.populasi : 30000}" min="100" required>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  // Remove existing modal if any
  const oldModal = document.getElementById('pkmModal');
  if (oldModal) oldModal.remove();

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  const bsModal = new bootstrap.Modal(document.getElementById('pkmModal'));
  bsModal.show();
}

function savePuskesmasForm(e, editId) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  const pkmObj = {
    id: formData.get('id'),
    nama: formData.get('nama'),
    kecamatan: formData.get('kecamatan'),
    tipe: formData.get('tipe'),
    akreditasi: formData.get('akreditasi'),
    kepala: formData.get('kepala'),
    kontak: formData.get('kontak'),
    jml_dokter: parseInt(formData.get('jml_dokter')),
    jml_perawat: parseInt(formData.get('jml_perawat')),
    jml_bidan: parseInt(formData.get('jml_bidan')),
    wilayah_desa: parseInt(formData.get('wilayah_desa')),
    populasi: parseInt(formData.get('populasi')),
    status: 'Aktif'
  };

  if (editId) {
    const idx = appData.puskesmas.findIndex(p => p.id === editId);
    if (idx !== -1) {
      appData.puskesmas[idx] = pkmObj;
      showToast("Data Puskesmas berhasil diperbarui!", "success");
    }
  } else {
    appData.puskesmas.unshift(pkmObj);
    showToast("Puskesmas baru berhasil ditambahkan!", "success");
  }

  saveData();
  bootstrap.Modal.getInstance(document.getElementById('pkmModal')).hide();
  renderPuskesmas(document.getElementById('view-container'));
}

function editPuskesmas(id) {
  const item = appData.puskesmas.find(p => p.id === id);
  if (item) {
    openPuskesmasModal(item);
  }
}

function deletePuskesmas(id) {
  if (confirm(`Apakah Anda yakin ingin menghapus data Puskesmas ${id}?`)) {
    appData.puskesmas = appData.puskesmas.filter(p => p.id !== id);
    saveData();
    showToast("Puskesmas berhasil dihapus.", "warning");
    renderPuskesmas(document.getElementById('view-container'));
  }
}

// -------------------------------------------------------------
// 3. SURVEILANS & SKDR (P2P - WABAH & KLB)
// -------------------------------------------------------------
function renderSurveilans(container) {
  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Surveilans Epidemiologi & SKDR</h3>
        <p class="text-muted mb-0">Sistem Kewaspadaan Dini dan Respon Penyakit Menular Potensi Kejadian Luar Biasa (KLB)</p>
      </div>
      <div>
        <button class="btn btn-danger" onclick="openSurveilansModal()"><i class="bi bi-bell-fill me-1"></i> Input Laporan Kasus Baru</button>
      </div>
    </div>

    <!-- ALERT BANNER JIKA ADA STATUS KLB -->
    ${appData.surveilans.some(s => s.status_alert === 'Alert KLB') ? `
      <div class="alert alert-danger border-danger d-flex align-items-center gap-3 mb-4 shadow-sm" role="alert">
        <i class="bi bi-exclamation-octagon-fill fs-2 text-danger"></i>
        <div>
          <h6 class="alert-heading fw-bold mb-0">PERINGATAN DINI: Terdeteksi Lonjakan Kasus Melebihi Ambang Batas!</h6>
          <p class="small mb-0">Wilayah Puskesmas Cibadak Sehat melaporkan peningkatan kasus DBD yang berpotensi KLB. Tim Gerak Cepat (TGC) Dinkes diinstruksikan melakukan Penyelidikan Epidemiologi (PE).</p>
        </div>
      </div>
    ` : ''}

    <div class="card-dinkes">
      <div class="card-header bg-white">
        <div class="row g-2 w-100 align-items-center">
          <div class="col-12 col-md-5">
            <div class="input-group input-group-sm">
              <span class="input-group-text bg-light border-end-0"><i class="bi bi-search"></i></span>
              <input type="text" id="search-srv" class="form-control border-start-0" placeholder="Cari penyakit, puskesmas..." onkeyup="filterSurveilansTable()">
            </div>
          </div>
          <div class="col-6 col-md-3">
            <select id="filter-status-alert" class="form-select form-select-sm" onchange="filterSurveilansTable()">
              <option value="">Semua Status Alert</option>
              <option value="Alert KLB">Alert KLB</option>
              <option value="Waspada">Waspada</option>
              <option value="Normal">Normal</option>
            </select>
          </div>
          <div class="col-6 col-md-4 text-md-end">
            <span class="badge bg-light text-dark border">Total: <strong>${appData.surveilans.length}</strong> Laporan</span>
          </div>
        </div>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover table-dinkes mb-0" id="table-srv">
            <thead>
              <tr>
                <th>ID & Tanggal</th>
                <th>Puskesmas Pelapor</th>
                <th>Nama Penyakit & Kategori</th>
                <th class="text-center">Kasus / Meninggal</th>
                <th>Status Alert SKDR</th>
                <th>Catatan / Tindak Lanjut</th>
                <th class="text-end">Aksi</th>
              </tr>
            </thead>
            <tbody>
              ${appData.surveilans.map(s => `
                <tr data-id="${s.id}">
                  <td>
                    <span class="font-monospace small fw-bold text-secondary">${s.id}</span>
                    <div class="small text-muted">${s.tanggal}</div>
                  </td>
                  <td>
                    <div class="fw-bold">${s.puskesmas_nama}</div>
                    <span class="badge bg-light text-muted border">${s.puskesmas_id}</span>
                  </td>
                  <td>
                    <div class="fw-bold text-slate-800">${s.penyakit}</div>
                    <small class="text-muted">${s.kategori}</small>
                  </td>
                  <td class="text-center">
                    <span class="badge bg-danger fs-6">${s.jumlah_kasus}</span>
                    ${s.meninggal > 0 ? `<div class="small text-danger fw-bold mt-1">${s.meninggal} Meninggal</div>` : '<div class="small text-muted mt-1">0 Meninggal</div>'}
                  </td>
                  <td>
                    <span class="badge ${s.status_alert === 'Alert KLB' ? 'badge-alert-klb' : (s.status_alert === 'Waspada' ? 'badge-waspada' : 'badge-normal')}">
                      ${s.status_alert === 'Alert KLB' ? '<i class="bi bi-exclamation-diamond-fill me-1"></i>' : ''}
                      ${s.status_alert}
                    </span>
                  </td>
                  <td>
                    <small class="text-secondary">${s.catatan || '-'}</small>
                  </td>
                  <td class="text-end">
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteSurveilans('${s.id}')"><i class="bi bi-trash"></i></button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

function filterSurveilansByPkm(pkmId) {
  switchView('surveilans');
  setTimeout(() => {
    const searchInput = document.getElementById('search-srv');
    if (searchInput) {
      searchInput.value = pkmId;
      filterSurveilansTable();
    }
  }, 100);
}

function filterSurveilansTable() {
  const query = document.getElementById('search-srv').value.toLowerCase();
  const alertStatus = document.getElementById('filter-status-alert').value;
  const rows = document.querySelectorAll('#table-srv tbody tr');

  rows.forEach(row => {
    const text = row.innerText.toLowerCase();
    const matchQuery = !query || text.includes(query);
    const matchAlert = !alertStatus || text.includes(alertStatus.toLowerCase());

    row.style.display = (matchQuery && matchAlert) ? '' : 'none';
  });
}

function openSurveilansModal() {
  const modalHtml = `
    <div class="modal fade" id="srvModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header bg-danger text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-bell-fill me-2"></i> Input Laporan Kasus Surveilans Baru</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <form onsubmit="saveSurveilansForm(event)">
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Puskesmas Pelapor</label>
                  <select class="form-select" name="puskesmas_id" required>
                    ${appData.puskesmas.map(p => `<option value="${p.id}">${p.nama} (${p.kecamatan})</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Tanggal Pelaporan</label>
                  <input type="date" class="form-control" name="tanggal" value="${new Date().toISOString().split('T')[0]}" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Nama Penyakit</label>
                  <select class="form-select" name="penyakit" required>
                    <option value="Demam Berdarah Dengue (DBD)">Demam Berdarah Dengue (DBD)</option>
                    <option value="Infeksi Saluran Pernapasan Akut (ISPA)">Infeksi Saluran Pernapasan Akut (ISPA)</option>
                    <option value="Diare Akut">Diare Akut</option>
                    <option value="Tuberkulosis (TBC)">Tuberkulosis (TBC)</option>
                    <option value="Suspek Campak / Morbili">Suspek Campak / Morbili</option>
                    <option value="Difteri">Difteri</option>
                    <option value="Malaria">Malaria</option>
                    <option value="Leptospirosis">Leptospirosis</option>
                    <option value="Gigitan Hewan Penular Rabies (GHPR)">Gigitan Hewan Penular Rabies (GHPR)</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Kategori Surveilans</label>
                  <select class="form-select" name="kategori">
                    <option value="Penyakit Menular Potensi KLB">Penyakit Menular Potensi KLB</option>
                    <option value="Penyakit Menular Kronis">Penyakit Menular Kronis</option>
                    <option value="Penyakit Tidak Menular (PTM)">Penyakit Tidak Menular (PTM)</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Jumlah Kasus Baru</label>
                  <input type="number" class="form-control" name="jumlah_kasus" min="1" value="5" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Jumlah Kematian</label>
                  <input type="number" class="form-control" name="meninggal" min="0" value="0">
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Status Alert SKDR</label>
                  <select class="form-select" name="status_alert">
                    <option value="Normal">Normal</option>
                    <option value="Waspada" selected>Waspada</option>
                    <option value="Alert KLB">Alert KLB</option>
                  </select>
                </div>
                <div class="col-12">
                  <label class="form-label small fw-bold">Catatan Penyelidikan Epidemiologi / Respon Tindakan</label>
                  <textarea class="form-control" name="catatan" rows="3" placeholder="Contoh: Telah dilakukan Penyelidikan Epidemiologi (PE) di radius 100m, ditemukan jentik di penampungan air..."></textarea>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-danger"><i class="bi bi-save me-1"></i> Simpan Laporan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  const oldModal = document.getElementById('srvModal');
  if (oldModal) oldModal.remove();

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  new bootstrap.Modal(document.getElementById('srvModal')).show();
}

function saveSurveilansForm(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  const pkmId = formData.get('puskesmas_id');
  const pkm = appData.puskesmas.find(p => p.id === pkmId);

  const newSrv = {
    id: `SRV-2026-${String(appData.surveilans.length + 1).padStart(3, '0')}`,
    tanggal: formData.get('tanggal'),
    puskesmas_id: pkmId,
    puskesmas_nama: pkm ? pkm.nama : pkmId,
    penyakit: formData.get('penyakit'),
    kategori: formData.get('kategori'),
    jumlah_kasus: parseInt(formData.get('jumlah_kasus')),
    meninggal: parseInt(formData.get('meninggal') || 0),
    status_alert: formData.get('status_alert'),
    catatan: formData.get('catatan')
  };

  appData.surveilans.unshift(newSrv);
  saveData();
  showToast("Laporan surveilans berhasil disimpan dan terintegrasi ke SKDR!", "success");

  bootstrap.Modal.getInstance(document.getElementById('srvModal')).hide();
  renderSurveilans(document.getElementById('view-container'));
}

function deleteSurveilans(id) {
  if (confirm(`Hapus laporan surveilans ${id}?`)) {
    appData.surveilans = appData.surveilans.filter(s => s.id !== id);
    saveData();
    showToast("Laporan dihapus.", "warning");
    renderSurveilans(document.getElementById('view-container'));
  }
}

// -------------------------------------------------------------
// 4. KESMAS & PROGRAM STUNTING
// -------------------------------------------------------------
function renderKesmas(container) {
  const totalBalita = appData.stunting.reduce((acc, s) => acc + s.total_balita, 0);
  const totalStunting = appData.stunting.reduce((acc, s) => acc + s.balita_stunting, 0);
  const totalWasting = appData.stunting.reduce((acc, s) => acc + s.balita_wasting, 0);
  const avgImunisasi = (appData.stunting.reduce((acc, s) => acc + s.cakupan_imunisasi, 0) / (appData.stunting.length || 1)).toFixed(1);

  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Kesehatan Masyarakat & Program Stunting</h3>
        <p class="text-muted mb-0">Pemantauan Status Gizi Balita & Cakupan Imunisasi Dasar Lengkap (IDL)</p>
      </div>
      <div>
        <button class="btn btn-success" onclick="openStuntingModal()"><i class="bi bi-plus-circle me-1"></i> Update Data Balita / Stunting</button>
      </div>
    </div>

    <!-- STAT SUMMARY KESMAS -->
    <div class="row g-3 mb-4">
      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <span class="text-muted small fw-semibold">TOTAL BALITA TERDATA</span>
          <h3 class="fw-bold my-1 text-primary">${totalBalita.toLocaleString('id-ID')}</h3>
          <div class="small text-muted">Sasaran Posyandu se-Kabupaten</div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <span class="text-muted small fw-semibold">BALITA STUNTING (PENDEK)</span>
          <h3 class="fw-bold my-1 text-danger">${totalStunting.toLocaleString('id-ID')}</h3>
          <div class="small text-danger fw-semibold">Prevalensi Rata-rata: ${((totalStunting/totalBalita)*100).toFixed(1)}%</div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <span class="text-muted small fw-semibold">BALITA WASTING (GIZI KURANG)</span>
          <h3 class="fw-bold my-1 text-warning">${totalWasting.toLocaleString('id-ID')}</h3>
          <div class="small text-muted">Pemberian Makanan Tambahan (PMT) Aktif</div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
          <span class="text-muted small fw-semibold">CAKUPAN IMUNISASI (IDL)</span>
          <h3 class="fw-bold my-1 text-success">${avgImunisasi}%</h3>
          <div class="small text-success fw-semibold"><i class="bi bi-shield-check"></i> Di atas target nasional (&ge; 90%)</div>
        </div>
      </div>
    </div>

    <div class="card-dinkes">
      <div class="card-header bg-white">
        <span class="fw-bold">Matriks Capaian Stunting & Imunisasi Per Wilayah Puskesmas</span>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover table-dinkes mb-0">
            <thead>
              <tr>
                <th>Puskesmas / Kecamatan</th>
                <th class="text-end">Balita Terdata</th>
                <th class="text-end">Balita Ditimbang</th>
                <th class="text-end">Stunting</th>
                <th class="text-center">Prevalensi (%)</th>
                <th class="text-center">Cakupan Imunisasi</th>
                <th>Status Evaluasi Kinerja</th>
              </tr>
            </thead>
            <tbody>
              ${appData.stunting.map(st => {
                const isUnder = st.persen_stunting <= st.target_kab;
                return `
                  <tr>
                    <td>
                      <div class="fw-bold">${st.puskesmas_nama}</div>
                      <small class="text-muted">Kec. ${st.kecamatan}</small>
                    </td>
                    <td class="text-end">${st.total_balita.toLocaleString('id-ID')}</td>
                    <td class="text-end">${st.balita_ditimbang.toLocaleString('id-ID')}</td>
                    <td class="text-end fw-bold text-danger">${st.balita_stunting}</td>
                    <td class="text-center">
                      <span class="badge ${isUnder ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'} fw-bold fs-6">
                        ${st.persen_stunting}%
                      </span>
                    </td>
                    <td class="text-center">
                      <div class="fw-semibold">${st.cakupan_imunisasi}%</div>
                      <div class="progress mt-1" style="height: 5px;">
                        <div class="progress-bar bg-success" style="width: ${st.cakupan_imunisasi}%"></div>
                      </div>
                    </td>
                    <td>
                      <span class="badge ${isUnder ? 'bg-success' : 'bg-warning text-dark'}">
                        ${st.status_kinerja}
                      </span>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

function openStuntingModal() {
  const modalHtml = `
    <div class="modal fade" id="stnModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-success text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i> Update Capaian Stunting Puskesmas</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <form onsubmit="saveStuntingForm(event)">
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label small fw-bold">Pilih Puskesmas</label>
                  <select class="form-select" name="puskesmas_id" required>
                    ${appData.stunting.map(s => `<option value="${s.puskesmas_id}">${s.puskesmas_nama}</option>`).join('')}
                  </select>
                </div>
                <div class="col-6">
                  <label class="form-label small fw-bold">Total Balita Ditimbang</label>
                  <input type="number" class="form-control" name="balita_ditimbang" value="3000" min="10" required>
                </div>
                <div class="col-6">
                  <label class="form-label small fw-bold">Balita Stunting (Pendek)</label>
                  <input type="number" class="form-control" name="balita_stunting" value="250" min="0" required>
                </div>
                <div class="col-6">
                  <label class="form-label small fw-bold">Balita Wasting (Kurus)</label>
                  <input type="number" class="form-control" name="balita_wasting" value="60" min="0" required>
                </div>
                <div class="col-6">
                  <label class="form-label small fw-bold">Cakupan Imunisasi IDL (%)</label>
                  <input type="number" step="0.1" class="form-control" name="cakupan_imunisasi" value="95.0" min="0" max="100" required>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success"><i class="bi bi-save me-1"></i> Simpan Pembaruan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  const oldModal = document.getElementById('stnModal');
  if (oldModal) oldModal.remove();

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  new bootstrap.Modal(document.getElementById('stnModal')).show();
}

function saveStuntingForm(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  const pkmId = formData.get('puskesmas_id');

  const idx = appData.stunting.findIndex(s => s.puskesmas_id === pkmId);
  if (idx !== -1) {
    const ditimbang = parseInt(formData.get('balita_ditimbang'));
    const stunting = parseInt(formData.get('balita_stunting'));
    const persen = parseFloat(((stunting / ditimbang) * 100).toFixed(1));

    appData.stunting[idx].balita_ditimbang = ditimbang;
    appData.stunting[idx].balita_stunting = stunting;
    appData.stunting[idx].balita_wasting = parseInt(formData.get('balita_wasting'));
    appData.stunting[idx].persen_stunting = persen;
    appData.stunting[idx].cakupan_imunisasi = parseFloat(formData.get('cakupan_imunisasi'));
    appData.stunting[idx].status_kinerja = persen <= appData.stunting[idx].target_kab ? 'Sangat Baik (Di Bawah Target)' : 'Perlu Intervensi Khusus';

    saveData();
    showToast(`Data stunting untuk ${appData.stunting[idx].puskesmas_nama} diperbarui!`, "success");
  }

  bootstrap.Modal.getInstance(document.getElementById('stnModal')).hide();
  renderKesmas(document.getElementById('view-container'));
}

// -------------------------------------------------------------
// 5. GUDANG FARMASI (GFK) & DISTRIBUSI LOGISTIK
// -------------------------------------------------------------
function renderFarmasi(container) {
  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Gudang Farmasi Kabupaten (GFK)</h3>
        <p class="text-muted mb-0">Pengelolaan Buffer Stock Obat Esensial, Vaksin, dan Distribusi (SBBK) ke Puskesmas</p>
      </div>
      <div class="d-flex gap-2">
        <button class="btn btn-outline-primary" onclick="openTambahObatModal()"><i class="bi bi-plus-circle me-1"></i> Tambah Master Obat</button>
        <button class="btn btn-primary" onclick="openDistribusiModal()"><i class="bi bi-truck me-1"></i> Buat Surat Bukti Barang Keluar (SBBK)</button>
      </div>
    </div>

    <!-- TAB NAVIGATION -->
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
      <li class="nav-item">
        <button class="nav-link active fw-bold" id="pills-obat-tab" data-bs-toggle="pill" data-bs-target="#pills-obat">
          <i class="bi bi-capsule me-1"></i> Stok Obat & Vaksin Dinkes (${appData.obat_gfk.length})
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link fw-bold" id="pills-distribusi-tab" data-bs-toggle="pill" data-bs-target="#pills-distribusi">
          <i class="bi bi-clock-history me-1"></i> Riwayat Pengeluaran / SBBK (${appData.distribusi.length})
        </button>
      </li>
    </ul>

    <div class="tab-content" id="pills-tabContent">
      <!-- TAB 1: STOK OBAT -->
      <div class="tab-pane fade show active" id="pills-obat">
        <div class="card-dinkes">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover table-dinkes mb-0">
                <thead>
                  <tr>
                    <th>Kode & Nama Obat</th>
                    <th>Kategori</th>
                    <th class="text-end">Stok Tersedia</th>
                    <th>Satuan</th>
                    <th>No. Batch & Exp Date</th>
                    <th>Status Buffer Stock</th>
                    <th class="text-end">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  ${appData.obat_gfk.map(o => `
                    <tr>
                      <td>
                        <span class="font-monospace small text-muted">${o.kode}</span>
                        <div class="fw-bold text-slate-800">${o.nama_obat}</div>
                      </td>
                      <td><span class="badge bg-light text-secondary border">${o.kategori}</span></td>
                      <td class="text-end fw-bold fs-6">
                        ${o.stok_dinkes.toLocaleString('id-ID')}
                      </td>
                      <td>${o.satuan}</td>
                      <td>
                        <div><small class="fw-semibold">${o.batch}</small></div>
                        <div class="small ${new Date(o.exp_date) < new Date('2027-01-01') ? 'text-danger fw-bold' : 'text-muted'}">
                          <i class="bi bi-calendar-event"></i> Exp: ${o.exp_date}
                        </div>
                      </td>
                      <td>
                        <span class="badge ${o.status_stok === 'Aman' ? 'bg-success' : (o.status_stok === 'Menipis' ? 'bg-warning text-dark' : 'bg-danger')}">
                          ${o.status_stok}
                        </span>
                      </td>
                      <td class="text-end">
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteObat('${o.id}')"><i class="bi bi-trash"></i></button>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- TAB 2: DISTRIBUSI / SBBK -->
      <div class="tab-pane fade" id="pills-distribusi">
        <div class="card-dinkes">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover table-dinkes mb-0">
                <thead>
                  <tr>
                    <th>No. SBBK & Tanggal</th>
                    <th>Puskesmas Penerima</th>
                    <th>Item Obat & Alokasi</th>
                    <th>Tujuan Permintaan</th>
                    <th>Petugas Pengirim GFK</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  ${appData.distribusi.map(dst => `
                    <tr>
                      <td>
                        <div class="fw-bold text-primary font-monospace">${dst.no_sbbk}</div>
                        <small class="text-muted"><i class="bi bi-calendar3"></i> ${dst.tanggal}</small>
                      </td>
                      <td>
                        <div class="fw-bold">${dst.puskesmas_nama}</div>
                        <span class="badge bg-light text-muted border">${dst.puskesmas_id}</span>
                      </td>
                      <td>
                        <div class="small fw-semibold text-slate-800">${dst.item_obat}</div>
                      </td>
                      <td><small class="text-secondary">${dst.tujuan}</small></td>
                      <td><small class="text-muted">${dst.petugas_gfk}</small></td>
                      <td>
                        <span class="badge ${dst.status.includes('Diterima') ? 'bg-success-subtle text-success' : 'bg-primary-subtle text-primary'}">
                          ${dst.status}
                        </span>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function openTambahObatModal() {
  const modalHtml = `
    <div class="modal fade" id="obatModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-capsule me-2"></i> Tambah Obat / Vaksin ke GFK</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <form onsubmit="saveObatForm(event)">
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label small fw-bold">Kode Obat</label>
                  <input type="text" class="form-control" name="kode" value="FAR-00${appData.obat_gfk.length + 1}" required>
                </div>
                <div class="col-md-8">
                  <label class="form-label small fw-bold">Nama Obat / Alkes</label>
                  <input type="text" class="form-control" name="nama_obat" placeholder="Contoh: Cefixime Tab 100 mg" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Kategori Farmasi</label>
                  <input type="text" class="form-control" name="kategori" placeholder="Contoh: Antibiotik / Vaksin" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Satuan Kemasan</label>
                  <input type="text" class="form-control" name="satuan" placeholder="Tablet, Vial, Botol" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Jumlah Stok Masuk</label>
                  <input type="number" class="form-control" name="stok_dinkes" value="10000" min="1" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Buffer Minimal</label>
                  <input type="number" class="form-control" name="buffer_minimal" value="2000" min="1" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Nomor Batch</label>
                  <input type="text" class="form-control" name="batch" value="BCH-2026-001" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Tanggal Kadaluarsa (Exp)</label>
                  <input type="date" class="form-control" name="exp_date" value="2028-12-31" required>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Stok</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  const oldModal = document.getElementById('obatModal');
  if (oldModal) oldModal.remove();

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  new bootstrap.Modal(document.getElementById('obatModal')).show();
}

function saveObatForm(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  const stok = parseInt(formData.get('stok_dinkes'));
  const buffer = parseInt(formData.get('buffer_minimal'));
  let status = 'Aman';
  if (stok < buffer * 0.5) status = 'Kritis';
  else if (stok <= buffer) status = 'Menipis';

  const newObat = {
    id: `OBT00${appData.obat_gfk.length + 1}`,
    kode: formData.get('kode'),
    nama_obat: formData.get('nama_obat'),
    kategori: formData.get('kategori'),
    stok_dinkes: stok,
    satuan: formData.get('satuan'),
    batch: formData.get('batch'),
    exp_date: formData.get('exp_date'),
    buffer_minimal: buffer,
    status_stok: status
  };

  appData.obat_gfk.unshift(newObat);
  saveData();
  showToast("Obat baru berhasil ditambahkan ke inventaris GFK!", "success");

  bootstrap.Modal.getInstance(document.getElementById('obatModal')).hide();
  renderFarmasi(document.getElementById('view-container'));
}

function deleteObat(id) {
  if (confirm(`Hapus item obat ${id}?`)) {
    appData.obat_gfk = appData.obat_gfk.filter(o => o.id !== id);
    saveData();
    showToast("Item obat dihapus.", "warning");
    renderFarmasi(document.getElementById('view-container'));
  }
}

function openDistribusiModal() {
  const modalHtml = `
    <div class="modal fade" id="dstModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header bg-dark text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-truck me-2"></i> Buat Surat Bukti Barang Keluar (SBBK)</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <form onsubmit="saveDistribusiForm(event)">
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Nomor Dokumen SBBK</label>
                  <input type="text" class="form-control" name="no_sbbk" value="SBBK/GFK/XI/2026/08${appData.distribusi.length + 1}" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Tanggal Distribusi</label>
                  <input type="date" class="form-control" name="tanggal" value="${new Date().toISOString().split('T')[0]}" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Puskesmas Penerima</label>
                  <select class="form-select" name="puskesmas_id" required>
                    ${appData.puskesmas.map(p => `<option value="${p.id}">${p.nama} (${p.kecamatan})</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-bold">Petugas Farmasi Pengirim</label>
                  <input type="text" class="form-control" name="petugas_gfk" value="Apt. Wahyu Pratama, S.Farm" required>
                </div>
                <div class="col-12">
                  <label class="form-label small fw-bold">Item Obat & Jumlah Alokasi</label>
                  <textarea class="form-control" name="item_obat" rows="2" placeholder="Contoh: Paracetamol 500mg (10.000 tab), Amoxicillin (5.000 kaplet)" required></textarea>
                </div>
                <div class="col-12">
                  <label class="form-label small fw-bold">Tujuan / Keperluan Permintaan</label>
                  <input type="text" class="form-control" name="tujuan" placeholder="Contoh: Pemenuhan buffer stock rutin / Posyandu balita" required>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-primary"><i class="bi bi-printer me-1"></i> Terbitkan & Simpan SBBK</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  const oldModal = document.getElementById('dstModal');
  if (oldModal) oldModal.remove();

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  new bootstrap.Modal(document.getElementById('dstModal')).show();
}

function saveDistribusiForm(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  const pkmId = formData.get('puskesmas_id');
  const pkm = appData.puskesmas.find(p => p.id === pkmId);

  const newDst = {
    id: `DST-2026-08${appData.distribusi.length + 1}`,
    no_sbbk: formData.get('no_sbbk'),
    tanggal: formData.get('tanggal'),
    puskesmas_id: pkmId,
    puskesmas_nama: pkm ? pkm.nama : pkmId,
    item_obat: formData.get('item_obat'),
    tujuan: formData.get('tujuan'),
    petugas_gfk: formData.get('petugas_gfk'),
    status: 'Dalam Pengiriman'
  };

  appData.distribusi.unshift(newDst);
  saveData();
  showToast("Dokumen pengeluaran SBBK berhasil dibuat!", "success");

  bootstrap.Modal.getInstance(document.getElementById('dstModal')).hide();
  renderFarmasi(document.getElementById('view-container'));
}

// -------------------------------------------------------------
// 6. LAPORAN RESMI & CETAK DINKES (PRINT & EXCEL EXPORT)
// -------------------------------------------------------------
function renderLaporan(container) {
  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800">Laporan Eksekutif & Rekapitulasi Daerah</h3>
        <p class="text-muted mb-0">Cetak Laporan Resmi Ber-KOP Dinas Kesehatan & Ekspor Data Excel / CSV</p>
      </div>
      <div class="d-flex gap-2">
        <button class="btn btn-outline-success" onclick="exportDataCSV()"><i class="bi bi-file-earmark-excel me-1"></i> Ekspor CSV / Excel</button>
        <button class="btn btn-primary" onclick="printOfficialReport()"><i class="bi bi-printer-fill me-1"></i> Cetak / Simpan PDF</button>
      </div>
    </div>

    <!-- PREVIEW LAPORAN BER-KOP SURAT RESMI -->
    <div class="card-dinkes p-4 bg-white border shadow-sm">
      <div class="kop-surat">
        <div class="kop-logo d-flex align-items-center justify-content-center bg-teal text-white rounded-3 fs-1 fw-bold" style="background:#0d9488">
          <i class="bi bi-hospital"></i>
        </div>
        <div class="kop-text">
          <h4>PEMERINTAH DAERAH PROVINSI ${appData.profil_dinkes.provinsi.toUpperCase()}</h4>
          <h2>${appData.profil_dinkes.nama_instansi.toUpperCase()}</h2>
          <p>${appData.profil_dinkes.alamat} | Telp: ${appData.profil_dinkes.telepon} | Email: ${appData.profil_dinkes.email}</p>
        </div>
      </div>

      <div class="text-center my-4">
        <h5 class="fw-bold text-decoration-underline mb-1">LAPORAN MONITORING SITUASI KESEHATAN DAERAH</h5>
        <div class="text-muted small">Periode: November ${appData.profil_dinkes.tahun_anggaran} | Wilayah Kerja Seluruh UPT Puskesmas</div>
      </div>

      <!-- REKAPITULASI FASILITAS & SDMK -->
      <h6 class="fw-bold border-bottom pb-2 mt-4 text-primary"><i class="bi bi-1-circle-fill me-1"></i> Ringkasan Fasilitas & Ketenagaan Kesehatan</h6>
      <table class="table table-bordered table-sm mb-4 small">
        <thead class="table-light">
          <tr>
            <th>Total Puskesmas</th>
            <th>Rawat Inap</th>
            <th>Non Rawat Inap</th>
            <th>Akreditasi Paripurna</th>
            <th>Total Dokter</th>
            <th>Total Perawat</th>
            <th>Total Bidan</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="fw-bold">${appData.puskesmas.length} Unit</td>
            <td>${appData.puskesmas.filter(p => p.tipe === 'Rawat Inap').length} Unit</td>
            <td>${appData.puskesmas.filter(p => p.tipe === 'Non Rawat Inap').length} Unit</td>
            <td>${appData.puskesmas.filter(p => p.akreditasi === 'Paripurna').length} Unit</td>
            <td class="fw-bold">${appData.puskesmas.reduce((a,b)=>a+b.jml_dokter,0)} Orang</td>
            <td>${appData.puskesmas.reduce((a,b)=>a+b.jml_perawat,0)} Orang</td>
            <td>${appData.puskesmas.reduce((a,b)=>a+b.jml_bidan,0)} Orang</td>
          </tr>
        </tbody>
      </table>

      <!-- REKAPITULASI SURVEILANS POTENSI KLB -->
      <h6 class="fw-bold border-bottom pb-2 mt-4 text-danger"><i class="bi bi-2-circle-fill me-1"></i> Situasi Surveilans Penyakit Potensi KLB (EWARS)</h6>
      <table class="table table-bordered table-sm mb-4 small">
        <thead class="table-light">
          <tr>
            <th>Tanggal</th>
            <th>Puskesmas</th>
            <th>Penyakit Teridentifikasi</th>
            <th>Jumlah Kasus</th>
            <th>Status Peringatan</th>
            <th>Tindak Lanjut / Respon</th>
          </tr>
        </thead>
        <tbody>
          ${appData.surveilans.map(s => `
            <tr>
              <td>${s.tanggal}</td>
              <td class="fw-semibold">${s.puskesmas_nama}</td>
              <td>${s.penyakit}</td>
              <td class="fw-bold text-center">${s.jumlah_kasus}</td>
              <td><span class="badge ${s.status_alert === 'Alert KLB' ? 'bg-danger' : (s.status_alert === 'Waspada' ? 'bg-warning text-dark' : 'bg-success')}">${s.status_alert}</span></td>
              <td>${s.catatan || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <!-- REKAPITULASI STUNTING -->
      <h6 class="fw-bold border-bottom pb-2 mt-4 text-success"><i class="bi bi-3-circle-fill me-1"></i> Capaian Penurunan Stunting & Imunisasi Balita</h6>
      <table class="table table-bordered table-sm mb-4 small">
        <thead class="table-light">
          <tr>
            <th>Puskesmas</th>
            <th class="text-end">Balita Sasaran</th>
            <th class="text-end">Ditimbang</th>
            <th class="text-end">Stunting</th>
            <th class="text-center">Prevalensi</th>
            <th class="text-center">Imunisasi (IDL)</th>
            <th>Status Evaluasi</th>
          </tr>
        </thead>
        <tbody>
          ${appData.stunting.map(st => `
            <tr>
              <td class="fw-semibold">${st.puskesmas_nama}</td>
              <td class="text-end">${st.total_balita.toLocaleString('id-ID')}</td>
              <td class="text-end">${st.balita_ditimbang.toLocaleString('id-ID')}</td>
              <td class="text-end fw-bold">${st.balita_stunting}</td>
              <td class="text-center fw-bold">${st.persen_stunting}%</td>
              <td class="text-center">${st.cakupan_imunisasi}%</td>
              <td>${st.status_kinerja}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <!-- TANDA TANGAN KEPALA DINAS KESEHATAN -->
      <div class="row mt-5 pt-3">
        <div class="col-6"></div>
        <div class="col-6 text-center">
          <p class="mb-1">Ditetapkan di: Kabupaten Sehat Sejahtera</p>
          <p class="mb-5">Pada tanggal: ${new Date().toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'})}<br><strong>KEPALA DINAS KESEHATAN</strong></p>
          <br><br>
          <p class="fw-bold text-decoration-underline mb-0">${appData.profil_dinkes.kepala_dinas}</p>
          <p class="text-muted small">NIP. ${appData.profil_dinkes.nip_kepala}</p>
        </div>
      </div>
    </div>
  `;
}

// Print View Generator
function printOfficialReport() {
  const printContainer = document.getElementById('official-print-view');
  if (!printContainer) return;

  printContainer.innerHTML = `
    <div class="kop-surat">
      <div class="kop-text">
        <h4>PEMERINTAH DAERAH PROVINSI ${appData.profil_dinkes.provinsi.toUpperCase()}</h4>
        <h2>${appData.profil_dinkes.nama_instansi.toUpperCase()}</h2>
        <p>${appData.profil_dinkes.alamat} | Telp: ${appData.profil_dinkes.telepon} | Email: ${appData.profil_dinkes.email}</p>
      </div>
    </div>

    <div style="text-align: center; margin: 25px 0;">
      <h3 style="margin: 0; text-decoration: underline;">LAPORAN MONITORING SITUASI KESEHATAN DAERAH</h3>
      <p style="margin: 5px 0; font-size: 11pt;">Tahun Anggaran ${appData.profil_dinkes.tahun_anggaran} &bull; Laporan Terpadu EWARS, Puskesmas, Gizi & Farmasi</p>
    </div>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 20px;">I. FASILITAS KESEHATAN & SUMBER DAYA MANUSIA</h4>
    <table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 10pt; margin-bottom: 20px;">
      <thead>
        <tr bgcolor="#f0f0f0">
          <th>Kode</th>
          <th>Nama Puskesmas</th>
          <th>Kecamatan</th>
          <th>Tipe</th>
          <th>Akreditasi</th>
          <th>Dokter</th>
          <th>Perawat</th>
          <th>Bidan</th>
        </tr>
      </thead>
      <tbody>
        ${appData.puskesmas.map(p => `
          <tr>
            <td>${p.id}</td>
            <td><strong>${p.nama}</strong></td>
            <td>${p.kecamatan}</td>
            <td>${p.tipe}</td>
            <td>${p.akreditasi}</td>
            <td align="center">${p.jml_dokter}</td>
            <td align="center">${p.jml_perawat}</td>
            <td align="center">${p.jml_bidan}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 20px;">II. LAPORAN SURVEILANS POTENSI KLB & SKDR</h4>
    <table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 10pt; margin-bottom: 20px;">
      <thead>
        <tr bgcolor="#f0f0f0">
          <th>Tanggal</th>
          <th>Puskesmas</th>
          <th>Penyakit</th>
          <th>Kasus</th>
          <th>Status Alert</th>
          <th>Catatan Lapangan</th>
        </tr>
      </thead>
      <tbody>
        ${appData.surveilans.map(s => `
          <tr>
            <td>${s.tanggal}</td>
            <td>${s.puskesmas_nama}</td>
            <td><strong>${s.penyakit}</strong></td>
            <td align="center">${s.jumlah_kasus}</td>
            <td>${s.status_alert}</td>
            <td>${s.catatan || '-'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 20px;">III. PREVALENSI STUNTING & IMUNISASI</h4>
    <table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 10pt; margin-bottom: 20px;">
      <thead>
        <tr bgcolor="#f0f0f0">
          <th>Puskesmas</th>
          <th>Balita Terdata</th>
          <th>Ditimbang</th>
          <th>Stunting</th>
          <th>Prevalensi (%)</th>
          <th>Imunisasi IDL (%)</th>
        </tr>
      </thead>
      <tbody>
        ${appData.stunting.map(st => `
          <tr>
            <td>${st.puskesmas_nama}</td>
            <td align="right">${st.total_balita}</td>
            <td align="right">${st.balita_ditimbang}</td>
            <td align="right"><strong>${st.balita_stunting}</strong></td>
            <td align="center"><strong>${st.persen_stunting}%</strong></td>
            <td align="center">${st.cakupan_imunisasi}%</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div style="margin-top: 40px; display: flex; justify-content: flex-end;">
      <div style="text-align: center; width: 300px; font-size: 11pt;">
        <p style="margin-bottom: 70px;">
          Kabupaten Sehat Sejahtera, ${new Date().toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'})}<br>
          <strong>KEPALA DINAS KESEHATAN</strong>
        </p>
        <p style="font-weight: bold; text-decoration: underline; margin-bottom: 2px;">${appData.profil_dinkes.kepala_dinas}</p>
        <p style="margin: 0; font-size: 9.5pt;">NIP. ${appData.profil_dinkes.nip_kepala}</p>
      </div>
    </div>
  `;

  window.print();
}

// Export CSV / Excel Format
function exportDataCSV() {
  let csvContent = "data:text/csv;charset=utf-8,";
  
  // Header Puskesmas
  csvContent += "=== DATA PUSKESMAS & FASILITAS KESEHATAN ===\r\n";
  csvContent += "Kode,Nama Puskesmas,Kecamatan,Tipe,Akreditasi,Kepala,Kontak,Dokter,Perawat,Bidan,Populasi\r\n";
  appData.puskesmas.forEach(p => {
    csvContent += `"${p.id}","${p.nama}","${p.kecamatan}","${p.tipe}","${p.akreditasi}","${p.kepala}","${p.kontak}",${p.jml_dokter},${p.jml_perawat},${p.jml_bidan},${p.populasi}\r\n`;
  });

  csvContent += "\r\n=== DATA SURVEILANS & SKDR ===\r\n";
  csvContent += "ID,Tanggal,Puskesmas,Penyakit,Kategori,Kasus,Meninggal,Status Alert,Catatan\r\n";
  appData.surveilans.forEach(s => {
    csvContent += `"${s.id}","${s.tanggal}","${s.puskesmas_nama}","${s.penyakit}","${s.kategori}",${s.jumlah_kasus},${s.meninggal},"${s.status_alert}","${(s.catatan||'').replace(/"/g, '""')}"\r\n`;
  });

  csvContent += "\r\n=== DATA STUNTING & KESMAS ===\r\n";
  csvContent += "Puskesmas,Kecamatan,Total Balita,Balita Ditimbang,Balita Stunting,Prevalensi %,Cakupan Imunisasi %\r\n";
  appData.stunting.forEach(st => {
    csvContent += `"${st.puskesmas_nama}","${st.kecamatan}",${st.total_balita},${st.balita_ditimbang},${st.balita_stunting},${st.persen_stunting},${st.cakupan_imunisasi}\r\n`;
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `Rekapitulasi_SIMKES_Dinkes_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast("File CSV / Excel berhasil diunduh!", "success");
}

// Notification Toast Helper
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const bgClass = type === 'success' ? 'bg-success' : (type === 'warning' ? 'bg-warning text-dark' : (type === 'danger' ? 'bg-danger' : 'bg-primary'));
  const textClass = type === 'warning' ? 'text-dark' : 'text-white';

  const toastEl = document.createElement('div');
  toastEl.className = `toast align-items-center ${bgClass} ${textClass} border-0 shadow-lg`;
  toastEl.setAttribute('role', 'alert');
  toastEl.setAttribute('aria-live', 'assertive');
  toastEl.setAttribute('aria-atomic', 'true');
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body fw-semibold">
        <i class="bi bi-info-circle-fill me-2"></i> ${message}
      </div>
      <button type="button" class="btn-close ${type === 'warning' ? '' : 'btn-close-white'} me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;

  container.appendChild(toastEl);
  const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
  bsToast.show();

  toastEl.addEventListener('hidden.bs.toast', () => {
    toastEl.remove();
  });
}

// -------------------------------------------------------------
// MODUL: PEDOMAN & SOP PENANGANAN & PENCEGAHAN PENYAKIT
// -------------------------------------------------------------
let selectedPedomanId = 'P001';

function renderPedoman(container) {
  if (typeof PEDOMAN_PENYAKIT === 'undefined') return;

  const activeP = PEDOMAN_PENYAKIT.find(p => p.id === selectedPedomanId) || PEDOMAN_PENYAKIT[0];

  container.innerHTML = `
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-1 text-slate-800"><i class="bi bi-shield-shaded text-teal me-2"></i> Pedoman Penanganan & Pencegahan Penyakit</h3>
        <p class="text-muted mb-0">Standar Operasional Prosedur (SOP) Tatalaksana Medis, Respon Cepat TGC, dan Edukasi Pencegahan Kemenkes RI</p>
      </div>
      <div class="d-flex gap-2 mt-2 mt-md-0">
        <button class="btn btn-primary btn-sm" onclick="printPedomanSOP('${activeP.id}')">
          <i class="bi bi-printer-fill me-1"></i> Cetak Lembar SOP Resmi
        </button>
      </div>
    </div>

    <!-- DISEASE SELECTOR PILLS -->
    <div class="d-flex flex-wrap gap-2 mb-4 pb-2 border-bottom">
      ${PEDOMAN_PENYAKIT.map(p => `
        <button onclick="switchPedoman('${p.id}')" class="btn btn-sm ${p.id === activeP.id ? 'btn-teal text-white fw-bold shadow-sm' : 'btn-outline-secondary'}" style="${p.id === activeP.id ? 'background:#0d9488;' : ''}">
          <i class="bi ${p.id === 'P001' ? 'bi-virus' : (p.id === 'P006' ? 'bi-heart-pulse' : 'bi-capsule')} me-1"></i> ${p.nama}
        </button>
      `).join('')}
    </div>

    <!-- DETAIL CARD HEADER -->
    <div class="card-dinkes mb-4 border-start border-4 border-${activeP.warna_kategori}">
      <div class="card-body">
        <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
          <div>
            <span class="badge bg-${activeP.warna_kategori}-subtle text-${activeP.warna_kategori} fw-bold mb-2">${activeP.kategori}</span>
            <h4 class="fw-bold text-slate-900 mb-1">${activeP.nama} (${activeP.kode})</h4>
            <p class="text-muted small mb-0"><i class="bi bi-info-circle me-1"></i> <strong>Patogen / Etiologi:</strong> ${activeP.vektor_patogen} &bull; <strong>Masa Inkubasi:</strong> ${activeP.masa_inkubasi}</p>
          </div>
          <span class="badge bg-light text-dark border font-monospace">Dokumen SOP: DINKES-SOP-${activeP.kode}-2026</span>
        </div>
      </div>
    </div>

    <!-- 4 PROTOCOL SECTIONS -->
    <div class="row g-4">
      <!-- 1. TATALAKSANA MEDIS -->
      <div class="col-12 col-lg-6">
        <div class="card-dinkes h-100">
          <div class="card-header bg-white border-bottom text-primary d-flex align-items-center gap-2">
            <i class="bi bi-heart-pulse-fill fs-5"></i>
            <span class="fw-bold">1. Tatalaksana Klinis & Medis Pasien</span>
          </div>
          <div class="card-body">
            <h6 class="fw-bold text-slate-800 small text-uppercase">Gejala Klinis & Trias Khas:</h6>
            <ul class="small mb-3 ps-3">
              ${activeP.gejala_klinis.map(g => `<li class="mb-1">${g}</li>`).join('')}
            </ul>

            <h6 class="fw-bold text-slate-800 small text-uppercase border-top pt-3">Prosedur Terapi & Perawatan Medis:</h6>
            <ol class="small mb-0 ps-3">
              ${activeP.tatalaksana_medis.map(m => `<li class="mb-1.5 ${m.includes('KONTRAINDIKASI') ? 'text-danger fw-bold' : ''}">${m}</li>`).join('')}
            </ol>
          </div>
        </div>
      </div>

      <!-- 2. SOP RESPON CEPAT DINKES (TGC) -->
      <div class="col-12 col-lg-6">
        <div class="card-dinkes h-100">
          <div class="card-header bg-white border-bottom text-danger d-flex align-items-center gap-2">
            <i class="bi bi-bell-fill fs-5"></i>
            <span class="fw-bold">2. SOP Respon Cepat Lapangan (Tim Gerak Cepat)</span>
          </div>
          <div class="card-body">
            <div class="alert alert-light border py-2 px-3 small mb-3">
              <i class="bi bi-exclamation-triangle-fill text-warning me-1"></i>
              <strong>Protokol Tanggap Darurat:</strong> Wajib dilaksanakan Puskesmas dan Bidang P2P Dinkes saat sinyal SKDR berbunyi.
            </div>
            <ul class="list-group list-group-flush small">
              ${activeP.sop_respon_dinkes.map((sop, idx) => `
                <li class="list-group-item px-0 py-2 d-flex align-items-start gap-2">
                  <span class="badge bg-danger rounded-pill">${idx+1}</span>
                  <div>${sop}</div>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>
      </div>

      <!-- 3. PENCEGAHAN MASYARAKAT -->
      <div class="col-12 col-lg-6">
        <div class="card-dinkes h-100">
          <div class="card-header bg-white border-bottom text-success d-flex align-items-center gap-2">
            <i class="bi bi-shield-check fs-5"></i>
            <span class="fw-bold">3. Tindakan Pencegahan & Edukasi Masyarakat</span>
          </div>
          <div class="card-body">
            <p class="small text-muted mb-2">Intervensi promotif dan preventif untuk memutus rantai penularan di tingkat keluarga dan komunitas:</p>
            <ul class="list-group list-group-flush small">
              ${activeP.pencegahan_masyarakat.map(pm => `
                <li class="list-group-item px-0 py-1.5 d-flex align-items-start gap-2">
                  <i class="bi bi-check-circle-fill text-success mt-0.5"></i>
                  <div>${pm}</div>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>
      </div>

      <!-- 4. LOGISTIK & OBAT GFK TERKAIT -->
      <div class="col-12 col-lg-6">
        <div class="card-dinkes h-100">
          <div class="card-header bg-white border-bottom text-warning d-flex align-items-center gap-2">
            <i class="bi bi-box-seam-fill fs-5"></i>
            <span class="fw-bold">4. Kebutuhan Buffer Stock Obat & Alkes GFK</span>
          </div>
          <div class="card-body">
            <div class="p-3 bg-light rounded-3 mb-3">
              <span class="text-muted small fw-semibold">DAFTAR OBAT & LOGISTIK ESENSIAL TERKAIT:</span>
              <div class="fw-bold text-slate-800 mt-1">${activeP.logistik_terkait}</div>
            </div>
            <p class="small text-muted mb-3">Pastikan ketersediaan buffer stock di Gudang Farmasi Kabupaten (GFK) mencukupi kebutuhan seluruh UPT Puskesmas minimal untuk durasi 3 bulan cadangan operasional.</p>
            <button class="btn btn-sm btn-outline-primary" onclick="switchView('farmasi')">
              <i class="bi bi-box-arrow-up-right me-1"></i> Buka Manajemen Gudang Farmasi
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
}

function switchPedoman(id) {
  selectedPedomanId = id;
  renderPedoman(document.getElementById('view-container'));
}

function printPedomanSOP(id) {
  const p = PEDOMAN_PENYAKIT.find(item => item.id === id);
  if (!p) return;

  const printContainer = document.getElementById('official-print-view');
  if (!printContainer) return;

  printContainer.innerHTML = `
    <div class="kop-surat">
      <div class="kop-text">
        <h4>PEMERINTAH DAERAH PROVINSI JAWA BARAT</h4>
        <h2>DINAS KESEHATAN KABUPATEN SEHAT SEJAHTERA</h2>
        <p>Jl. Kesehatan No. 45, Kompleks Pemda | Telp: (021) 8765-4321 | Email: dinkes@sehatsejahtera.go.id</p>
      </div>
    </div>

    <div style="text-align: center; margin: 20px 0;">
      <h3 style="margin: 0; text-decoration: underline;">STANDAR OPERASIONAL PROSEDUR (SOP)</h3>
      <h4 style="margin: 4px 0;">PENANGANAN DAN PENCEGAHAN: ${p.nama.toUpperCase()}</h4>
      <p style="margin: 0; font-size: 10pt;">Nomor Dokumen: DINKES-SOP-${p.kode}-2026 &bull; Bidang P2P dan Kesmas</p>
    </div>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 15px;">I. GEJALA & TATALAKSANA MEDIS</h4>
    <ul style="font-size: 10pt; line-height: 1.5;">
      ${p.tatalaksana_medis.map(m => `<li>${m}</li>`).join('')}
    </ul>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 15px;">II. SOP RESPON CEPAT LAPANGAN (TIM GERAK CEPAT DINKES)</h4>
    <ol style="font-size: 10pt; line-height: 1.5;">
      ${p.sop_respon_dinkes.map(s => `<li>${s}</li>`).join('')}
    </ol>

    <h4 style="border-bottom: 2px solid #000; padding-bottom: 4px; margin-top: 15px;">III. TINDAKAN PENCEGAHAN MASYARAKAT</h4>
    <ul style="font-size: 10pt; line-height: 1.5;">
      ${p.pencegahan_masyarakat.map(pm => `<li>${pm}</li>`).join('')}
    </ul>

    <div style="margin-top: 30px; display: flex; justify-content: flex-end;">
      <div style="text-align: center; width: 280px; font-size: 10pt;">
        <p style="margin-bottom: 60px;">
          Ditetapkan di: Kabupaten Sehat Sejahtera<br>
          <strong>KEPALA DINAS KESEHATAN</strong>
        </p>
        <p style="font-weight: bold; text-decoration: underline; margin-bottom: 2px;">dr. H. Rahmat Hidayat, M.Kes, Sp.KKLP</p>
        <p style="margin: 0; font-size: 9pt;">NIP. 19750812 200212 1 003</p>
      </div>
    </div>
  `;

  window.print();
}
