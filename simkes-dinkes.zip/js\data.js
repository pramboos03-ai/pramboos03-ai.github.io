/**
 * DATA DEFAULT SIMKES DINAS KESEHATAN DAERAH
 * Sistem Informasi Manajemen Kesehatan Terpadu
 */

const DEFAULT_DATA = {
  profil_dinkes: {
    nama_instansi: "Dinas Kesehatan Kabupaten Sehat Sejahtera",
    provinsi: "Jawa Barat",
    kepala_dinas: "dr. H. Rahmat Hidayat, M.Kes, Sp.KKLP",
    nip_kepala: "19750812 200212 1 003",
    alamat: "Jl. Kesehatan No. 45, Kompleks Perkantoran Pemda",
    telepon: "(021) 8765-4321 / 0812-3456-7890",
    email: "kontak@dinkes-sehat.go.id",
    website: "https://dinkes-sehat.go.id",
    tahun_anggaran: 2026
  },

  puskesmas: [
    {
      id: "PKM001",
      nama: "Puskesmas Sukamaju",
      kecamatan: "Kec. Sukamaju",
      tipe: "Rawat Inap",
      akreditasi: "Paripurna",
      kepala: "dr. Anita Wijaya",
      kontak: "0812-1111-2222",
      jml_dokter: 5,
      jml_perawat: 14,
      jml_bidan: 12,
      wilayah_desa: 6,
      populasi: 48500,
      status: "Aktif"
    },
    {
      id: "PKM002",
      nama: "Puskesmas Mentari Indah",
      kecamatan: "Kec. Mentari",
      tipe: "Non Rawat Inap",
      akreditasi: "Paripurna",
      kepala: "dr. Budi Santoso",
      kontak: "0812-2222-3333",
      jml_dokter: 4,
      jml_perawat: 10,
      jml_bidan: 9,
      wilayah_desa: 5,
      populasi: 36200,
      status: "Aktif"
    },
    {
      id: "PKM003",
      nama: "Puskesmas Cibadak Sehat",
      kecamatan: "Kec. Cibadak",
      tipe: "Rawat Inap",
      akreditasi: "Utama",
      kepala: "dr. Hendra Kusuma",
      kontak: "0813-3333-4444",
      jml_dokter: 6,
      jml_perawat: 16,
      jml_bidan: 14,
      wilayah_desa: 8,
      populasi: 54300,
      status: "Aktif"
    },
    {
      id: "PKM004",
      nama: "Puskesmas Harapan Jaya",
      kecamatan: "Kec. Harapan",
      tipe: "Non Rawat Inap",
      akreditasi: "Utama",
      kepala: "dr. Siti Rahmawati",
      kontak: "0813-4444-5555",
      jml_dokter: 3,
      jml_perawat: 9,
      jml_bidan: 8,
      wilayah_desa: 4,
      populasi: 29800,
      status: "Aktif"
    },
    {
      id: "PKM005",
      nama: "Puskesmas Danau Sari",
      kecamatan: "Kec. Danau",
      tipe: "Rawat Inap",
      akreditasi: "Madya",
      kepala: "dr. Dimas Pratama",
      kontak: "0815-5555-6666",
      jml_dokter: 4,
      jml_perawat: 12,
      jml_bidan: 11,
      wilayah_desa: 7,
      populasi: 41200,
      status: "Aktif"
    },
    {
      id: "PKM006",
      nama: "Puskesmas Gunung Kencana",
      kecamatan: "Kec. Gunung",
      tipe: "Non Rawat Inap",
      akreditasi: "Madya",
      kepala: "dr. Ratna Dewi",
      kontak: "0815-6666-7777",
      jml_dokter: 3,
      jml_perawat: 8,
      jml_bidan: 7,
      wilayah_desa: 5,
      populasi: 25400,
      status: "Aktif"
    },
    {
      id: "PKM007",
      nama: "Puskesmas Karang Sari",
      kecamatan: "Kec. Karang",
      tipe: "Rawat Inap",
      akreditasi: "Utama",
      kepala: "dr. Eko Prasetyo",
      kontak: "0816-7777-8888",
      jml_dokter: 5,
      jml_perawat: 15,
      jml_bidan: 13,
      wilayah_desa: 6,
      populasi: 47600,
      status: "Aktif"
    },
    {
      id: "PKM008",
      nama: "Puskesmas Pesisir Raya",
      kecamatan: "Kec. Pesisir",
      tipe: "Non Rawat Inap",
      akreditasi: "Paripurna",
      kepala: "dr. Maya Safitri",
      kontak: "0817-8888-9999",
      jml_dokter: 4,
      jml_perawat: 11,
      jml_bidan: 10,
      wilayah_desa: 5,
      populasi: 33900,
      status: "Aktif"
    }
  ],

  // Surveilans Penyakit & SKDR (Sistem Kewaspadaan Dini dan Respon)
  surveilans: [
    {
      id: "SRV-2026-001",
      tanggal: "2026-11-20",
      puskesmas_id: "PKM001",
      puskesmas_nama: "Puskesmas Sukamaju",
      penyakit: "Demam Berdarah Dengue (DBD)",
      kategori: "Penyakit Menular Potensi KLB",
      jumlah_kasus: 28,
      meninggal: 0,
      status_alert: "Waspada",
      catatan: "Peningkatan kasus di Desa Sukaresmi RT 03/04 pasca hujan deras. Fogging fokus dijadwalkan."
    },
    {
      id: "SRV-2026-002",
      tanggal: "2026-11-21",
      puskesmas_id: "PKM003",
      puskesmas_nama: "Puskesmas Cibadak Sehat",
      penyakit: "Demam Berdarah Dengue (DBD)",
      kategori: "Penyakit Menular Potensi KLB",
      jumlah_kasus: 34,
      meninggal: 1,
      status_alert: "Alert KLB",
      catatan: "Melebihi batas ambang epidemik minggu ke-46. Tim Gerak Cepat Dinkes diterjunkan."
    },
    {
      id: "SRV-2026-003",
      tanggal: "2026-11-22",
      puskesmas_id: "PKM002",
      puskesmas_nama: "Puskesmas Mentari Indah",
      penyakit: "Infeksi Saluran Pernapasan Akut (ISPA)",
      kategori: "Penyakit Menular",
      jumlah_kasus: 142,
      meninggal: 0,
      status_alert: "Normal",
      catatan: "Musim pancaroba, dominan kelompok usia anak dan lansia."
    },
    {
      id: "SRV-2026-004",
      tanggal: "2026-11-22",
      puskesmas_id: "PKM004",
      puskesmas_nama: "Puskesmas Harapan Jaya",
      penyakit: "Diare Akut",
      kategori: "Penyakit Menular Potensi KLB",
      jumlah_kasus: 45,
      meninggal: 0,
      status_alert: "Waspada",
      catatan: "Penyuluhan sanitasi air bersih di bantaran sungai digiatkan."
    },
    {
      id: "SRV-2026-005",
      tanggal: "2026-11-23",
      puskesmas_id: "PKM005",
      puskesmas_nama: "Puskesmas Danau Sari",
      penyakit: "Tuberkulosis (TBC)",
      kategori: "Penyakit Menular Kronis",
      jumlah_kasus: 18,
      meninggal: 0,
      status_alert: "Normal",
      catatan: "Skrining kontak serumah aktif dengan tes cepat molekuler (TCM)."
    },
    {
      id: "SRV-2026-006",
      tanggal: "2026-11-24",
      puskesmas_id: "PKM007",
      puskesmas_nama: "Puskesmas Karang Sari",
      penyakit: "Hipertensi Esensial",
      kategori: "Penyakit Tidak Menular (PTM)",
      jumlah_kasus: 188,
      meninggal: 0,
      status_alert: "Normal",
      catatan: "Posbindu PTM aktif di 6 desa."
    },
    {
      id: "SRV-2026-007",
      tanggal: "2026-11-25",
      puskesmas_id: "PKM008",
      puskesmas_nama: "Puskesmas Pesisir Raya",
      penyakit: "Suspek Campak / Morbili",
      kategori: "Penyakit Menular Potensi KLB",
      jumlah_kasus: 7,
      meninggal: 0,
      status_alert: "Waspada",
      catatan: "Sampel serum dikirim ke Labkesda untuk konfirmasi serologis IgM."
    }
  ],

  // Data Kesehatan Balita & Program Stunting (Bidang Kesmas)
  stunting: [
    {
      id: "STN001",
      puskesmas_id: "PKM001",
      puskesmas_nama: "Puskesmas Sukamaju",
      kecamatan: "Sukamaju",
      total_balita: 3420,
      balita_ditimbang: 3180,
      balita_stunting: 268,
      balita_wasting: 84,
      persen_stunting: 8.4,
      target_kab: 11.5,
      status_kinerja: "Sangat Baik (Di Bawah Target)",
      cakupan_imunisasi: 94.2
    },
    {
      id: "STN002",
      puskesmas_id: "PKM002",
      puskesmas_nama: "Puskesmas Mentari Indah",
      kecamatan: "Mentari",
      total_balita: 2840,
      balita_ditimbang: 2650,
      balita_stunting: 215,
      balita_wasting: 62,
      persen_stunting: 8.1,
      target_kab: 11.5,
      status_kinerja: "Sangat Baik (Di Bawah Target)",
      cakupan_imunisasi: 96.0
    },
    {
      id: "STN003",
      puskesmas_id: "PKM003",
      puskesmas_nama: "Puskesmas Cibadak Sehat",
      kecamatan: "Cibadak",
      total_balita: 4100,
      balita_ditimbang: 3750,
      balita_stunting: 495,
      balita_wasting: 128,
      persen_stunting: 13.2,
      target_kab: 11.5,
      status_kinerja: "Perlu Intervensi Khusus",
      cakupan_imunisasi: 88.5
    },
    {
      id: "STN004",
      puskesmas_id: "PKM004",
      puskesmas_nama: "Puskesmas Harapan Jaya",
      kecamatan: "Harapan",
      total_balita: 2150,
      balita_ditimbang: 1980,
      balita_stunting: 178,
      balita_wasting: 46,
      persen_stunting: 9.0,
      target_kab: 11.5,
      status_kinerja: "Baik",
      cakupan_imunisasi: 92.4
    },
    {
      id: "STN005",
      puskesmas_id: "PKM005",
      puskesmas_nama: "Puskesmas Danau Sari",
      kecamatan: "Danau",
      total_balita: 3200,
      balita_ditimbang: 2890,
      balita_stunting: 390,
      balita_wasting: 110,
      persen_stunting: 13.5,
      target_kab: 11.5,
      status_kinerja: "Perlu Intervensi Khusus",
      cakupan_imunisasi: 86.8
    },
    {
      id: "STN006",
      puskesmas_id: "PKM006",
      puskesmas_nama: "Puskesmas Gunung Kencana",
      kecamatan: "Gunung",
      total_balita: 1920,
      balita_ditimbang: 1740,
      balita_stunting: 242,
      balita_wasting: 55,
      persen_stunting: 13.9,
      target_kab: 11.5,
      status_kinerja: "Perlu Intervensi Khusus",
      cakupan_imunisasi: 85.1
    },
    {
      id: "STN007",
      puskesmas_id: "PKM007",
      puskesmas_nama: "Puskesmas Karang Sari",
      kecamatan: "Karang",
      total_balita: 3650,
      balita_ditimbang: 3410,
      balita_stunting: 358,
      balita_wasting: 89,
      persen_stunting: 10.5,
      target_kab: 11.5,
      status_kinerja: "Baik",
      cakupan_imunisasi: 93.7
    },
    {
      id: "STN008",
      puskesmas_id: "PKM008",
      puskesmas_nama: "Puskesmas Pesisir Raya",
      kecamatan: "Pesisir",
      total_balita: 2600,
      balita_ditimbang: 2390,
      balita_stunting: 265,
      balita_wasting: 71,
      persen_stunting: 11.1,
      target_kab: 11.5,
      status_kinerja: "Baik",
      cakupan_imunisasi: 91.2
    }
  ],

  // Gudang Farmasi Kabupaten (GFK) & Logistik Obat Esensial
  obat_gfk: [
    {
      id: "OBT001",
      kode: "FAR-001",
      nama_obat: "Paracetamol Tab 500 mg",
      kategori: "Analgesik & Antipiretik",
      stok_dinkes: 145000,
      satuan: "Tablet",
      batch: "BCH-2025-081",
      exp_date: "2027-08-30",
      buffer_minimal: 30000,
      status_stok: "Aman"
    },
    {
      id: "OBT002",
      kode: "FAR-002",
      nama_obat: "Amoxicillin Trihydrate 500 mg",
      kategori: "Antibiotik",
      stok_dinkes: 85000,
      satuan: "Kaplet",
      batch: "BCH-2025-119",
      exp_date: "2027-03-15",
      buffer_minimal: 25000,
      status_stok: "Aman"
    },
    {
      id: "OBT003",
      kode: "FAR-003",
      nama_obat: "Oralit Serbuk 200 ml",
      kategori: "Rehidrasi Cairan",
      stok_dinkes: 62000,
      satuan: "Sachet",
      batch: "BCH-2025-204",
      exp_date: "2028-01-10",
      buffer_minimal: 20000,
      status_stok: "Aman"
    },
    {
      id: "OBT004",
      kode: "FAR-004",
      nama_obat: "Vaksin DPT-HB-Hib (Pentabio)",
      kategori: "Vaksin Imunisasi Dasar",
      stok_dinkes: 2400,
      satuan: "Vial (5 dosis)",
      batch: "VAC-2026-012",
      exp_date: "2026-12-15",
      buffer_minimal: 2000,
      status_stok: "Menipis"
    },
    {
      id: "OBT005",
      kode: "FAR-005",
      nama_obat: "Tablet Tambah Darah (Fe + Folat)",
      kategori: "Suplemen Anemia Bumil",
      stok_dinkes: 190000,
      satuan: "Tablet",
      batch: "BCH-2025-331",
      exp_date: "2027-10-20",
      buffer_minimal: 40000,
      status_stok: "Aman"
    },
    {
      id: "OBT006",
      kode: "FAR-006",
      nama_obat: "Larutan Ringer Laktat (RL) 500 ml",
      kategori: "Cairan Infus Emergensi",
      stok_dinkes: 3200,
      satuan: "Kolf / Botol",
      batch: "BCH-2025-095",
      exp_date: "2027-06-30",
      buffer_minimal: 5000,
      status_stok: "Menipis"
    },
    {
      id: "OBT007",
      kode: "FAR-007",
      nama_obat: "Insektisida Malathion 96% (Fogging DBD)",
      kategori: "Vektor & P2P",
      stok_dinkes: 85,
      satuan: "Drum (20 Liter)",
      batch: "PST-2025-004",
      exp_date: "2028-05-18",
      buffer_minimal: 50,
      status_stok: "Aman"
    },
    {
      id: "OBT008",
      kode: "FAR-008",
      nama_obat: "Oseltamivir Cap 75 mg",
      kategori: "Antivirus Influenza / ISPA",
      stok_dinkes: 1800,
      satuan: "Kapsul",
      batch: "BCH-2024-811",
      exp_date: "2026-12-30",
      buffer_minimal: 3000,
      status_stok: "Kritis"
    }
  ],

  // Riwayat Distribusi Obat ke Puskesmas
  distribusi: [
    {
      id: "DST-2026-081",
      no_sbbk: "SBBK/GFK/XI/2026/081",
      tanggal: "2026-11-18",
      puskesmas_id: "PKM003",
      puskesmas_nama: "Puskesmas Cibadak Sehat",
      item_obat: "Paracetamol 500mg (15.000 tab), RL Infus (300 kolf), Abate (25 kg)",
      tujuan: "Antisipasi Peningkatan Kasus DBD",
      petugas_gfk: "Apt. Wahyu Pratama, S.Farm",
      status: "Terkirim & Diterima"
    },
    {
      id: "DST-2026-082",
      no_sbbk: "SBBK/GFK/XI/2026/082",
      tanggal: "2026-11-20",
      puskesmas_id: "PKM001",
      puskesmas_nama: "Puskesmas Sukamaju",
      item_obat: "Tablet Tambah Darah (20.000 tab), Vaksin Pentabio (150 vial)",
      tujuan: "Alokasi Rutin Program Posyandu & Bumil",
      petugas_gfk: "Apt. Wahyu Pratama, S.Farm",
      status: "Terkirim & Diterima"
    },
    {
      id: "DST-2026-083",
      no_sbbk: "SBBK/GFK/XI/2026/083",
      tanggal: "2026-11-24",
      puskesmas_id: "PKM002",
      puskesmas_nama: "Puskesmas Mentari Indah",
      item_obat: "Amoxicillin 500mg (10.000 kaplet), Oralit (5.000 sachet)",
      tujuan: "Buffer Stock Triwulan IV",
      petugas_gfk: "Apt. Wahyu Pratama, S.Farm",
      status: "Dalam Perjalanan"
    }
  ],

  // 10 Besar Penyakit Terbanyak Daerah
  top_penyakit: [
    { rank: 1, nama: "Infeksi Saluran Pernapasan Akut (ISPA)", kasus: 3840, tren: "+4.2%" },
    { rank: 2, nama: "Hipertensi Primer / Esensial", kasus: 2950, tren: "+1.8%" },
    { rank: 3, nama: "Dispepsia / Gangguan Lambung", kasus: 2180, tren: "-0.5%" },
    { rank: 4, nama: "Diabetes Melitus Tipe 2", kasus: 1720, tren: "+2.1%" },
    { rank: 5, nama: "Diare & Gastroenteritis", kasus: 1460, tren: "+6.8%" },
    { rank: 6, nama: "Demam Berdarah Dengue (DBD)", kasus: 890, tren: "+18.4%" },
    { rank: 7, nama: "Penyakit Sendi & Rematik", kasus: 810, tren: "-1.2%" },
    { rank: 8, nama: "Tuberkulosis Paru (TBC)", kasus: 450, tren: "+0.9%" },
    { rank: 9, nama: "Dermatitis / Alergi Kulit", kasus: 390, tren: "-2.0%" },
    { rank: 10, nama: "Penyakit Gigi & Jaringan Periodontal", kasus: 320, tren: "+1.1%" }
  ]
};
