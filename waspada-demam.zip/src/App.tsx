/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useAuth } from './contexts/AuthContext';
import AuthPage from './components/AuthPage';
import AdminDashboard from './components/AdminDashboard';
import PasienDashboard from './components/PasienDashboard';
import NakesDashboard from './components/NakesDashboard';

export default function App() {
  const { role, setRole } = useAuth();

  if (!role) {
    return <AuthPage />;
  }

  if (role === 'admin') {
    return <AdminDashboard />;
  }

  if (role === 'pasien') {
    return <PasienDashboard />;
  }

  if (role === 'nakes') {
    return <NakesDashboard />;
  }

  const logout = () => setRole(null);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-8">
      <header className="flex justify-between items-center mb-12">
        <h1 className="text-2xl font-bold">Waspada Demam - {role.toUpperCase()}</h1>
        <button 
          onClick={logout}
          className="px-6 py-2 bg-gray-200 rounded-full text-sm font-medium hover:bg-gray-300 transition-colors"
        >
          Keluar
        </button>
      </header>
      
      <main>
      </main>
    </div>
  );
}

