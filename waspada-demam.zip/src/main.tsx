import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { AuthProvider } from './contexts/AuthContext.tsx';
import { ThemeProvider } from './contexts/ThemeContext.tsx';
import { registerSW } from 'virtual:pwa-register';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';

registerSW({ onNeedRefresh() {} });

createRoot(document.getElementById('root')!).render(
  <AuthProvider>
    <ThemeProvider>
      <App />
      <OfflineIndicator />
    </ThemeProvider>
  </AuthProvider>
);
