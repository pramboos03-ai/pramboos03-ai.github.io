export type GejalaInput = Record<string, number>;

export interface ResultAnalisis {
  penyakit: string[];
  kewaspadaan: 'Rendah' | 'Sedang' | 'Tinggi';
  saran: string[];
  jalurTree: string;
}

export function prosesDecisionTree(input: GejalaInput): ResultAnalisis {
  // 1. Check Tanda Bahaya (Priority Rule)
  const adaTandaBahaya = input['kejang'] === 1 || 
                         input['sesak_napas'] === 1 || 
                         input['perdarahan'] === 1 || 
                         input['penurunan_kesadaran'] === 1;

  if (adaTandaBahaya) {
    return {
      penyakit: ["Demam dengan Komplikasi / Kondisi Darurat"],
      kewaspadaan: "Tinggi",
      saran: [
        "Segera menuju IGD atau fasilitas kesehatan terdekat",
        "Dampingi pasien dan jaga jalan napas tetap lega",
        "Bawa catatan gejala dan hasil analisis ini"
      ],
      jalurTree: "Demam -> Tanda Bahaya Terdeteksi -> Kewaspadaan Tinggi"
    };
  }

  // 2. Check Penyakit Spesifik (Subset 10 Penyakit)
  if (input['nyeri_di_belakang_mata'] === 1 || input['ruam_kulit'] === 1) {
    return {
      penyakit: ["Demam Berdarah Dengue (DBD)"],
      kewaspadaan: "Sedang",
      saran: [
        "Konsultasikan segera ke fasilitas kesehatan",
        "Perbanyak konsumsi cairan/air putih",
        "Lakukan pemeriksaan darah rutin di laboratorium"
      ],
      jalurTree: "Demam -> Ruam Kulit / Nyeri Mata -> Kewaspadaan Sedang"
    };
  }

  if (input['darah_dalam_dahak'] === 1 || input['pembengkakan_kelenjar'] === 1) {
    return {
      penyakit: ["Tuberkulosis (TBC)"],
      kewaspadaan: "Sedang",
      saran: ["Pemeriksaan dahak dan rontgen dada di faskes", "Gunakan masker"],
      jalurTree: "Demam -> Batuk Dahak -> Kewaspadaan Sedang"
    };
  }

  // 3. Fallback: Flu Biasa / ISPA
  return {
    penyakit: ["Infeksi Virus Ringan (ISPA / Flu Biasa)"],
    kewaspadaan: "Rendah",
    saran: [
      "Istirahat cukup dan perbanyak minum air hangat",
      "Kompres hangat pada lipatan tubuh",
      "Pantau suhu tubuh selama 24-48 jam"
    ],
    jalurTree: "Demam -> Batuk/Pilek -> Tanpa Tanda Bahaya -> Kewaspadaan Rendah"
  };
}
