import { createContext, useContext, useState } from 'react';

type UserRole = 'pasien' | 'nakes' | 'admin';

interface AuthContextType {
  role: UserRole | null;
  setRole: (role: UserRole) => void;
  // Firebase auth state would be managed here
}

const AuthContext = createContext<AuthContextType>({
  role: null,
  setRole: () => {},
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [role, setRole] = useState<UserRole | null>(null);

  return (
    <AuthContext.Provider value={{ role, setRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
