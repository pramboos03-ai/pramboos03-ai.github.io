import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const penyakitInfo = [
  { nama: "Demam Berdarah Dengue (DBD)", icd: "A91", gejala: "Demam tinggi mendadak, nyeri otot, bintik merah", penyebab: "Virus Dengue melalui gigitan nyamuk Aedes aegypti", diagnosis: "Tes antigen NS1 atau pemeriksaan serologi IgM/IgG", preventif: "3M Plus, lotion anti nyamuk" },
  { nama: "Malaria", icd: "B50-B54", gejala: "Demam menggigil, berkeringat, sakit kepala", penyebab: "Parasit Plasmodium melalui nyamuk Anopheles", diagnosis: "Pemeriksaan mikroskopis apus darah tebal/tipis", preventif: "Gunakan kelambu, profilaksis malaria" },
  { nama: "Tipus (Demam Tifoid)", icd: "A01.0", gejala: "Demam tinggi bertahap, nyeri perut, diare/konstipasi", penyebab: "Bakteri Salmonella typhi (fecal-oral route)", diagnosis: "Tes Widal atau kultur darah/urin", preventif: "Sanitasi makanan, vaksinasi tifoid" },
  { nama: "Flu Biasa", icd: "J11", gejala: "Demam ringan, batuk, pilek, lemas", penyebab: "Virus Influenza", diagnosis: "Klinis (berdasarkan gejala fisik)", preventif: "Vaksin flu, cuci tangan, etika batuk" },
  { nama: "Cacar Air", icd: "B01", gejala: "Demam, ruam lenting gatal, lemas", penyebab: "Virus Varicella-zoster", diagnosis: "Klinis (pemeriksaan lesi kulit)", preventif: "Vaksinasi varisela" },
  { nama: "Tuberkulosis (TBC)", icd: "A15", gejala: "Batuk kronis >2 minggu, demam, keringat malam", penyebab: "Bakteri Mycobacterium tuberculosis", diagnosis: "Tes Cepat Molekuler (TCM) dahak, rontgen dada", preventif: "Vaksin BCG, ventilasi, etika batuk" },
  { nama: "Radang Paru-paru (Pneumonia)", icd: "J18", gejala: "Demam, sesak napas, batuk berdahak", penyebab: "Infeksi bakteri, virus, atau jamur di paru", diagnosis: "Rontgen dada, pemeriksaan dahak, saturasi oksigen", preventif: "Vaksin pneumokokus, jangan merokok" },
  { nama: "Hepatitis A", icd: "B15", gejala: "Demam, mual, urin gelap, kulit kuning", penyebab: "Virus Hepatitis A (makanan/air terkontaminasi)", diagnosis: "Tes fungsi hati (SGOT/SGPT), pemeriksaan IgM anti-HAV", preventif: "Vaksin Hepatitis A, kebersihan makanan" },
  { nama: "Hepatitis E", icd: "B17.2", gejala: "Demam, lemas, kulit kuning", penyebab: "Virus Hepatitis E (air terkontaminasi)", diagnosis: "Pemeriksaan IgM anti-HEV", preventif: "Masak air hingga mendidih, sanitasi lingkungan" },
  { nama: "Penyakit Kuning", icd: "R17", gejala: "Kulit dan mata kuning, urin gelap", penyebab: "Gangguan hati/saluran empedu", diagnosis: "Tes bilirubin, USG perut, tes fungsi hati", preventif: "Hindari alkohol, diet sehat, kontrol rutin" }
];

export default function EdukasiPage({ onBack }: { onBack: () => void }) {
  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <div className="max-w-md mx-auto min-h-screen bg-gray-50 p-6 pb-20">
      <button onClick={onBack} className="mb-6 font-bold text-teal-700">← Kembali</button>
      <h2 className="text-2xl font-bold mb-6">Informasi Penyakit</h2>
      <div className="space-y-4">
        {penyakitInfo.map((p, i) => (
          <motion.div key={i} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <button onClick={() => setExpanded(expanded === i ? null : i)} className="w-full p-5 flex justify-between items-center font-bold text-teal-800">
              {p.nama}
              <ChevronDown className={`transition-transform ${expanded === i ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
              {expanded === i && (
                <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-5 pb-5 text-sm space-y-2 text-gray-600">
                  <p><strong>ICD-10:</strong> {p.icd}</p>
                  <p><strong>Gejala:</strong> {p.gejala}</p>
                  <p><strong>Penyebab:</strong> {p.penyebab}</p>
                  <p><strong>Diagnosis:</strong> {p.diagnosis}</p>
                  <p><strong>Preventif:</strong> {p.preventif}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
