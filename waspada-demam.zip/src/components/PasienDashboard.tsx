import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Activity, History, BookOpen, Stethoscope, AlertTriangle, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { prosesDecisionTree } from '../utils/decisionTree';
import EdukasiPage from './EdukasiPage';
import ProfileSettings from './ProfileSettings';
import { requestNotificationPermission, showNotification } from '../utils/notifications';

const GEJALA_UMUM = ['demam', 'sakit_kepala', 'batuk', 'pilek', 'mual', 'nyeri_otot', 'ruam_kulit'];
const TANDA_BAHAYA = ['kejang', 'sesak_napas', 'perdarahan', 'penurunan_kesadaran'];

export default function PasienDashboard() {
  const { setRole } = useAuth();
  const [view, setView] = useState<'home' | 'gejala' | 'hasil' | 'edukasi' | 'profile'>('home');
  const [selectedGejala, setSelectedGejala] = useState<Record<string, number>>({});
  const [hasil, setHasil] = useState<any>(null);

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  const toggleGejala = (gejala: string) => {
    setSelectedGejala(prev => ({ ...prev, [gejala]: prev[gejala] === 1 ? 0 : 1 }));
  };

  const jumlahTerpilih = Object.values(selectedGejala).filter(v => v === 1).length;

  const handleAnalisis = () => {
    if (jumlahTerpilih === 0) {
      alert("Pilih minimal 1 gejala sebelum menekan tombol analisis.");
      return;
    }
    const hasilAnalisis = prosesDecisionTree(selectedGejala);
    setHasil(hasilAnalisis);
    setView('hasil');
    setTimeout(() => {
        showNotification("Waspada Demam", "Tenaga kesehatan telah menanggapi konsultasi Anda.");
    }, 5000);
  };

  if (view === 'edukasi') return <EdukasiPage onBack={() => setView('home')} />;
  if (view === 'profile') return <ProfileSettings onBack={() => setView('home')} />;

  const AnalysisModal = () => (
    <AnimatePresence>
      {hasil && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 p-6 flex items-center justify-center">
          <motion.div className="bg-white p-6 rounded-3xl w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Hasil Analisis</h2>
            <div className={`p-4 rounded-xl text-white mb-4 ${hasil.kewaspadaan === 'Tinggi' ? 'bg-red-600' : hasil.kewaspadaan === 'Sedang' ? 'bg-amber-500' : 'bg-green-600'}`}>
              <p className="font-bold">KEWASPADAAN {hasil.kewaspadaan.toUpperCase()}</p>
              <p className="text-sm">{hasil.penyakit}</p>
            </div>
            <button onClick={() => { setHasil(null); setView('home'); }} className="w-full py-3 bg-teal-600 text-white rounded-xl font-bold">Tutup</button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  return (
    <div className="max-w-md mx-auto min-h-screen bg-gray-50 pb-20">
      {view === 'home' && (
        <div className="p-6">
          <header className="flex justify-between items-center mb-8">
            <h1 className="text-xl font-bold">Halo, Pasien!</h1>
            <div className='flex gap-2'>
              <button onClick={() => setView('profile')} className="p-2 bg-gray-200 rounded-full"><User size={18} /></button>
              <button onClick={() => setRole(null)} className="p-2 bg-gray-200 rounded-full"><LogOut size={18} /></button>
            </div>
          </header>
          {/* ... (rest of the dashboard) */}
          <div className="bg-teal-600 text-white p-6 rounded-3xl mb-8">
            <h2 className="text-lg font-bold mb-2">Merasa demam?</h2>
            <p className="text-sm opacity-90 mb-4">Pilih gejala yang Anda alami untuk mendapatkan informasi awal.</p>
            <button onClick={() => setView('gejala')} className="w-full py-3 bg-white text-teal-700 rounded-xl font-semibold">Mulai Cek Gejala</button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[ {label: 'Cek Gejala', icon: Stethoscope, view: 'gejala'}, {label: 'Riwayat', icon: History, view: 'home'}, {label: 'Edukasi', icon: BookOpen, view: 'edukasi'}, {label: 'Hubungi Nakes', icon: Activity, view: 'home'}].map(item => (
              <button key={item.label} onClick={() => setView(item.view as any)} className="bg-white p-4 rounded-2xl shadow-sm text-center hover:border-teal-500 border border-transparent transition-all">
                <item.icon className="mx-auto mb-2 text-teal-600" />
                <p className="text-xs font-semibold">{item.label}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {view === 'gejala' && (
        <div className="p-6">
          <h2 className="text-xl font-bold mb-6">Pilih Gejala</h2>
          <div className="grid grid-cols-2 gap-3">
            {[...GEJALA_UMUM, ...TANDA_BAHAYA].map(g => (
              <button 
                key={g} onClick={() => toggleGejala(g)}
                className={`p-3 rounded-full text-sm ${selectedGejala[g] === 1 ? 'bg-teal-600 text-white' : 'bg-white border'}`}
              >
                {g.replace('_', ' ').toUpperCase()}
              </button>
            ))}
          </div>
          <button onClick={handleAnalisis} className="fixed bottom-6 left-6 right-6 py-4 bg-teal-600 text-white rounded-2xl font-bold">Analisis</button>
        </div>
      )}
      <AnalysisModal />
    </div>
  );
}
