import { useState } from 'react';
import { LogOut, Activity, AlertTriangle, Users, Search, ChevronRight, Send, Clock, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

type Severity = 'Tinggi' | 'Sedang' | 'Rendah';

interface Konsultasi {
  id: string;
  pasien: string;
  timestamp: string;
  gejala: string[];
  kewaspadaan: Severity;
  status: 'Menunggu' | 'Selesai';
}

export default function NakesDashboard() {
  const { setRole } = useAuth();
  const [selectedKonsultasi, setSelectedKonsultasi] = useState<Konsultasi | null>(null);

  const konsultasiList: Konsultasi[] = [
    { id: '1', pasien: 'Pengguna A', timestamp: 'Hari ini, 09.41', gejala: ['Demam', 'Kejang', 'Sesak napas'], kewaspadaan: 'Tinggi', status: 'Menunggu' },
    { id: '2', pasien: 'Pengguna B', timestamp: 'Hari ini, 10.15', gejala: ['Demam', 'Mual'], kewaspadaan: 'Sedang', status: 'Menunggu' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white p-6 border-b flex justify-between items-center sticky top-0 z-10">
        <h1 className="text-xl font-bold text-teal-800">Waspada Demam<span className="block text-sm text-gray-500 font-normal">Portal Nakes</span></h1>
        <div className="flex items-center gap-4">
          <span className="text-sm">Dr. Nakes | RSUD Bukittinggi</span>
          <button onClick={() => setRole(null)} className="p-2 bg-gray-100 rounded-full text-red-600"><LogOut size={18} /></button>
        </div>
      </header>

      <main className="p-6 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[ {l: 'Konsultasi Masuk', v: 18, c: 'text-blue-600'}, {l: 'High Risk', v: 3, c: 'text-red-600'}, {l: 'Menunggu', v: 5, c: 'text-amber-600'}, {l: 'Selesai', v: 10, c: 'text-green-600'}].map(s => (
            <div key={s.l} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <p className="text-sm text-gray-500">{s.l}</p>
              <p className={`text-2xl font-bold ${s.c}`}>{s.v}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-4">
            <div className="relative mb-4">
              <Search className="absolute left-3 top-3 text-gray-400" size={18} />
              <input type="text" placeholder="Cari pasien..." className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl" />
            </div>
            {konsultasiList.map(k => (
              <button key={k.id} onClick={() => setSelectedKonsultasi(k)} className="w-full bg-white p-4 rounded-xl shadow-sm border border-gray-100 text-left hover:border-teal-500 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold">{k.pasien}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${k.kewaspadaan === 'Tinggi' ? 'bg-red-100 text-red-700' : k.kewaspadaan === 'Sedang' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}>{k.kewaspadaan}</span>
                </div>
                <p className="text-sm text-gray-600 mb-2">{k.gejala.join(', ')}</p>
                <div className="flex justify-between items-center text-xs text-gray-400">
                  <span className="flex items-center gap-1"><Clock size={12}/> {k.timestamp}</span>
                  <span className={k.status === 'Menunggu' ? 'text-amber-600' : 'text-green-600'}>{k.status}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="md:col-span-2 bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
            {selectedKonsultasi ? (
              <div>
                <h3 className="text-lg font-bold mb-4">Detail Konsultasi: {selectedKonsultasi.pasien}</h3>
                <div className="bg-gray-50 p-4 rounded-xl mb-4 text-sm">
                  <p className="font-bold mb-1">Gejala:</p>
                  <p className="mb-3">{selectedKonsultasi.gejala.join(', ')}</p>
                  <p className="font-bold mb-1">Path Analisis:</p>
                  <p className="text-gray-600 italic">Demam - {selectedKonsultasi.gejala[1]} - Kewaspadaan {selectedKonsultasi.kewaspadaan}</p>
                </div>
                <textarea placeholder="Tulis tanggapan medis..." className="w-full p-4 border rounded-xl mb-4 h-32"></textarea>
                <div className="flex gap-2">
                  <button className="flex-1 py-3 bg-teal-600 text-white rounded-xl font-bold flex items-center justify-center gap-2"><Send size={18}/> Kirim</button>
                  <button className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold">Rujuk ke IGD</button>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400">Pilih pasien dari daftar untuk melihat detail</div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
