import { useState } from 'react';
import { LayoutDashboard, FileText, Stethoscope, History, LogOut, Search, Plus, Trash2, Edit2, AlertTriangle, Activity, Users, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

type Tab = 'overview' | 'gejala' | 'artikel' | 'riwayat' | 'pasien';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [gejalaSearch, setGejalaSearch] = useState('');

  const stats = [
    { label: 'Total Konsultasi', value: '128', icon: Activity, color: 'text-blue-600' },
    { label: 'Kewaspadaan Tinggi', value: '14', icon: AlertTriangle, color: 'text-red-600' },
    { label: 'Kewaspadaan Sedang', value: '42', icon: AlertTriangle, color: 'text-amber-600' },
    { label: 'Pengguna Aktif', value: '56', icon: Users, color: 'text-teal-600' },
  ];

  const gejalaData = [
    { nama: 'Demam', kategori: 'Umum' },
    { nama: 'Batuk', kategori: 'Umum' },
    { nama: 'Kejang', kategori: 'Tanda Bahaya' }
  ];
  const filteredGejala = gejalaData.filter(g => g.nama.toLowerCase().includes(gejalaSearch.toLowerCase()));

  const exportToCSV = () => {
    const headers = ["ID", "Tanggal", "Pengguna", "Prediksi"];
    const data = [["1", "2026-11-09", "Pasien A", "DBD"]];
    const csvContent = [headers, ...data].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Laporan_Konsultasi.csv';
    a.click();
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Laporan Konsultasi", 14, 16);
    (doc as any).autoTable({ 
      head: [["ID", "Tanggal", "Pengguna", "Prediksi"]],
      body: [["1", "2026-11-09", "Pasien A", "DBD"]],
      startY: 20 
    });
    doc.save('Laporan_Konsultasi.pdf');
  };

  const SidebarItem = ({ id, label, icon: Icon }: { id: Tab, label: string, icon: any }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-3 p-4 rounded-xl transition-all ${activeTab === id ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100'}`}
    >
      <Icon size={20} />
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="w-64 bg-white border-r border-gray-200 p-6 flex flex-col">
        <h1 className="text-xl font-bold text-teal-800 mb-10">Waspada Demam<br/><span className="text-sm text-gray-500 font-normal">Portal Admin</span></h1>
        <nav className="flex-grow space-y-2">
          <SidebarItem id="overview" label="Overview" icon={LayoutDashboard} />
          <SidebarItem id="gejala" label="Kelola Gejala & Penyakit" icon={Stethoscope} />
          <SidebarItem id="artikel" label="Kelola Artikel" icon={FileText} />
          <SidebarItem id="riwayat" label="Riwayat Konsultasi" icon={History} />
          <SidebarItem id="pasien" label="Kelola Pasien" icon={Users} />
        </nav>
        <button onClick={() => setIsLogoutModalOpen(true)} className="flex items-center gap-3 text-red-600 p-4 hover:bg-red-50 rounded-xl transition-colors">
          <LogOut size={20} /> Keluar
        </button>
      </aside>

      <main className="flex-1 p-8">
        <header className="flex justify-between items-center mb-8 bg-white p-6 rounded-2xl shadow-sm">
          <h2 className="text-2xl font-bold text-gray-900 capitalize">{activeTab}</h2>
          <div className="text-right">
            <p className="font-semibold text-gray-900">Admin Utama</p>
            <p className="text-sm text-gray-500">admin@waspadademam.com</p>
          </div>
        </header>

        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {stats.map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className={`p-3 rounded-full bg-gray-100 ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h3 className="text-lg font-bold mb-6">Tren Gejala Terlapor</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[{ name: 'Demam', count: 80 }, { name: 'Batuk', count: 65 }, { name: 'Pilek', count: 45 }, { name: 'Mual', count: 30 }, { name: 'Nyeri', count: 20 }]}>
                    <XAxis dataKey="name" /> <YAxis /> <Tooltip />
                    <Bar dataKey="count" fill="#00897B" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'gejala' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex justify-between mb-6">
              <div className="relative w-64">
                <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                <input type="text" onChange={(e) => setGejalaSearch(e.target.value)} placeholder="Cari gejala..." className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl" />
              </div>
              <button className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded-xl font-semibold"><Plus size={18} /> Tambah Data</button>
            </div>
            <table className="w-full text-left">
              <thead><tr className="text-gray-500 border-b"><th className="pb-3">Nama</th><th className="pb-3">Kategori</th><th className="pb-3">Aksi</th></tr></thead>
              <tbody>
                {filteredGejala.map((g, i) => (
                  <tr key={i} className="border-b"><td className="py-4">{g.nama}</td><td className="py-4">{g.kategori}</td><td className="py-4 flex gap-2"><button className="text-blue-600"><Edit2 size={18}/></button><button className="text-red-600"><Trash2 size={18}/></button></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {activeTab === 'riwayat' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex justify-end gap-2 mb-6">
              <button onClick={exportToCSV} className="flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-xl"><Download size={18} /> CSV</button>
              <button onClick={exportToPDF} className="flex items-center gap-2 bg-red-100 text-red-700 px-4 py-2 rounded-xl"><Download size={18} /> PDF</button>
            </div>
            <p>Riwayat Konsultasi...</p>
          </div>
        )}

        {activeTab === 'pasien' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold mb-4">Kelola Pasien</h3>
            <table className="w-full text-left">
              <thead><tr className="text-gray-500 border-b"><th className="pb-3">Nama</th><th className="pb-3">Riwayat Penyakit</th><th className="pb-3">Aksi</th></tr></thead>
              <tbody>
                <tr className="border-b"><td className="py-4">Pasien A</td><td className="py-4">DBD (2026-10-01)</td><td className="py-4 flex gap-2"><button className="text-blue-600"><Edit2 size={18}/></button></td></tr>
              </tbody>
            </table>
          </div>
        )}
      </main>

      <AnimatePresence>
        {isLogoutModalOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} className="bg-white p-8 rounded-3xl max-w-sm w-full">
              <h3 className="text-lg font-bold mb-4">Konfirmasi Keluar</h3>
              <p className="text-gray-600 mb-6">Apakah Anda yakin ingin keluar dari sesi Admin?</p>
              <div className="flex gap-4">
                <button onClick={() => setIsLogoutModalOpen(false)} className="flex-1 py-3 rounded-xl bg-gray-100 font-semibold">Batal</button>
                <button onClick={() => window.location.reload()} className="flex-1 py-3 rounded-xl bg-red-600 text-white font-semibold">Keluar</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
