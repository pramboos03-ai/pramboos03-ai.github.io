import { useState } from 'react';
import { motion } from 'framer-motion';

export default function ProfileSettings({ onBack }: { onBack: () => void }) {
  const [profile, setProfile] = useState({
    nama: 'Pasien A',
    email: 'pasien@contoh.com',
    riwayat: 'Alergi obat amoxicillin',
    kontak: '08123456789'
  });

  return (
    <div className="max-w-md mx-auto min-h-screen bg-gray-50 p-6 pb-20">
      <button onClick={onBack} className="mb-6 font-bold text-teal-700">← Kembali</button>
      <h2 className="text-2xl font-bold mb-6">Pengaturan Profil</h2>
      
      <div className="space-y-4 bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
        <div>
          <label className="block text-sm font-semibold mb-1">Nama Lengkap</label>
          <input value={profile.nama} onChange={e => setProfile({...profile, nama: e.target.value})} className="w-full p-3 border rounded-xl" />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Riwayat Medis</label>
          <textarea value={profile.riwayat} onChange={e => setProfile({...profile, riwayat: e.target.value})} className="w-full p-3 border rounded-xl" rows={3} />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Kontak Darurat</label>
          <input value={profile.kontak} onChange={e => setProfile({...profile, kontak: e.target.value})} className="w-full p-3 border rounded-xl" />
        </div>
        <button className="w-full py-4 bg-teal-600 text-white rounded-2xl font-bold mt-4">Simpan Perubahan</button>
      </div>
    </div>
  );
}
