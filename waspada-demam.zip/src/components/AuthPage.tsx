import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';

export default function AuthPage() {
  const { setRole } = useAuth();
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md p-8 bg-white rounded-3xl shadow-xl border border-gray-100"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Waspada Demam</h1>
        <p className="text-gray-600 mb-8">{isLogin ? "Masuk ke akun Anda" : "Daftar akun baru"}</p>
        
        <form className="space-y-4">
          {!isLogin && <input type="text" placeholder="Nama Lengkap" className="w-full p-4 bg-gray-50 rounded-2xl" />}
          <input type="email" placeholder="Email" className="w-full p-4 bg-gray-50 rounded-2xl" />
          <input type="password" placeholder="Kata Sandi" className="w-full p-4 bg-gray-50 rounded-2xl" />
          
          <button 
            type="button"
            onClick={() => setRole('pasien')}
            className="w-full py-4 bg-gray-900 text-white rounded-2xl font-semibold hover:bg-black transition-colors"
          >
            {isLogin ? "Masuk" : "Daftar"}
          </button>
        </form>

        <div className="mt-6 flex flex-col gap-2">
          <button onClick={() => setRole('nakes')} className="text-sm text-gray-500 hover:text-gray-900">Masuk sebagai Nakes</button>
          <button onClick={() => setRole('admin')} className="text-sm text-gray-500 hover:text-gray-900">Masuk sebagai Admin</button>
          <button onClick={() => setIsLogin(!isLogin)} className="text-sm text-blue-600 mt-4">
            {isLogin ? "Belum punya akun? Daftar" : "Sudah punya akun? Masuk"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
