<?php
declare(strict_types=1);

/* ============ Config & util dasar ============ */
$__cf = __DIR__ . '/../config.php';
if (!is_file($__cf)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('config.php belum ada. Salin config.sample.php menjadi config.php lalu isi.');
}
$GLOBALS['CFG'] = require $__cf;
date_default_timezone_set((string)cfg('timezone', 'Asia/Jakarta'));

function cfg(string $k, $d = null)
{
    return $GLOBALS['CFG'][$k] ?? $d;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . cfg('db_host', '127.0.0.1') . ';dbname=' . cfg('db_name') . ';charset=utf8mb4',
            (string)cfg('db_user'),
            (string)cfg('db_pass', ''),
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        $pdo->exec("SET time_zone = '" . date('P') . "'");
    }
    return $pdo;
}

function q(string $sql, array $p = []): PDOStatement
{
    $s = db()->prepare($sql);
    $s->execute($p);
    return $s;
}
function row(string $sql, array $p = []): ?array
{
    $r = q($sql, $p)->fetch();
    return $r ?: null;
}
function rows(string $sql, array $p = []): array
{
    return q($sql, $p)->fetchAll();
}
function val(string $sql, array $p = [])
{
    $r = q($sql, $p)->fetchColumn();
    return $r === false ? null : $r;
}
function now(): string
{
    return date('Y-m-d H:i:s');
}
function ms(?string $dt): int
{
    return $dt ? (int)strtotime($dt) * 1000 : 0;
}
function ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0';
}

/* ============ Respons JSON & error ============ */
class ApiError extends Exception
{
    public ?string $field;
    public function __construct(string $m, int $code = 400, ?string $field = null)
    {
        parent::__construct($m, $code);
        $this->field = $field;
    }
}
function fail(string $m, int $code = 400, ?string $field = null): void
{
    throw new ApiError($m, $code, $field);
}
function reply_raw(string $body, int $code = 200, string $type = 'application/json; charset=utf-8'): void
{
    http_response_code($code);
    header('Content-Type: ' . $type);
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    if (!ini_get('zlib.output_compression')) {
        header('Content-Length: ' . strlen($body));
        header('Connection: close');
    }
    echo $body;
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
        @flush();
    }
}
function out($d, int $code = 200): void
{
    reply_raw((string)json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $code);
    exit;
}
function input(): array
{
    static $j = null;
    if ($j === null) {
        $raw = (string)file_get_contents('php://input');
        $j = json_decode($raw !== '' ? $raw : '[]', true);
        if (!is_array($j)) {
            $j = [];
        }
    }
    return $j + $_POST;
}

/* ============ Sesi, CSRF, auth ============ */
function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name('lgz');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'secure' => $https,
        'httponly' => true, 'samesite' => 'Lax',
    ]);
    session_start();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
}
function csrf_check(): void
{
    start_session();
    $t = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!hash_equals((string)$_SESSION['csrf'], $t)) {
        fail('Sesi kedaluwarsa. Muat ulang halaman.', 419);
    }
}
function me(): ?array
{
    start_session();
    $id = $_SESSION['uid'] ?? null;
    if (!$id) {
        return null;
    }
    return row('SELECT * FROM users WHERE id=? AND verified_at IS NOT NULL', [$id]);
}
function need_user(): array
{
    $u = me();
    if (!$u) {
        fail('Silakan masuk dulu.', 401);
    }
    return $u;
}
function need_role(array $roles): array
{
    $u = need_user();
    if (!in_array($u['role'], $roles, true)) {
        fail('Kamu tidak punya akses ke fitur ini.', 403);
    }
    return $u;
}
function login_user(array $u): void
{
    start_session();
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    unset($_SESSION['reset_uid'], $_SESSION['reset_at']);
}
function norm_wa(string $v): string
{
    $d = preg_replace('/\D/', '', $v) ?? '';
    if (str_starts_with($d, '0')) {
        $d = '62' . substr($d, 1);
    }
    return preg_match('/^62\d{8,12}$/', $d) ? $d : '';
}
function find_user(string $id): ?array
{
    $id = trim($id);
    $w = norm_wa($id);
    $e = strtolower($id);
    return row('SELECT * FROM users WHERE verified_at IS NOT NULL AND ((? <> "" AND wa = ?) OR email = ?) LIMIT 1', [$w, $w, $e])
        ?: row('SELECT * FROM users WHERE ((? <> "" AND wa = ?) OR email = ?) LIMIT 1', [$w, $w, $e]);
}
function pw_ok(string $p): bool
{
    return strlen($p) >= 8 && preg_match('/[A-Za-z]/', $p) && preg_match('/\d/', $p);
}
function throttle(string $key, int $max, int $win): void
{
    $k = hash('sha256', $key);
    $c = (int)val('SELECT COUNT(*) FROM throttle WHERE k=? AND at>?', [$k, date('Y-m-d H:i:s', time() - $win)]);
    if ($c >= $max) {
        fail('Terlalu banyak percobaan. Coba lagi beberapa menit lagi.', 429);
    }
    q('INSERT INTO throttle(k,at) VALUES(?,?)', [$k, now()]);
    if (random_int(1, 50) === 1) {
        q('DELETE FROM throttle WHERE at<?', [date('Y-m-d H:i:s', time() - 86400)]);
    }
}

/* ============ URL dasar aplikasi ============ */
function base_url(): string
{
    $b = trim((string)cfg('base_url', ''));
    if ($b !== '') {
        return rtrim($b, '/');
    }
    if (!isset($_SERVER['HTTP_HOST'])) {
        return 'http://localhost';
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $root = str_replace('\\', '/', (string)realpath(__DIR__ . '/..'));
    $doc = str_replace('\\', '/', (string)realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')));
    $path = ($doc !== '' && stripos($root, $doc) === 0) ? substr($root, strlen($doc)) : '';
    return ($https ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . rtrim($path, '/');
}

/* ============ HTTP client (cURL) ============ */
function http_call(string $method, string $url, $body = null, array $headers = [], ?string $userpwd = null, int $timeout = 12): array
{
    $ch = curl_init($url);
    $opt = [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => $headers,
    ];
    if ($userpwd !== null) {
        $opt[CURLOPT_USERPWD] = $userpwd;
    }
    if ($body !== null) {
        $opt[CURLOPT_POSTFIELDS] = $body;
    }
    curl_setopt_array($ch, $opt);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res === false) {
        throw new RuntimeException('Koneksi gagal: ' . $err);
    }
    $j = json_decode((string)$res, true);
    return [$code, is_array($j) ? $j : [], (string)$res];
}

/* ============ Notifikasi (outbox) ============ */
function notify(string $channel, string $target, string $body, string $subject = ''): void
{
    if ($target === '' || ($channel === 'email' && !cfg('mail_enabled', false))) {
        return;
    }
    q('INSERT INTO outbox(channel,target,subject,body,status,created_at) VALUES(?,?,?,?,?,?)',
        [$channel, $target, $subject, $body, 'pending', now()]);
    queue_send((int)db()->lastInsertId());
}
// Pesan dikirim SETELAH respons ke browser selesai, supaya halaman tidak menunggu WhatsApp/email.
function queue_send(int $id): void
{
    static $registered = false;
    $GLOBALS['LGZ_Q'][] = $id;
    if (!$registered) {
        $registered = true;
        register_shutdown_function(function () {
            foreach (($GLOBALS['LGZ_Q'] ?? []) as $qid) {
                try {
                    send_outbox((int)$qid);
                } catch (Throwable $e) {
                    error_log('LGZ queue: ' . $e->getMessage());
                }
            }
        });
    }
}
function send_outbox(int $id): void
{
    $m = row('SELECT * FROM outbox WHERE id=?', [$id]);
    if (!$m || $m['status'] === 'sent') {
        return;
    }
    try {
        if ($m['channel'] === 'whatsapp') {
            wa_send((string)$m['target'], (string)$m['body']);
        } else {
            mail_send((string)$m['target'], (string)$m['subject'], (string)$m['body']);
        }
        q('UPDATE outbox SET status="sent",sent_at=?,tries=tries+1,error=NULL WHERE id=?', [now(), $id]);
    } catch (Throwable $e) {
        q('UPDATE outbox SET status=IF(tries+1>=5,"failed","pending"),tries=tries+1,error=? WHERE id=?',
            [mb_substr($e->getMessage(), 0, 250), $id]);
        error_log('LGZ outbox #' . $id . ': ' . $e->getMessage());
    }
}
function wa_send(string $to, string $msg): void
{
    if (cfg('wa_driver', 'log') === 'fonnte') {
        [$c, $j] = http_call('POST', 'https://api.fonnte.com/send',
            ['target' => $to, 'message' => $msg],
            ['Authorization: ' . cfg('fonnte_token', '')]);
        if ($c >= 400 || empty($j['status'])) {
            throw new RuntimeException('Fonnte: ' . ($j['reason'] ?? $j['detail'] ?? ('HTTP ' . $c)));
        }
        return;
    }
    @file_put_contents(__DIR__ . '/../storage/outbox.log', '[' . now() . "] WA $to: $msg\n", FILE_APPEND | LOCK_EX);
}
function mail_send(string $to, string $subject, string $body): void
{
    $h = 'From: ' . cfg('mail_from', 'no-reply@example.com') . "\r\nContent-Type: text/plain; charset=UTF-8";
    $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject !== '' ? $subject : 'Laundry Gen Z') . '?=', $body, $h);
    if (!$ok) {
        throw new RuntimeException('mail() gagal. Atur SMTP/sendmail di server.');
    }
}

/* ============ OTP ============ */
function otp_hash(string $c): string
{
    return hash_hmac('sha256', $c, (string)cfg('app_key', 'change-me'));
}
function otp_send(string $purpose, array $user, string $channel = 'whatsapp'): ?string
{
    if ($channel === 'email' && !cfg('mail_enabled', false)) {
        $channel = 'whatsapp';
    }
    throttle('otpsend|' . $user['id'] . '|' . ip(), 6, 600);
    $last = val('SELECT MAX(created_at) FROM otp_codes WHERE user_id=? AND purpose=?', [$user['id'], $purpose]);
    if ($last && time() - strtotime((string)$last) < 50) {
        fail('Tunggu sebentar sebelum minta kode lagi.', 429);
    }
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    q('UPDATE otp_codes SET used=1 WHERE user_id=? AND purpose=? AND used=0', [$user['id'], $purpose]);
    q('INSERT INTO otp_codes(user_id,purpose,code_hash,channel,expires_at,created_at) VALUES(?,?,?,?,?,?)',
        [$user['id'], $purpose, otp_hash($code), $channel, date('Y-m-d H:i:s', time() + 300), now()]);
    $msg = "Kode OTP Laundry Gen Z kamu: $code. Berlaku 5 menit. Jangan bagikan ke siapa pun.";
    if ($channel === 'email') {
        notify('email', (string)$user['email'], $msg, 'Kode OTP Laundry Gen Z');
    } else {
        notify('whatsapp', (string)$user['wa'], $msg);
    }
    return cfg('app_env', 'prod') === 'dev' ? $code : null;
}
function otp_verify(string $purpose, array $user, string $code): void
{
    $r = row('SELECT * FROM otp_codes WHERE user_id=? AND purpose=? AND used=0 ORDER BY id DESC LIMIT 1', [$user['id'], $purpose]);
    if (!$r || strtotime((string)$r['expires_at']) < time()) {
        fail('Kode sudah kedaluwarsa. Minta kode baru.', 400, 'otp');
    }
    if ((int)$r['tries'] >= 5) {
        q('UPDATE otp_codes SET used=1 WHERE id=?', [$r['id']]);
        fail('Terlalu banyak percobaan salah. Minta kode baru.', 429, 'otp');
    }
    if (!hash_equals((string)$r['code_hash'], otp_hash(trim($code)))) {
        q('UPDATE otp_codes SET tries=tries+1 WHERE id=?', [$r['id']]);
        fail('Kode salah. Sisa percobaan: ' . (4 - (int)$r['tries']) . '.', 400, 'otp');
    }
    q('UPDATE otp_codes SET used=1 WHERE id=?', [$r['id']]);
}
