<?php
declare(strict_types=1);
// Jalankan SEKALI di browser: http://localhost/laundry-gen-z/install.php
// Setelah selesai, HAPUS file ini dari server.
require __DIR__ . '/src/core.php';

$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$msg = [];
$err = '';
$done = false;

try {
    // 1) Buat database bila belum ada (butuh hak akses; di hosting buat manual lewat phpMyAdmin).
    try {
        $root = new PDO('mysql:host=' . cfg('db_host', '127.0.0.1') . ';charset=utf8mb4', (string)cfg('db_user'), (string)cfg('db_pass', ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $root->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', (string)cfg('db_name')) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $msg[] = 'Database siap.';
    } catch (Throwable $e) {
        $msg[] = 'Lewati pembuatan database (' . $e->getMessage() . '). Pastikan database sudah dibuat manual.';
    }

    // 2) Jalankan skema.
    $sql = (string)file_get_contents(__DIR__ . '/database/schema.sql');
    foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $st) {
        if ($st !== '') {
            db()->exec($st);
        }
    }
    $msg[] = 'Tabel dan data awal siap.';

    $hasAdmin = (int)val('SELECT COUNT(*) FROM users WHERE role="admin"') > 0;
    if ($hasAdmin) {
        $err = 'Sudah ada akun admin, jadi pembuatan akun dikunci. Hapus install.php dari server.';
    } elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $name = trim((string)($_POST['name'] ?? ''));
        $wa = norm_wa((string)($_POST['wa'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass = (string)($_POST['pass'] ?? '');
        if (mb_strlen($name) < 3) {
            $err = 'Isi nama admin.';
        } elseif (!$wa) {
            $err = 'Nomor WhatsApp belum benar.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Format email belum benar.';
        } elseif (!pw_ok($pass)) {
            $err = 'Password minimal 8 karakter dengan huruf dan angka.';
        } else {
            q('INSERT INTO users(role,name,wa,email,pass_hash,verified_at,created_at) VALUES("admin",?,?,?,?,?,?)',
                [$name, $wa, $email, password_hash($pass, PASSWORD_DEFAULT), now(), now()]);
            $done = true;
        }
    }
} catch (Throwable $e) {
    $err = 'Gagal: ' . $e->getMessage();
}
$weakKey = (string)cfg('app_key', '') === 'GANTI-DENGAN-STRING-ACAK-PANJANG' || strlen((string)cfg('app_key', '')) < 16;
$hasAdmin = $hasAdmin ?? false;
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalasi Laundry Gen Z</title>
<style>body{font-family:system-ui,sans-serif;max-width:460px;margin:0 auto;padding:24px 16px;color:#1E1B1F}
h1{margin:0 0 12px}label{display:block;margin:12px 0 4px;font-weight:600}input{width:100%;box-sizing:border-box;padding:12px;border:1.5px solid #bdbbc4;border-radius:10px;font:inherit}
button{margin-top:18px;width:100%;padding:14px;border:0;border-radius:99px;background:#D80067;color:#fff;font:700 16px system-ui;cursor:pointer}
.ok{color:#12805A}.er{color:#C62A2F;font-weight:600}.w{background:#FFEBC7;padding:10px;border-radius:10px}</style></head><body>
<h1>Instalasi Laundry Gen Z</h1>
<?php foreach ($msg as $m): ?><p class="ok"><?= $h($m) ?></p><?php endforeach; ?>
<?php if ($weakKey): ?><p class="w">Ganti <b>app_key</b> di config.php dengan string acak panjang (minimal 16 karakter) sebelum dipakai.</p><?php endif; ?>
<?php if ($err): ?><p class="er"><?= $h($err) ?></p><?php endif; ?>
<?php if ($done): ?>
  <p class="ok"><b>Akun admin dibuat.</b> Sekarang hapus install.php, lalu buka <a href="index.html">index.html</a> dan masuk memakai nomor/email dan password tadi.</p>
<?php elseif (!$hasAdmin): ?>
  <form method="post"><h3>Buat akun admin</h3>
    <label>Nama</label><input name="name" required>
    <label>Nomor WhatsApp</label><input name="wa" required placeholder="0812xxxxxxxx">
    <label>Email</label><input name="email" type="email" required>
    <label>Password</label><input name="pass" type="password" required minlength="8">
    <button>Buat Admin</button></form>
<?php endif; ?>
</body></html>
