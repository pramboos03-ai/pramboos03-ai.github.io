<?php
// Salin file ini menjadi config.php, lalu isi. JANGAN commit config.php ke Git.
return [
  'app_env'   => 'dev',                 // 'dev' = kode OTP tampil di layar & tombol simulasi bayar aktif. Ganti 'prod' saat live.
  'app_key'   => 'GANTI-DENGAN-STRING-ACAK-PANJANG', // dipakai untuk hash OTP
  'timezone'  => 'Asia/Jakarta',
  'base_url'  => '',                    // kosong = deteksi otomatis. Isi saat pakai domain/ngrok, mis. https://abc.ngrok-free.app/laundry-gen-z

  'db_host' => '127.0.0.1',
  'db_name' => 'laundry_genz',
  'db_user' => 'root',
  'db_pass' => '',

  'outlet' => [
    'name' => 'Laundry Gen Z Outlet Pusat',
    'addr' => 'Jl. Contoh Raya No. 12',   // ganti alamat outlet asli
    'wa' => '6281200000000',               // format 62..., tanpa + atau spasi
    'wa_show' => '0812-0000-0000',
    'courier_phone' => '',                 // opsional, format 62...
  ],

  'ship_fee'   => 5000,
  'slot_quota' => 3,                       // maks. pesanan per slot jam
  'slots'      => ['08.00–10.00','10.00–12.00','13.00–15.00','15.00–17.00','18.00–20.00'],
  'aroma'      => ['Sakura Pop','Cotton Fresh','Vanilla Latte','Ocean Breeze','Tanpa parfum'],
  'use_unique_code' => false,              // true = tambah kode unik 11-99 pada QRIS/VA (tidak perlu bila pakai gateway)
  'map_default' => ['lat' => -6.2088, 'lng' => 106.8456],

  // WhatsApp: 'log' (tulis ke storage/outbox.log) atau 'fonnte'
  'wa_driver'    => 'log',
  'fonnte_token' => '',
  'mail_enabled' => false,               // true bila server mail/SMTP sudah siap; bila false, OTP dan struk hanya lewat WhatsApp
  'mail_from'    => 'no-reply@example.com',

  // Pembayaran: 'mock' (tanpa uang, untuk uji) atau 'xendit'
  'pay_driver'            => 'mock',
  'xendit_secret'         => '',          // Secret API key (mulai dengan xnd_development_ atau xnd_production_)
  'xendit_callback_token' => '',          // Verification token dari dashboard Xendit
  'pay_expiry_minutes'    => 15,
];
