<?php
declare(strict_types=1);

const PAY_CHANNELS = [
    'ewallet' => ['OVO' => 'ID_OVO', 'DANA' => 'ID_DANA', 'ShopeePay' => 'ID_SHOPEEPAY', 'LinkAja' => 'ID_LINKAJA'],
    'va' => ['BCA' => 'BCA', 'BNI' => 'BNI', 'Mandiri' => 'MANDIRI', 'BRI' => 'BRI'],
];
const HANDLING = ['Dilipat', 'Digantung'];

/* ============ Pesanan: util ============ */
function add_log(int $oid, int $status, string $text, ?int $uid): void
{
    q('INSERT INTO order_logs(order_id,status,text,user_id,created_at) VALUES(?,?,?,?,?)', [$oid, $status, $text, $uid, now()]);
}
function find_order(string $inv): array
{
    $o = row('SELECT * FROM orders WHERE invoice=?', [$inv]);
    if (!$o) {
        fail('Pesanan tidak ditemukan.', 404);
    }
    return $o;
}
function own_order(array $u, string $inv): array
{
    $o = find_order($inv);
    if ((int)$o['user_id'] !== (int)$u['id']) {
        fail('Pesanan tidak ditemukan.', 404);
    }
    return $o;
}
function order_items(int $oid, bool $final): array
{
    $col = $final ? 'qty_final' : 'qty_est';
    $r = rows("SELECT service_id id, name n, unit u, price p, $col q FROM order_items WHERE order_id=? ORDER BY id", [$oid]);
    foreach ($r as &$i) {
        $i['p'] = (int)$i['p'];
        $i['q'] = (float)$i['q'];
    }
    return $r;
}
function voucher_calc(?string $code, int $sub): int
{
    if (!$code) {
        return 0;
    }
    $v = row('SELECT * FROM vouchers WHERE code=?', [$code]);
    if (!$v || $sub < (int)$v['min_sub']) {
        return 0;
    }
    return $v['type'] === 'pct'
        ? (int)round(min($sub * (int)$v['val'] / 100, (int)$v['max_disc']))
        : (int)$v['val'];
}
function order_totals(array $o): array
{
    $items = order_items((int)$o['id'], (bool)$o['final_set']);
    $sub = 0;
    foreach ($items as $i) {
        $sub += (int)round($i['p'] * $i['q']);
    }
    $ship = $o['method'] === 'pickup' ? (int)cfg('ship_fee', 5000) : 0;
    $disc = voucher_calc($o['voucher'] ?? null, $sub);
    $uniq = (int)$o['uniq_code'];
    return ['sub' => $sub, 'ship' => $ship, 'disc' => $disc, 'uniq' => $uniq, 'total' => max(0, $sub + $ship - $disc) + $uniq];
}
function pay_name(array $p): string
{
    switch ($p['method']) {
        case 'qris': return 'QRIS';
        case 'va': return 'VA ' . $p['channel'];
        case 'cod': return 'COD (tunai)';
        default: return (string)$p['channel'];
    }
}
function pay_label(int $oid): string
{
    $p = row('SELECT * FROM payments WHERE order_id=? AND status="paid" ORDER BY id DESC LIMIT 1', [$oid]);
    if ($p) {
        return 'LUNAS - ' . pay_name($p);
    }
    $c = row('SELECT id FROM payments WHERE order_id=? AND method="cod" AND status="pending" LIMIT 1', [$oid]);
    return $c ? 'BELUM BAYAR - COD' : 'BELUM BAYAR';
}
function order_snapshot(int $oid, string $stage): void
{
    $o = row('SELECT * FROM orders WHERE id=?', [$oid]);
    $items = order_items($oid, $stage !== 'draft' && (bool)$o['final_set']);
    q('INSERT INTO receipts(order_id,stage,items_json,totals_json,pay_label,created_at) VALUES(?,?,?,?,?,?)',
        [$oid, $stage, json_encode($items, JSON_UNESCAPED_UNICODE), json_encode(order_totals($o)), pay_label($oid), now()]);
}
function track_url(string $inv): string
{
    return base_url() . '/track.php?no=' . rawurlencode($inv);
}
function rp(int $n): string
{
    return 'Rp' . number_format($n, 0, ',', '.');
}
function expire_payments(int $oid): void
{
    q('UPDATE payments SET status="expired" WHERE order_id=? AND status="pending" AND expires_at IS NOT NULL AND expires_at<?', [$oid, now()]);
}

function order_json(array $o): array
{
    $oid = (int)$o['id'];
    expire_payments($oid);
    $u = row('SELECT name,wa,email FROM users WHERE id=?', [$o['user_id']]) ?: ['name' => '', 'wa' => '', 'email' => ''];
    $logs = array_map(fn($l) => ['s' => (int)$l['s'], 't' => ms($l['t']), 'x' => $l['x']],
        rows('SELECT status s, text x, created_at t FROM order_logs WHERE order_id=? ORDER BY id', [$oid]));
    $snaps = array_map(fn($r) => [
        'stage' => $r['stage'], 'at' => ms($r['created_at']),
        'items' => json_decode($r['items_json'], true), 'tot' => json_decode($r['totals_json'], true), 'pay' => $r['pay_label'],
    ], rows('SELECT * FROM receipts WHERE order_id=? ORDER BY id', [$oid]));

    $paidRow = row('SELECT * FROM payments WHERE order_id=? AND status="paid" ORDER BY id DESC LIMIT 1', [$oid]);
    $cur = $paidRow ?: row('SELECT * FROM payments WHERE order_id=? AND status IN ("pending","expired") ORDER BY id DESC LIMIT 1', [$oid]);
    $pay = null;
    if ($cur) {
        $pay = [
            'k' => $cur['method'], 'opt' => $cur['channel'], 'st' => $cur['status'],
            'exp' => ms($cur['expires_at']), 'va' => $cur['va_number'], 'qr' => $cur['qr_string'], 'url' => $cur['checkout_url'],
        ];
    }
    $rv = row('SELECT * FROM reviews WHERE order_id=?', [$oid]);
    $proof = val('SELECT id FROM uploads WHERE order_id=? AND kind="proof" ORDER BY id DESC LIMIT 1', [$oid]);

    return [
        'id' => $o['invoice'], 'uid' => (int)$o['user_id'], 'at' => ms($o['created_at']),
        'cust' => ['name' => $u['name'], 'wa' => $u['wa'], 'email' => $u['email']],
        'items' => order_items($oid, false),
        'final' => $o['final_set'] ? order_items($oid, true) : null,
        'opts' => ['aroma' => $o['aroma'], 'handling' => $o['handling'], 'note' => $o['note']],
        'method' => $o['method'], 'slot' => ['date' => $o['slot_date'], 'time' => $o['slot_time']],
        'addr' => $o['addr'], 'voucher' => $o['voucher'] ?? '', 'status' => (int)$o['status'],
        'logs' => $logs, 'snaps' => $snaps,
        'paid' => $paidRow ? ['m' => pay_name($paidRow), 'at' => ms($paidRow['paid_at'])] : null,
        'pay' => $pay, 'uniq' => (int)$o['uniq_code'], 'tot' => order_totals($o),
        'review' => $rv ? ['r' => (int)$rv['rating'], 'text' => $rv['comment'], 'photo' => (bool)$rv['photo_id'], 'pts' => (int)$rv['pts']] : null,
        'bags' => (int)$o['bags'], 'picked' => (bool)$o['picked'], 'canc' => (bool)$o['cancelled_at'],
        'proof' => $proof ? 'file.php?id=' . (int)$proof : null,
    ];
}

/* ============ Upload foto ============ */
function save_upload(array $f, string $kind, int $oid, int $uid): int
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        fail('Unggah foto gagal. Coba lagi.', 422);
    }
    if ((int)$f['size'] > 3 * 1024 * 1024) {
        fail('Ukuran foto maksimal 3 MB.', 422);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext || !@getimagesize($f['tmp_name'])) {
        fail('File harus berupa foto JPG, PNG, atau WebP.', 422);
    }
    $dir = __DIR__ . '/../storage/uploads';
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        fail('Gagal menyimpan foto.', 500);
    }
    q('INSERT INTO uploads(kind,order_id,user_id,filename,mime,created_at) VALUES(?,?,?,?,?,?)', [$kind, $oid, $uid, $name, $mime, now()]);
    return (int)db()->lastInsertId();
}

/* ============ Pembayaran ============ */
function xendit(string $method, string $path, array $body, array $extra = []): array
{
    [$c, $j] = http_call($method, 'https://api.xendit.co' . $path, json_encode($body),
        array_merge(['Content-Type: application/json'], $extra), (string)cfg('xendit_secret', '') . ':');
    if ($c >= 400) {
        error_log('LGZ xendit ' . $path . ' HTTP ' . $c . ' ' . json_encode($j));
        throw new ApiError('Gateway pembayaran menolak permintaan: ' . ($j['message'] ?? $j['error_code'] ?? ('HTTP ' . $c)), 502);
    }
    return $j;
}
function gateway_create(string $m, string $ch, string $ref, int $amount, array $u, array $o): array
{
    if (cfg('pay_driver', 'mock') === 'mock') {
        return [
            'gid' => 'mock-' . $ref,
            'va' => $m === 'va' ? '8808' . str_pad((string)random_int(0, 99999999999), 11, '0', STR_PAD_LEFT) : null,
            'qr' => $m === 'qris' ? 'MOCK-QRIS|' . $ref . '|' . $amount : null,
            'url' => null,
        ];
    }
    $exp = gmdate('Y-m-d\TH:i:s\Z', time() + 60 * (int)cfg('pay_expiry_minutes', 15));
    if ($m === 'qris') {
        $j = xendit('POST', '/qr_codes', ['reference_id' => $ref, 'type' => 'DYNAMIC', 'currency' => 'IDR', 'amount' => $amount],
            ['api-version: 2022-07-31']);
        return ['gid' => $j['id'] ?? null, 'va' => null, 'qr' => $j['qr_string'] ?? null, 'url' => null];
    }
    if ($m === 'ewallet') {
        $code = PAY_CHANNELS['ewallet'][$ch];
        $props = $code === 'ID_OVO'
            ? ['mobile_number' => '+' . $u['wa']]
            : ['success_redirect_url' => base_url() . '/index.html', 'failure_redirect_url' => base_url() . '/index.html'];
        $j = xendit('POST', '/ewallets/charges', [
            'reference_id' => $ref, 'currency' => 'IDR', 'amount' => $amount,
            'checkout_method' => 'ONE_TIME_PAYMENT', 'channel_code' => $code, 'channel_properties' => $props,
        ]);
        $a = $j['actions'] ?? [];
        $url = $a['desktop_web_checkout_url'] ?? $a['mobile_web_checkout_url'] ?? $a['mobile_deeplink_checkout_url'] ?? null;
        return ['gid' => $j['id'] ?? null, 'va' => null, 'qr' => null, 'url' => $url];
    }
    $j = xendit('POST', '/callback_virtual_accounts', [
        'external_id' => $ref, 'bank_code' => PAY_CHANNELS['va'][$ch], 'name' => 'LAUNDRY GEN Z',
        'is_closed' => true, 'expected_amount' => $amount, 'is_single_use' => true, 'expiration_date' => $exp,
    ]);
    return ['gid' => $j['id'] ?? null, 'va' => $j['account_number'] ?? null, 'qr' => null, 'url' => null];
}
function pay_mark_paid(int $pid): void
{
    $done = false;
    db()->beginTransaction();
    try {
        $p = row('SELECT * FROM payments WHERE id=? FOR UPDATE', [$pid]);
        if (!$p || $p['status'] === 'paid') {
            db()->commit();
            return;
        }
        q('UPDATE payments SET status="paid",paid_at=? WHERE id=?', [now(), $pid]);
        q('UPDATE payments SET status="cancelled" WHERE order_id=? AND status="pending" AND id<>?', [$p['order_id'], $pid]);
        $o = row('SELECT * FROM orders WHERE id=?', [$p['order_id']]);
        add_log((int)$o['id'], (int)$o['status'], 'Pembayaran diterima (' . pay_name($p) . ').', null);
        order_snapshot((int)$o['id'], 'lunas');
        db()->commit();
        $done = true;
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
    if ($done) {
        $u = row('SELECT * FROM users WHERE id=?', [$o['user_id']]);
        $tot = order_totals($o);
        $msg = 'Pembayaran ' . rp($tot['total']) . ' untuk ' . $o['invoice'] . ' diterima. Struk Lunas: ' . track_url($o['invoice']);
        notify('whatsapp', (string)$u['wa'], $msg);
        notify('email', (string)$u['email'], $msg, 'Struk Lunas ' . $o['invoice']);
    }
}
function pay_confirm_by_ref(string $ref, ?int $amount): string
{
    $p = row('SELECT * FROM payments WHERE ref=?', [$ref]);
    if (!$p) {
        return 'unknown';
    }
    if ($p['status'] === 'paid') {
        return 'already';
    }
    if ($amount !== null && $amount !== (int)$p['amount']) {
        error_log("LGZ nominal tidak cocok untuk $ref: $amount vs {$p['amount']}");
        return 'mismatch';
    }
    pay_mark_paid((int)$p['id']);
    return 'paid';
}

/* ============ Rute API ============ */
function r_state(): array
{
    $u = me();
    $staff = $u && $u['role'] !== 'customer';
    $o = cfg('outlet', []);
    $svc = rows('SELECT id,cat,name n,unit u,price p,hours h,active FROM services ORDER BY FIELD(cat,"kiloan","satuan","express","special"), id');
    foreach ($svc as &$s) {
        $s['p'] = (int)$s['p'];
        $s['h'] = (int)$s['h'];
        $s['active'] = (int)$s['active'];
    }
    unset($s);
    if (!($u && $u['role'] === 'admin')) {
        $svc = array_values(array_filter($svc, fn($s) => $s['active'] === 1));
    }
    $vouchers = [];
    if ($u && $u['role'] === 'customer') {
        foreach (rows('SELECT * FROM vouchers WHERE active=1 AND (valid_until IS NULL OR valid_until>=?)', [date('Y-m-d')]) as $v) {
            if ($v['once_per_user'] && (int)val('SELECT COUNT(*) FROM voucher_uses WHERE code=? AND user_id=?', [$v['code'], $u['id']]) > 0) {
                continue;
            }
            $vouchers[] = ['code' => $v['code'], 't' => $v['type'], 'v' => (int)$v['val'], 'max' => (int)$v['max_disc'], 'min' => (int)$v['min_sub'], 'label' => $v['label']];
        }
    }
    $orders = [];
    if ($u) {
        if ($staff) {
            $os = rows('SELECT * FROM orders WHERE status<5 OR created_at>=? ORDER BY id DESC LIMIT 120', [date('Y-m-d H:i:s', time() - 7 * 86400)]);
        } else {
            $os = rows('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 100', [$u['id']]);
        }
        $orders = array_map('order_json', $os);
    }
    $slots = [];
    foreach (rows('SELECT slot_date d, slot_time t, COUNT(*) c FROM orders WHERE status=0 AND cancelled_at IS NULL AND slot_date>=? GROUP BY slot_date, slot_time', [date('Y-m-d')]) as $r) {
        $slots[$r['d'] . '|' . $r['t']] = (int)$r['c'];
    }
    return [
        'csrf' => $_SESSION['csrf'],
        'me' => $u ? ['id' => (int)$u['id'], 'role' => $u['role'], 'name' => $u['name'], 'wa' => $u['wa'], 'email' => $u['email'],
            'addr' => $u['addr'], 'lat' => $u['lat'], 'lng' => $u['lng'], 'pts' => (int)$u['pts']] : null,
        'services' => $svc, 'vouchers' => $vouchers, 'orders' => $orders, 'slots' => $slots,
        'staff' => ($u && $u['role'] === 'admin') ? rows('SELECT id,role,name,wa,email FROM users WHERE role<>"customer" ORDER BY id') : [],
        'cfg' => [
            'outlet' => ['name' => $o['name'] ?? '', 'addr' => $o['addr'] ?? '', 'wa' => $o['wa'] ?? '', 'waShow' => $o['wa_show'] ?? '', 'courier' => $o['courier_phone'] ?? ''],
            'ship' => (int)cfg('ship_fee', 5000), 'slots' => cfg('slots', []), 'aroma' => cfg('aroma', []), 'quota' => (int)cfg('slot_quota', 3),
            'env' => cfg('app_env', 'prod'), 'email_otp' => (bool)cfg('mail_enabled', false), 'pay_driver' => cfg('pay_driver', 'mock'), 'unique_code' => (bool)cfg('use_unique_code', false),
            'map' => cfg('map_default', ['lat' => -6.2088, 'lng' => 106.8456]), 'track_base' => base_url() . '/track.php?no=',
        ],
    ];
}

/* ---- Auth ---- */
function r_register(): array
{
    $i = input();
    throttle('reg|' . ip(), 10, 3600);
    $name = trim((string)($i['name'] ?? ''));
    if (mb_strlen($name) < 3 || mb_strlen($name) > 100) {
        fail('Isi nama lengkap, minimal 3 huruf.', 422, 'name');
    }
    $wa = norm_wa((string)($i['wa'] ?? ''));
    if (!$wa) {
        fail('Nomor WhatsApp belum benar. Contoh: 081234567890.', 422, 'wa');
    }
    $email = strtolower(trim((string)($i['email'] ?? '')));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) {
        fail('Format email belum benar.', 422, 'email');
    }
    $pass = (string)($i['pass'] ?? '');
    if (!pw_ok($pass)) {
        fail('Minimal 8 karakter dengan huruf dan angka.', 422, 'pass');
    }
    $addr = trim((string)($i['addr'] ?? ''));
    if (mb_strlen($addr) < 8 || mb_strlen($addr) > 400) {
        fail('Isi alamat lengkap, minimal 8 karakter.', 422, 'addr');
    }
    if (row('SELECT id FROM users WHERE wa=? AND verified_at IS NOT NULL', [$wa])) {
        fail('Nomor ini sudah terdaftar. Silakan masuk.', 409, 'wa');
    }
    if (row('SELECT id FROM users WHERE email=? AND verified_at IS NOT NULL', [$email])) {
        fail('Email ini sudah terdaftar.', 409, 'email');
    }
    q('DELETE FROM users WHERE verified_at IS NULL AND (wa=? OR email=?)', [$wa, $email]);
    $lat = is_numeric($i['lat'] ?? null) && abs((float)$i['lat']) <= 90 ? (float)$i['lat'] : null;
    $lng = is_numeric($i['lng'] ?? null) && abs((float)$i['lng']) <= 180 ? (float)$i['lng'] : null;
    q('INSERT INTO users(role,name,wa,email,pass_hash,addr,lat,lng,created_at) VALUES("customer",?,?,?,?,?,?,?,?)',
        [$name, $wa, $email, password_hash($pass, PASSWORD_DEFAULT), $addr, $lat, $lng, now()]);
    $u = row('SELECT * FROM users WHERE id=?', [db()->lastInsertId()]);
    $dev = otp_send('register', $u);
    return ['otp' => true, 'target' => $wa, 'dev' => $dev];
}
function r_verify(): array
{
    $i = input();
    $purpose = (string)($i['purpose'] ?? '');
    if (!in_array($purpose, ['register', 'login', 'forgot'], true)) {
        fail('Permintaan tidak valid.', 422);
    }
    throttle('otpv|' . strtolower((string)($i['target'] ?? '')) . '|' . ip(), 15, 900);
    $u = find_user((string)($i['target'] ?? ''));
    if (!$u || ($purpose === 'register') === ($u['verified_at'] !== null) || ($purpose !== 'register' && $u['role'] !== 'customer')) {
        fail('Kode salah atau sudah kedaluwarsa.', 400, 'otp');
    }
    otp_verify($purpose, $u, (string)($i['code'] ?? ''));
    if ($purpose === 'register') {
        q('UPDATE users SET verified_at=? WHERE id=?', [now(), $u['id']]);
        login_user($u);
    } elseif ($purpose === 'login') {
        login_user($u);
    } else {
        $_SESSION['reset_uid'] = (int)$u['id'];
        $_SESSION['reset_at'] = time();
    }
    return ['ok' => true];
}
function r_login(): array
{
    $i = input();
    $id = trim((string)($i['id'] ?? ''));
    throttle('login|' . strtolower($id) . '|' . ip(), 8, 900);
    $u = find_user($id);
    $hash = $u['pass_hash'] ?? '$2y$10$abcdefghijklmnopqrstuuMwP7e5u0Fq0aWjV0m0bq1kB2Zt3JZ5W';
    if (!$u || $u['verified_at'] === null || !password_verify((string)($i['pass'] ?? ''), $hash)) {
        fail('Nomor/email atau password salah.', 401, 'pass');
    }
    if (password_needs_rehash($u['pass_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash((string)$i['pass'], PASSWORD_DEFAULT), $u['id']]);
    }
    login_user($u);
    return ['ok' => true];
}
function r_otp_login(): array
{
    $i = input();
    $id = trim((string)($i['id'] ?? ''));
    $u = find_user($id);
    $dev = null;
    if ($u && $u['verified_at'] !== null && $u['role'] === 'customer') {
        $dev = otp_send('login', $u);
    }
    return ['otp' => true, 'target' => $id, 'dev' => $dev];
}
function r_forgot(): array
{
    $i = input();
    $id = trim((string)($i['id'] ?? ''));
    $u = find_user($id);
    $dev = null;
    if ($u && $u['verified_at'] !== null && $u['role'] === 'customer') {
        $dev = otp_send('forgot', $u);
    }
    return ['otp' => true, 'target' => $id, 'dev' => $dev];
}
function r_resend(): array
{
    $i = input();
    $purpose = (string)($i['purpose'] ?? '');
    if (!in_array($purpose, ['register', 'login', 'forgot'], true)) {
        fail('Permintaan tidak valid.', 422);
    }
    $ch = ($i['channel'] ?? '') === 'email' ? 'email' : 'whatsapp';
    $u = find_user((string)($i['target'] ?? ''));
    $dev = null;
    if ($u && ($purpose === 'register') === ($u['verified_at'] === null) && ($purpose === 'register' || $u['role'] === 'customer')) {
        $dev = otp_send($purpose, $u, $ch);
    }
    return ['ok' => true, 'dev' => $dev];
}
function r_reset(): array
{
    start_session();
    $uid = (int)($_SESSION['reset_uid'] ?? 0);
    if (!$uid || time() - (int)($_SESSION['reset_at'] ?? 0) > 600) {
        fail('Sesi reset habis. Ulangi dari awal.', 400);
    }
    $p = (string)(input()['pass'] ?? '');
    if (!pw_ok($p)) {
        fail('Minimal 8 karakter dengan huruf dan angka.', 422, 'pass');
    }
    q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($p, PASSWORD_DEFAULT), $uid]);
    unset($_SESSION['reset_uid'], $_SESSION['reset_at']);
    return ['ok' => true];
}
function r_logout(): array
{
    start_session();
    $_SESSION = [];
    session_regenerate_id(true);
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return ['ok' => true];
}
function r_profile_save(): array
{
    $u = need_role(['customer']);
    $i = input();
    $a = trim((string)($i['addr'] ?? ''));
    if (mb_strlen($a) < 8 || mb_strlen($a) > 400) {
        fail('Alamat terlalu pendek.', 422, 'addr');
    }
    q('UPDATE users SET addr=? WHERE id=?', [$a, $u['id']]);
    return ['ok' => true];
}

/* ---- Pesanan ---- */
function r_orders_create(): array
{
    $u = need_role(['customer']);
    $i = input();
    throttle('order|' . $u['id'], 20, 3600);
    $raw = $i['items'] ?? [];
    if (!is_array($raw) || !$raw) {
        fail('Pilih minimal satu layanan.', 422);
    }
    $svc = [];
    foreach (rows('SELECT * FROM services WHERE active=1') as $s) {
        $svc[$s['id']] = $s;
    }
    $items = [];
    $sub = 0;
    foreach ($raw as $it) {
        $id = (string)($it['id'] ?? '');
        $s = $svc[$id] ?? null;
        if (!$s || isset($items[$id])) {
            fail('Layanan tidak tersedia.', 422);
        }
        $q = round((float)($it['q'] ?? 0), 1);
        if ($s['unit'] === 'pcs') {
            $q = (float)(int)$q;
        }
        $min = $s['unit'] === 'kg' ? 0.5 : 1;
        $max = $s['unit'] === 'kg' ? 100 : 50;
        if ($q < $min || $q > $max) {
            fail('Jumlah ' . $s['name'] . ' di luar batas.', 422);
        }
        $items[$id] = ['s' => $s, 'q' => $q];
        $sub += (int)round((int)$s['price'] * $q);
    }
    $method = ($i['method'] ?? '') === 'dropoff' ? 'dropoff' : 'pickup';
    $date = (string)($i['date'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $date < date('Y-m-d')) {
        fail('Tanggal tidak valid.', 422, 'date');
    }
    $time = (string)($i['time'] ?? '');
    if (!in_array($time, (array)cfg('slots', []), true)) {
        fail('Pilih slot jam.', 422, 'time');
    }
    if ($date === date('Y-m-d') && (int)substr($time, 0, 2) <= (int)date('G')) {
        fail('Slot itu sudah lewat.', 422, 'time');
    }
    if ((int)val('SELECT COUNT(*) FROM orders WHERE slot_date=? AND slot_time=? AND status=0 AND cancelled_at IS NULL', [$date, $time]) >= (int)cfg('slot_quota', 3)) {
        fail('Slot itu sudah penuh. Pilih slot lain.', 409, 'time');
    }
    $addr = trim((string)($i['addr'] ?? ''));
    if ($method === 'pickup') {
        if (mb_strlen($addr) < 8 || mb_strlen($addr) > 400) {
            fail('Isi alamat penjemputan.', 422, 'addr');
        }
    } else {
        $addr = ((array)cfg('outlet', []))['addr'] . ' (drop-off)';
    }
    $aroma = (string)($i['aroma'] ?? '');
    if (!in_array($aroma, (array)cfg('aroma', []), true)) {
        fail('Pilih aroma pewangi.', 422);
    }
    $handling = (string)($i['handling'] ?? '');
    if (!in_array($handling, HANDLING, true)) {
        fail('Pilih hasil akhir: dilipat atau digantung.', 422);
    }
    $note = mb_substr(trim((string)($i['note'] ?? '')), 0, 300);
    $voucher = null;
    $vc = strtoupper(trim((string)($i['voucher'] ?? '')));
    if ($vc !== '') {
        $v = row('SELECT * FROM vouchers WHERE code=? AND active=1 AND (valid_until IS NULL OR valid_until>=?)', [$vc, date('Y-m-d')]);
        if (!$v) {
            fail('Kode voucher tidak valid.', 422, 'voucher');
        }
        if ($sub < (int)$v['min_sub']) {
            fail('Belanja minimal ' . rp((int)$v['min_sub']) . ' untuk kode ini.', 422, 'voucher');
        }
        if ($v['once_per_user'] && (int)val('SELECT COUNT(*) FROM voucher_uses WHERE code=? AND user_id=?', [$vc, $u['id']]) > 0) {
            fail('Voucher ini sudah pernah kamu pakai.', 422, 'voucher');
        }
        $voucher = $vc;
    }
    $lat = is_numeric($i['lat'] ?? null) && abs((float)$i['lat']) <= 90 ? (float)$i['lat'] : null;
    $lng = is_numeric($i['lng'] ?? null) && abs((float)$i['lng']) <= 180 ? (float)$i['lng'] : null;

    db()->beginTransaction();
    try {
        $d = date('Y-m-d');
        q('INSERT INTO invoice_seq(day,n) VALUES(?,1) ON DUPLICATE KEY UPDATE n=n+1', [$d]);
        $n = (int)val('SELECT n FROM invoice_seq WHERE day=?', [$d]);
        $inv = 'LGZ-' . date('Ymd') . '-' . str_pad((string)$n, 4, '0', STR_PAD_LEFT);
        q('INSERT INTO orders(invoice,user_id,method,slot_date,slot_time,addr,lat,lng,aroma,handling,note,voucher,status,created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0,?)',
            [$inv, $u['id'], $method, $date, $time, $addr, $lat, $lng, $aroma, $handling, $note, $voucher, now()]);
        $oid = (int)db()->lastInsertId();
        foreach ($items as $id => $it) {
            q('INSERT INTO order_items(order_id,service_id,name,unit,price,qty_est) VALUES(?,?,?,?,?,?)',
                [$oid, $id, $it['s']['name'], $it['s']['unit'], $it['s']['price'], $it['q']]);
        }
        if ($voucher) {
            q('INSERT INTO voucher_uses(code,user_id,order_id) VALUES(?,?,?)', [$voucher, $u['id'], $oid]);
        }
        add_log($oid, 0, $method === 'pickup' ? 'Pesanan dibuat. Kurir dijadwalkan menjemput.' : 'Pesanan dibuat. Menunggu kamu datang ke outlet.', (int)$u['id']);
        order_snapshot($oid, 'draft');
        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
    notify('whatsapp', (string)$u['wa'], "Pesanan $inv diterima. Struk awal & pelacakan: " . track_url($inv));
    return ['id' => $inv];
}
function r_orders_cancel(): array
{
    $u = need_role(['customer']);
    $o = own_order($u, (string)(input()['id'] ?? ''));
    if ((int)$o['status'] !== 0 || $o['cancelled_at']) {
        fail('Pesanan hanya bisa dibatalkan sebelum cucian tiba di outlet.', 409);
    }
    q('UPDATE orders SET cancelled_at=? WHERE id=?', [now(), $o['id']]);
    q('UPDATE payments SET status="cancelled" WHERE order_id=? AND status="pending"', [$o['id']]);
    q('DELETE FROM voucher_uses WHERE order_id=?', [$o['id']]);
    add_log((int)$o['id'], 0, 'Pesanan dibatalkan oleh pelanggan.', (int)$u['id']);
    return ['ok' => true];
}
function r_orders_weigh(): array
{
    $u = need_role(['kasir', 'admin']);
    $i = input();
    $o = find_order((string)($i['id'] ?? ''));
    if ((int)$o['status'] !== 0 || $o['final_set'] || $o['cancelled_at']) {
        fail('Pesanan ini tidak bisa ditimbang ulang.', 409);
    }
    $vals = is_array($i['items'] ?? null) ? $i['items'] : [];
    $bags = (int)($i['bags'] ?? 1);
    if ($bags < 1 || $bags > 50) {
        fail('Jumlah kantong 1-50.', 422);
    }
    db()->beginTransaction();
    try {
        foreach (rows('SELECT * FROM order_items WHERE order_id=?', [$o['id']]) as $it) {
            $q = round((float)($vals[$it['service_id']] ?? 0), 1);
            if ($it['unit'] === 'pcs') {
                $q = (float)(int)$q;
            }
            if ($q <= 0 || $q > 500) {
                throw new ApiError('Isi berat atau jumlah yang valid untuk ' . $it['name'] . '.', 422);
            }
            q('UPDATE order_items SET qty_final=? WHERE id=?', [$q, $it['id']]);
        }
        q('UPDATE orders SET final_set=1,status=1,bags=? WHERE id=?', [$bags, $o['id']]);
        add_log((int)$o['id'], 1, 'Cucian tiba dan ditimbang ulang. Struk Final terbit.', (int)$u['id']);
        order_snapshot((int)$o['id'], 'final');
        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
    $o = row('SELECT * FROM orders WHERE id=?', [$o['id']]);
    $cu = row('SELECT * FROM users WHERE id=?', [$o['user_id']]);
    $tot = order_totals($o);
    notify('whatsapp', (string)$cu['wa'], 'Struk Final ' . $o['invoice'] . ': total ' . rp($tot['total']) . '. Buka aplikasi untuk membayar. Pelacakan: ' . track_url($o['invoice']));
    return ['ok' => true];
}
function r_orders_advance(): array
{
    $u = need_role(['kasir', 'admin']);
    $o = find_order((string)(input()['id'] ?? ''));
    $s = (int)$o['status'];
    if ($o['cancelled_at'] || !$o['final_set'] || $s < 1 || $s > 4) {
        fail('Status tidak bisa dimajukan.', 409);
    }
    if ($s === 4 && $o['method'] !== 'dropoff') {
        fail('Pesanan ini diantar kurir.', 409);
    }
    $n = $s + 1;
    $tx = [
        2 => 'Cucian sedang dicuci dan dikeringkan.',
        3 => 'Masuk tahap setrika dan quality control.',
        4 => $o['method'] === 'pickup' ? 'Sudah dipacking, menunggu kurir mengantar.' : 'Sudah dipacking dan siap diambil di outlet.',
        5 => 'Cucian diambil pelanggan di outlet.',
    ][$n];
    q('UPDATE orders SET status=? WHERE id=?', [$n, $o['id']]);
    add_log((int)$o['id'], $n, $tx, (int)$u['id']);
    $cu = row('SELECT * FROM users WHERE id=?', [$o['user_id']]);
    if ($n === 4) {
        notify('whatsapp', (string)$cu['wa'], 'Cucian ' . $o['invoice'] . ' sudah selesai dan siap ' . ($o['method'] === 'pickup' ? 'diantar kurir.' : 'diambil di outlet.'));
    }
    if ($n === 5) {
        notify('whatsapp', (string)$cu['wa'], 'Pesanan ' . $o['invoice'] . ' sudah diserahterimakan. Beri ulasan untuk dapat poin!');
        notify('email', (string)$cu['email'], 'Pesanan ' . $o['invoice'] . ' selesai diserahterimakan.', 'Pesanan selesai ' . $o['invoice']);
    }
    return ['ok' => true];
}
function r_orders_picked(): array
{
    $u = need_role(['kurir', 'admin']);
    $o = find_order((string)(input()['id'] ?? ''));
    if ($o['method'] !== 'pickup' || (int)$o['status'] !== 0 || $o['picked'] || $o['cancelled_at']) {
        fail('Tugas jemput ini tidak valid.', 409);
    }
    q('UPDATE orders SET picked=1 WHERE id=?', [$o['id']]);
    add_log((int)$o['id'], 0, 'Kurir sudah mengambil cucian dan menuju outlet.', (int)$u['id']);
    $cu = row('SELECT * FROM users WHERE id=?', [$o['user_id']]);
    notify('whatsapp', (string)$cu['wa'], 'Kurir sudah mengambil cucian ' . $o['invoice'] . '.');
    return ['ok' => true];
}
function r_orders_deliver(): array
{
    $u = need_role(['kurir', 'admin']);
    $i = input();
    $o = find_order((string)($i['id'] ?? ''));
    if ($o['method'] !== 'pickup' || (int)$o['status'] !== 4 || $o['cancelled_at']) {
        fail('Pesanan ini belum siap diantar.', 409);
    }
    if (empty($_FILES['proof']['name'])) {
        fail('Unggah foto bukti serah terima dulu.', 422);
    }
    $paid = (int)val('SELECT COUNT(*) FROM payments WHERE order_id=? AND status="paid"', [$o['id']]);
    $cod = row('SELECT * FROM payments WHERE order_id=? AND method="cod" AND status="pending" ORDER BY id DESC LIMIT 1', [$o['id']]);
    if (!$paid) {
        if (!$cod) {
            fail('Pesanan belum lunas. Minta pelanggan bayar lewat aplikasi atau pilih COD.', 409);
        }
        if (empty($i['cod_received'])) {
            fail('Centang dulu setelah menerima uang tunai.', 422);
        }
    }
    save_upload($_FILES['proof'], 'proof', (int)$o['id'], (int)$u['id']);
    if (!$paid) {
        pay_mark_paid((int)$cod['id']);
    }
    q('UPDATE orders SET status=5 WHERE id=?', [$o['id']]);
    add_log((int)$o['id'], 5, 'Cucian diserahkan ke pelanggan. Foto bukti tersimpan.', (int)$u['id']);
    $cu = row('SELECT * FROM users WHERE id=?', [$o['user_id']]);
    notify('whatsapp', (string)$cu['wa'], 'Pesanan ' . $o['invoice'] . ' sudah diserahterimakan. Beri ulasan untuk dapat poin!');
    notify('email', (string)$cu['email'], 'Pesanan ' . $o['invoice'] . ' selesai diserahterimakan.', 'Pesanan selesai ' . $o['invoice']);
    return ['ok' => true];
}
function r_orders_review(): array
{
    $u = need_role(['customer']);
    $i = input();
    $o = own_order($u, (string)($i['id'] ?? ''));
    if ((int)$o['status'] !== 5 || $o['cancelled_at']) {
        fail('Ulasan dibuka setelah pesanan selesai.', 409);
    }
    if (row('SELECT id FROM reviews WHERE order_id=?', [$o['id']])) {
        fail('Pesanan ini sudah diulas.', 409);
    }
    $r = (int)($i['rating'] ?? 0);
    if ($r < 1 || $r > 5) {
        fail('Pilih rating 1-5.', 422);
    }
    $c = mb_substr(trim((string)($i['comment'] ?? '')), 0, 500);
    $photo = !empty($_FILES['photo']['name']) ? save_upload($_FILES['photo'], 'review', (int)$o['id'], (int)$u['id']) : null;
    $pts = 25 + ($photo ? 25 : 0);
    db()->beginTransaction();
    try {
        q('INSERT INTO reviews(order_id,user_id,rating,comment,photo_id,pts,created_at) VALUES(?,?,?,?,?,?,?)', [$o['id'], $u['id'], $r, $c, $photo, $pts, now()]);
        q('UPDATE users SET pts=pts+? WHERE id=?', [$pts, $u['id']]);
        q('INSERT INTO point_logs(user_id,delta,reason,order_id,created_at) VALUES(?,?,?,?,?)', [$u['id'], $pts, 'Ulasan ' . $o['invoice'], $o['id'], now()]);
        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
    return ['pts' => $pts];
}
function r_orders_send_receipt(): array
{
    $u = need_role(['customer']);
    $o = own_order($u, (string)(input()['id'] ?? ''));
    throttle('sendrc|' . $u['id'], 10, 3600);
    $tot = order_totals($o);
    notify('whatsapp', (string)$u['wa'], 'Struk Laundry Gen Z ' . $o['invoice'] . ' (total ' . rp($tot['total']) . '): ' . track_url($o['invoice']));
    return ['ok' => true];
}

/* ---- Pembayaran ---- */
function r_pay_start(): array
{
    $u = need_role(['customer']);
    $i = input();
    $o = own_order($u, (string)($i['id'] ?? ''));
    if ($o['cancelled_at']) {
        fail('Pesanan sudah dibatalkan.', 409);
    }
    if (!$o['final_set']) {
        fail('Pembayaran dibuka setelah cucian ditimbang di outlet.', 409);
    }
    if ((int)val('SELECT COUNT(*) FROM payments WHERE order_id=? AND status="paid"', [$o['id']]) > 0) {
        fail('Pesanan ini sudah lunas.', 409);
    }
    $m = (string)($i['method'] ?? '');
    $ch = (string)($i['channel'] ?? '');
    if (!in_array($m, ['qris', 'ewallet', 'va', 'cod'], true)) {
        fail('Metode pembayaran tidak dikenal.', 422);
    }
    if (isset(PAY_CHANNELS[$m])) {
        if (!isset(PAY_CHANNELS[$m][$ch])) {
            fail('Pilihan channel tidak valid.', 422);
        }
    } else {
        $ch = '';
    }
    if ($m === 'cod' && $o['method'] !== 'pickup') {
        fail('COD hanya untuk pesanan yang diantar kurir.', 422);
    }
    throttle('paystart|' . $u['id'], 15, 600);
    q('UPDATE payments SET status="cancelled" WHERE order_id=? AND status="pending"', [$o['id']]);
    $uniq = (cfg('use_unique_code', false) && in_array($m, ['qris', 'va'], true)) ? random_int(11, 99) : 0;
    q('UPDATE orders SET uniq_code=? WHERE id=?', [$uniq, $o['id']]);
    $o['uniq_code'] = $uniq;
    $tot = order_totals($o);
    $exp = $m === 'cod' ? null : date('Y-m-d H:i:s', time() + 60 * (int)cfg('pay_expiry_minutes', 15));
    q('INSERT INTO payments(order_id,method,channel,amount,ref,status,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?)',
        [$o['id'], $m, $ch, $tot['total'], 'tmp' . bin2hex(random_bytes(6)), 'pending', $exp, now()]);
    $pid = (int)db()->lastInsertId();
    $ref = $o['invoice'] . '-P' . $pid;
    q('UPDATE payments SET ref=? WHERE id=?', [$ref, $pid]);
    if ($m !== 'cod') {
        try {
            $g = gateway_create($m, $ch, $ref, (int)$tot['total'], $u, $o);
            q('UPDATE payments SET gateway_id=?,va_number=?,qr_string=?,checkout_url=? WHERE id=?', [$g['gid'], $g['va'], $g['qr'], $g['url'], $pid]);
        } catch (Throwable $e) {
            q('UPDATE payments SET status="failed" WHERE id=?', [$pid]);
            throw $e;
        }
    }
    return ['ok' => true];
}
function r_pay_cancel(): array
{
    $u = need_role(['customer']);
    $o = own_order($u, (string)(input()['id'] ?? ''));
    q('UPDATE payments SET status="cancelled" WHERE order_id=? AND status IN ("pending","expired")', [$o['id']]);
    q('UPDATE orders SET uniq_code=0 WHERE id=?', [$o['id']]);
    return ['ok' => true];
}
function r_pay_simulate(): array
{
    $u = need_user();
    if (cfg('app_env', 'prod') !== 'dev' || cfg('pay_driver', 'mock') !== 'mock') {
        fail('Simulasi hanya aktif di mode pengembangan dengan pay_driver = mock.', 403);
    }
    $o = find_order((string)(input()['id'] ?? ''));
    if ($u['role'] === 'customer' && (int)$o['user_id'] !== (int)$u['id']) {
        fail('Pesanan tidak ditemukan.', 404);
    }
    $p = row('SELECT * FROM payments WHERE order_id=? AND status="pending" AND method<>"cod" ORDER BY id DESC LIMIT 1', [$o['id']]);
    if (!$p) {
        fail('Tidak ada pembayaran yang menunggu.', 409);
    }
    pay_confirm_by_ref((string)$p['ref'], null);
    return ['ok' => true];
}

/* ---- Admin ---- */
function r_admin_staff(): array
{
    need_role(['admin']);
    $i = input();
    $role = (string)($i['role'] ?? '');
    if (!in_array($role, ['kasir', 'kurir', 'admin'], true)) {
        fail('Pilih peran staf.', 422, 's_role');
    }
    $name = trim((string)($i['name'] ?? ''));
    if (mb_strlen($name) < 3) {
        fail('Isi nama staf.', 422, 's_name');
    }
    $wa = norm_wa((string)($i['wa'] ?? ''));
    if (!$wa) {
        fail('Nomor WhatsApp belum benar.', 422, 's_wa');
    }
    $email = strtolower(trim((string)($i['email'] ?? '')));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('Format email belum benar.', 422, 's_email');
    }
    $pass = (string)($i['pass'] ?? '');
    if (!pw_ok($pass)) {
        fail('Minimal 8 karakter dengan huruf dan angka.', 422, 's_pass');
    }
    if (row('SELECT id FROM users WHERE wa=? OR email=?', [$wa, $email])) {
        fail('Nomor atau email sudah dipakai akun lain.', 409, 's_wa');
    }
    q('INSERT INTO users(role,name,wa,email,pass_hash,verified_at,created_at) VALUES(?,?,?,?,?,?,?)',
        [$role, $name, $wa, $email, password_hash($pass, PASSWORD_DEFAULT), now(), now()]);
    return ['ok' => true];
}
function r_admin_service(): array
{
    need_role(['admin']);
    $i = input();
    $price = (int)($i['price'] ?? 0);
    if ($price < 500 || $price > 5000000) {
        fail('Harga harus antara Rp500 dan Rp5.000.000.', 422);
    }
    $n = q('UPDATE services SET price=?, active=? WHERE id=?', [$price, empty($i['active']) ? 0 : 1, (string)($i['id'] ?? '')])->rowCount();
    return ['ok' => true, 'n' => $n];
}
