SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role ENUM('customer','kasir','kurir','admin') NOT NULL DEFAULT 'customer',
  name VARCHAR(100) NOT NULL,
  wa VARCHAR(20) NOT NULL,
  email VARCHAR(120) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  addr TEXT NULL,
  lat DECIMAL(10,7) NULL,
  lng DECIMAL(10,7) NULL,
  pts INT NOT NULL DEFAULT 0,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_wa (wa),
  UNIQUE KEY uq_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS otp_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  purpose ENUM('register','login','forgot') NOT NULL,
  code_hash CHAR(64) NOT NULL,
  channel VARCHAR(12) NOT NULL DEFAULT 'whatsapp',
  expires_at DATETIME NOT NULL,
  tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  KEY k_user (user_id, purpose, used),
  CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS throttle (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  k CHAR(64) NOT NULL,
  at DATETIME NOT NULL,
  KEY k_key (k, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS services (
  id VARCHAR(8) PRIMARY KEY,
  cat ENUM('kiloan','satuan','express','special') NOT NULL,
  name VARCHAR(80) NOT NULL,
  unit ENUM('kg','pcs') NOT NULL,
  price INT UNSIGNED NOT NULL,
  hours SMALLINT UNSIGNED NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vouchers (
  code VARCHAR(20) PRIMARY KEY,
  type ENUM('pct','flat') NOT NULL,
  val INT UNSIGNED NOT NULL,
  max_disc INT UNSIGNED NOT NULL DEFAULT 0,
  min_sub INT UNSIGNED NOT NULL DEFAULT 0,
  label VARCHAR(160) NOT NULL,
  once_per_user TINYINT(1) NOT NULL DEFAULT 0,
  valid_until DATE NULL,
  active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoice_seq (
  day DATE PRIMARY KEY,
  n INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice VARCHAR(24) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  method ENUM('pickup','dropoff') NOT NULL,
  slot_date DATE NOT NULL,
  slot_time VARCHAR(20) NOT NULL,
  addr TEXT NOT NULL,
  lat DECIMAL(10,7) NULL,
  lng DECIMAL(10,7) NULL,
  aroma VARCHAR(40) NOT NULL,
  handling VARCHAR(20) NOT NULL,
  note VARCHAR(300) NOT NULL DEFAULT '',
  voucher VARCHAR(20) NULL,
  status TINYINT UNSIGNED NOT NULL DEFAULT 0,
  picked TINYINT(1) NOT NULL DEFAULT 0,
  final_set TINYINT(1) NOT NULL DEFAULT 0,
  bags TINYINT UNSIGNED NOT NULL DEFAULT 0,
  uniq_code SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  cancelled_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_invoice (invoice),
  KEY k_user (user_id),
  KEY k_slot (slot_date, slot_time, status),
  CONSTRAINT fk_ord_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  service_id VARCHAR(8) NOT NULL,
  name VARCHAR(80) NOT NULL,
  unit ENUM('kg','pcs') NOT NULL,
  price INT UNSIGNED NOT NULL,
  qty_est DECIMAL(6,1) NOT NULL,
  qty_final DECIMAL(6,1) NULL,
  KEY k_order (order_id),
  CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  status TINYINT UNSIGNED NOT NULL,
  text VARCHAR(255) NOT NULL,
  user_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  KEY k_order (order_id),
  CONSTRAINT fk_log_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS receipts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  stage ENUM('draft','final','lunas') NOT NULL,
  items_json MEDIUMTEXT NOT NULL,
  totals_json TEXT NOT NULL,
  pay_label VARCHAR(60) NOT NULL,
  created_at DATETIME NOT NULL,
  KEY k_order (order_id),
  CONSTRAINT fk_rc_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  method ENUM('qris','ewallet','va','cod') NOT NULL,
  channel VARCHAR(20) NOT NULL DEFAULT '',
  amount INT UNSIGNED NOT NULL,
  ref VARCHAR(64) NOT NULL,
  gateway_id VARCHAR(80) NULL,
  status ENUM('pending','paid','expired','failed','cancelled') NOT NULL DEFAULT 'pending',
  va_number VARCHAR(40) NULL,
  qr_string TEXT NULL,
  checkout_url TEXT NULL,
  expires_at DATETIME NULL,
  paid_at DATETIME NULL,
  raw TEXT NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_ref (ref),
  KEY k_order (order_id, status),
  CONSTRAINT fk_pay_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS uploads (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('proof','review') NOT NULL,
  order_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  filename VARCHAR(64) NOT NULL,
  mime VARCHAR(30) NOT NULL,
  created_at DATETIME NOT NULL,
  KEY k_order (order_id, kind),
  CONSTRAINT fk_up_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(500) NOT NULL DEFAULT '',
  photo_id INT UNSIGNED NULL,
  pts INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_order (order_id),
  CONSTRAINT fk_rv_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS point_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  delta INT NOT NULL,
  reason VARCHAR(80) NOT NULL,
  order_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  KEY k_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS voucher_uses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  order_id INT UNSIGNED NOT NULL,
  KEY k_use (code, user_id),
  KEY k_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS outbox (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  channel ENUM('whatsapp','email') NOT NULL,
  target VARCHAR(120) NOT NULL,
  subject VARCHAR(160) NOT NULL DEFAULT '',
  body TEXT NOT NULL,
  status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
  tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
  error VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  sent_at DATETIME NULL,
  KEY k_status (status, tries)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO services (id,cat,name,unit,price,hours) VALUES
('k1','kiloan','Cuci Kering Lipat','kg',7000,48),
('k2','kiloan','Cuci Setrika','kg',9000,48),
('s1','satuan','Jas','pcs',35000,72),
('s2','satuan','Gaun','pcs',30000,72),
('s3','satuan','Jaket','pcs',20000,48),
('s4','satuan','Bedcover','pcs',40000,72),
('s5','satuan','Selimut','pcs',25000,72),
('e1','express','Express 3 Jam','kg',20000,3),
('e2','express','Express 6 Jam','kg',15000,6),
('e3','express','Express 1 Hari','kg',12000,24),
('x1','special','Cuci Sepatu','pcs',35000,72),
('x2','special','Cuci Tas','pcs',45000,96),
('x3','special','Cuci Helm','pcs',25000,48);

INSERT IGNORE INTO vouchers (code,type,val,max_disc,min_sub,label,once_per_user) VALUES
('GENZ10','pct',10,15000,30000,'Diskon 10% pesanan pertama (maks. Rp15.000, min. Rp30.000)',1),
('HEMAT5K','flat',5000,0,20000,'Potongan Rp5.000 (min. Rp20.000)',0);
