# Laundry Gen Z — versi PHP + MySQL

PHP native (tanpa framework) + MySQL (PDO) + satu file frontend `index.html`.
Sudah termasuk: OTP via WhatsApp/email, login dengan password ter-hash, peta Leaflet, QR sungguhan,
pembayaran lewat Xendit (QRIS, e-wallet, virtual account) + COD, struk 3 tahap, tracking publik lewat QR,
panel Kasir/Kurir/Admin dengan akun dan peran sungguhan.

## 1. Pasang di XAMPP (laptop)

1. Salin folder ini ke `C:\xampp\htdocs\laundry-gen-z\`. Nyalakan **Apache** dan **MySQL** di XAMPP.
2. Salin `config.sample.php` menjadi `config.php`. Isi minimal: `app_key` (string acak panjang), `db_user`, `db_pass`.
   Bawaan XAMPP: user `root`, password kosong.
3. Buka `http://localhost/laundry-gen-z/install.php`. Halaman ini membuat database, tabel, data awal layanan,
   dan akun **admin** pertama. Setelah selesai, **hapus `install.php`**.
4. Buka `http://localhost/laundry-gen-z/index.html`, masuk sebagai admin, lalu tambah akun Kasir dan Kurir di tab **Staf**.
5. Uji alur pelanggan: daftar akun baru. Selama `app_env = 'dev'`, kode OTP tampil di layar
   dan semua pesan WA ditulis ke `storage/outbox.log`.

6. Buka `http://localhost/laundry-gen-z/cek.php`. Halaman ini memeriksa PHP, ekstensi, database, folder, dan koneksi keluar,
   lalu menunjukkan apa yang masih perlu diperbaiki (tanda ✘). Hapus `cek.php` saat live.

Syarat: PHP 8.0+ dengan ekstensi `pdo_mysql`, `curl`, `mbstring`, `fileinfo` (semua aktif di XAMPP standar).
Jika cURL gagal dengan error SSL di Windows, set `curl.cainfo` di `php.ini` ke file `cacert.pem`.

## 2. Aktifkan integrasi sungguhan

### WhatsApp (OTP dan notifikasi) — Fonnte
1. Daftar di fonnte.com, sambungkan satu nomor WhatsApp, salin token perangkat.
2. Di `config.php`: `'wa_driver' => 'fonnte'`, `'fonnte_token' => '...'`.
3. Pesan yang gagal terkirim dicoba ulang oleh `php cron/outbox.php` (jadwalkan tiap 5 menit).

### Pembayaran — Xendit
1. Buat akun Xendit, ambil **Secret API key** mode test, dan **Verification Token** (Settings > Developers > Callbacks).
2. Di `config.php`: `'pay_driver' => 'xendit'`, `'xendit_secret'`, `'xendit_callback_token'`.
3. Di Dashboard Xendit > Settings > Callbacks, isi URL `https://DOMAIN-KAMU/laundry-gen-z/api/webhook.php`
   untuk callback **E-Wallet**, **QR Code**, dan **Virtual Account**. Webhook butuh alamat publik HTTPS;
   di laptop pakai ngrok (`ngrok http 80`) dan isi `base_url` di config dengan alamat ngrok + `/laundry-gen-z`.
4. Uji di mode test, lalu ganti ke key production saat live.

Catatan penting:
- **GoPay** tidak tersedia sebagai channel e-wallet langsung di Xendit. Pelanggan GoPay membayar lewat **QRIS**
  (semua e-wallet bisa memindai QRIS). Channel e-wallet yang tersedia di aplikasi ini: OVO, DANA, ShopeePay, LinkAja.
- Kode memakai endpoint per-channel Xendit (`/qr_codes`, `/ewallets/charges`, `/callback_virtual_accounts`).
  Xendit sedang mengarahkan integrator ke Payments API v3. **Cocokkan payload di `gateway_create()`
  (src/domain.php) dengan dokumentasi Xendit terbaru dan uji di mode test** sebelum live.
- Nominal di webhook dicocokkan dengan nominal pembayaran di database; yang tidak cocok diabaikan dan dicatat di error log.
- `pay_driver = 'mock'` tidak memakai uang: tombol "Simulasikan Pembayaran Berhasil" muncul hanya bila `app_env = 'dev'`.

### Peta dan QR
- Peta: Leaflet + OpenStreetMap, tanpa API key. Tombol "Isi alamat dari pin" memakai Nominatim (batas pemakaian wajar;
  untuk trafik besar pakai penyedia tile/geocoding berbayar atau Google Maps).
- QR: library `qrcode-generator` dari CDN. Untuk produksi, simpan file library di server sendiri agar tidak bergantung CDN.

### Email (opsional)
Secara bawaan `mail_enabled = false`: OTP dan struk hanya lewat WhatsApp, dan opsi "kirim lewat email" disembunyikan.
Aktifkan hanya setelah server mail/SMTP siap (`mail()` bawaan XAMPP dan banyak hosting murah tidak mengirim apa pun).

### Bila hosting memakai Nginx (bukan Apache)
File `.htaccess` diabaikan Nginx, jadi folder rahasia harus diblokir manual di konfigurasi server:
```
location ~ ^/laundry-gen-z/(src|database|cron|storage)/ { deny all; }
location ~ ^/laundry-gen-z/(config\.php|config\.sample\.php|README\.md)$ { deny all; }
```

## 3. Struktur

```
index.html         frontend (pelanggan, kasir, kurir, admin)
track.php          halaman tracking publik (tujuan QR di struk)
file.php           menyajikan foto bukti/ulasan, hanya untuk pemilik pesanan dan staf
install.php        instalasi sekali jalan (hapus setelah dipakai)
cek.php            pemeriksa pengaturan (hanya aktif saat app_env = dev; hapus saat live)
api/index.php      semua endpoint JSON (?r=orders/create, dst.)
api/webhook.php    callback Xendit
src/core.php       config, DB, sesi, CSRF, OTP, notifikasi
src/domain.php     pesanan, struk, pembayaran, rute API
database/schema.sql
cron/outbox.php    kirim ulang pesan gagal, tandai pembayaran kedaluwarsa
storage/           foto unggahan dan log (diblokir dari akses web lewat .htaccess)
```

## 4. Keamanan yang sudah ada
- Password di-hash (`password_hash`), sesi cookie HttpOnly + SameSite, token CSRF di setiap POST.
- Semua query memakai prepared statement. Output HTML di-escape.
- OTP disimpan sebagai HMAC, berlaku 5 menit, maksimal 5 percobaan, ada pembatasan kirim ulang dan percobaan login.
- Harga, total, voucher, dan status dihitung ulang di server; klien tidak bisa menentukan harga.
- Unggahan foto divalidasi tipe dan ukuran (maks. 3 MB), disimpan di luar akses langsung, disajikan lewat `file.php`.
- Hak akses per peran dicek di server (pelanggan, kasir, kurir, admin).

## 5. Checklist sebelum live
- [ ] `app_env = 'prod'` (menutup tampilan OTP di layar dan tombol simulasi bayar). Hapus `install.php` dan `cek.php`.
- [ ] `app_key` acak panjang; `install.php` dihapus; password admin kuat.
- [ ] HTTPS aktif (cookie otomatis memakai flag Secure bila HTTPS).
- [ ] Ganti nama, alamat, dan nomor outlet di `config.php`; cek harga di tab **Harga**.
- [ ] Webhook Xendit terdaftar dan teruji di mode test; ganti ke key production.
- [ ] Cron `cron/outbox.php` berjalan; backup database terjadwal.
- [ ] Email (opsional): `mail_enabled = true` hanya setelah SMTP/server mail siap.

## 6. Yang belum ada
- Pengembalian dana, penghapusan staf, dan pengelolaan voucher dari UI (ubah langsung di tabel `vouchers`).
- Refresh status memakai polling tiap 15-20 detik, bukan WebSocket.
- Belum ada tes otomatis untuk sisi PHP, dan kode PHP belum pernah dijalankan oleh pembuatnya: uji di XAMPP lebih dulu.
