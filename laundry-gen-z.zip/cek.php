<?php
declare(strict_types=1);
// Pemeriksa pengaturan. Buka: http://localhost/laundry-gen-z/cek.php  (hanya aktif bila app_env = 'dev'). HAPUS saat live.
require __DIR__ . '/src/core.php';
if (cfg('app_env', 'prod') !== 'dev') {
    http_response_code(403);
    exit('Dinonaktifkan. Set app_env = dev untuk memakai halaman ini.');
}
$rows = [];
$add = function (string $name, bool $ok, string $note = '', bool $warn = false) use (&$rows) {
    $rows[] = [$name, $warn ? 'warn' : ($ok ? 'ok' : 'bad'), $note];
};
$add('PHP 8.0 atau lebih baru', version_compare(PHP_VERSION, '8.0.0', '>='), 'Versi sekarang: ' . PHP_VERSION);
foreach (['pdo_mysql', 'curl', 'mbstring', 'fileinfo', 'json', 'openssl'] as $e) {
    $add('Ekstensi ' . $e, extension_loaded($e), extension_loaded($e) ? '' : 'Aktifkan di php.ini lalu restart Apache.');
}
$key = (string)cfg('app_key', '');
$add('app_key sudah diganti', $key !== '' && $key !== 'GANTI-DENGAN-STRING-ACAK-PANJANG' && strlen($key) >= 16, 'Isi dengan string acak minimal 16 karakter.');
$dbok = false;
try {
    db();
    $dbok = true;
    $add('Koneksi database', true, 'Terhubung ke ' . cfg('db_name'));
} catch (Throwable $e) {
    $add('Koneksi database', false, $e->getMessage() . ' (cek db_* di config.php dan pastikan MySQL menyala; jalankan install.php.)');
}
if ($dbok) {
    try {
        $t = (int)val('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()');
        $add('Tabel database lengkap', $t >= 15, $t . ' tabel ditemukan. Jalankan install.php bila kurang.');
        $add('Daftar layanan terisi', (int)val('SELECT COUNT(*) FROM services') > 0, 'Tabel services kosong? Jalankan install.php.');
        $add('Akun admin ada', (int)val('SELECT COUNT(*) FROM users WHERE role="admin"') > 0, 'Buat lewat install.php.');
    } catch (Throwable $e) {
        $add('Tabel database', false, $e->getMessage());
    }
}
$add('Folder storage/uploads bisa ditulis', is_dir(__DIR__ . '/storage/uploads') && is_writable(__DIR__ . '/storage/uploads'), 'Beri izin tulis pada folder ini.');
$add('Folder storage bisa ditulis (log)', is_writable(__DIR__ . '/storage'), '');
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$add('HTTPS aktif', $https, 'Wajib saat live. Di localhost boleh HTTP.', !$https);
$add('base_url terdeteksi', true, base_url());
$curl = function (string $url) {
    if (!function_exists('curl_init')) {
        return 'ekstensi curl tidak aktif';
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_NOBODY => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5]);
    $r = curl_exec($ch);
    $e = curl_error($ch);
    curl_close($ch);
    return $r === false ? $e : '';
};
$err = $curl('https://api.fonnte.com');
$add('Koneksi HTTPS keluar (ke Fonnte)', $err === '', $err !== '' ? $err . ' — di Windows/XAMPP, set curl.cainfo di php.ini ke file cacert.pem.' : '');
$err = $curl('https://api.xendit.co');
$add('Koneksi HTTPS keluar (ke Xendit)', $err === '', $err);
$wa = cfg('wa_driver', 'log');
$add('WhatsApp: ' . $wa, $wa !== 'fonnte' || (string)cfg('fonnte_token', '') !== '', $wa === 'log' ? 'Mode log: pesan hanya ditulis ke storage/outbox.log (aman untuk uji).' : 'Isi fonnte_token.', $wa === 'log');
$pd = cfg('pay_driver', 'mock');
$add('Pembayaran: ' . $pd, $pd !== 'xendit' || ((string)cfg('xendit_secret', '') !== '' && (string)cfg('xendit_callback_token', '') !== ''), $pd === 'mock' ? 'Mode mock: tidak ada uang yang bergerak (aman untuk uji).' : 'Isi xendit_secret dan xendit_callback_token.', $pd === 'mock');
$add('app_env', false, 'Sekarang "dev". Ganti ke "prod" saat live, lalu hapus cek.php dan install.php.', true);
$bad = count(array_filter($rows, fn($r) => $r[1] === 'bad'));
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cek pengaturan</title><style>body{font-family:system-ui,sans-serif;max-width:640px;margin:0 auto;padding:20px 16px;color:#1E1B1F}
li{list-style:none;padding:10px 12px;border:1.5px solid #E2E1E7;border-radius:12px;margin:8px 0}ul{padding:0}
.ok b::before{content:"✔ ";color:#12805A}.bad b::before{content:"✘ ";color:#C62A2F}.warn b::before{content:"! ";color:#9A5B00}
small{display:block;color:#625E68;margin-top:2px}.bad{border-color:#C62A2F}</style></head><body>
<h1>Cek pengaturan Laundry Gen Z</h1>
<p><b><?= $bad === 0 ? 'Semua pemeriksaan wajib lulus.' : $bad . ' hal perlu diperbaiki (tanda ✘).' ?></b></p>
<ul><?php foreach ($rows as [$n, $s, $note]): ?><li class="<?= $s ?>"><b><?= $h($n) ?></b><?php if ($note !== ''): ?><small><?= $h($note) ?></small><?php endif; ?></li><?php endforeach; ?></ul>
</body></html>
