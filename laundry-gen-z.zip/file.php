<?php
declare(strict_types=1);
// Menyajikan foto bukti serah terima dan foto ulasan, hanya untuk pemilik pesanan atau staf.
require __DIR__ . '/src/core.php';
$u = me();
$up = $u ? row('SELECT up.*, o.user_id AS owner FROM uploads up JOIN orders o ON o.id=up.order_id WHERE up.id=?', [(int)($_GET['id'] ?? 0)]) : null;
if (!$u || !$up || ($u['role'] === 'customer' && (int)$up['owner'] !== (int)$u['id'])) {
    http_response_code(404);
    exit('Tidak ditemukan');
}
$path = __DIR__ . '/storage/uploads/' . basename((string)$up['filename']);
if (!is_file($path)) {
    http_response_code(404);
    exit('Tidak ditemukan');
}
header('Content-Type: ' . $up['mime']);
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');
readfile($path);
