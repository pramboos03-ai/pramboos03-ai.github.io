<?php
declare(strict_types=1);
// Callback dari Xendit. Daftarkan URL ini di Dashboard Xendit > Settings > Callbacks
// (E-Wallet, QR Code, dan Virtual Account), lalu salin Verification Token ke config.php.
require __DIR__ . '/../src/core.php';
require __DIR__ . '/../src/domain.php';

header('Content-Type: application/json; charset=utf-8');
$expect = (string)cfg('xendit_callback_token', '');
$got = (string)($_SERVER['HTTP_X_CALLBACK_TOKEN'] ?? '');
if ($expect === '' || !hash_equals($expect, $got)) {
    http_response_code(401);
    echo '{"error":"unauthorized"}';
    exit;
}
$b = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($b)) {
    http_response_code(400);
    echo '{"error":"bad_request"}';
    exit;
}
try {
    $d = (isset($b['data']) && is_array($b['data'])) ? $b['data'] : $b;
    $ref = '';
    foreach ([$d['reference_id'] ?? null, $b['reference_id'] ?? null, $d['external_id'] ?? null, $b['external_id'] ?? null, $b['qr_code']['external_id'] ?? null] as $c) {
        if (is_string($c) && $c !== '') {
            $ref = $c;
            break;
        }
    }
    $st = strtoupper((string)($d['status'] ?? $b['status'] ?? ''));
    $isVaPaid = isset($b['payment_id']) && isset($b['account_number']);
    $paid = $isVaPaid || in_array($st, ['SUCCEEDED', 'COMPLETED', 'PAID', 'SETTLED'], true);
    $amount = isset($d['amount']) ? (int)round((float)$d['amount']) : (isset($d['charge_amount']) ? (int)round((float)$d['charge_amount']) : null);
    $result = 'ignored';
    if ($ref !== '') {
        q('UPDATE payments SET raw=? WHERE ref=?', [mb_substr((string)json_encode($b), 0, 4000), $ref]);
        if ($paid) {
            $result = pay_confirm_by_ref($ref, $amount);
        } elseif (in_array($st, ['FAILED', 'VOIDED'], true)) {
            q('UPDATE payments SET status="failed" WHERE ref=? AND status="pending"', [$ref]);
            $result = 'failed';
        } elseif (in_array($st, ['EXPIRED', 'INACTIVE'], true)) {
            q('UPDATE payments SET status="expired" WHERE ref=? AND status="pending"', [$ref]);
            $result = 'expired';
        }
    }
    reply_raw((string)json_encode(['ok' => true, 'result' => $result]));
} catch (Throwable $e) {
    error_log('LGZ webhook: ' . $e->getMessage());
    http_response_code(500);
    echo '{"error":"server"}';
}
