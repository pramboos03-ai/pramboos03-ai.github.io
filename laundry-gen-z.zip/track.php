<?php
declare(strict_types=1);
// Halaman pelacakan publik (dibuka dari QR di struk). Tidak menampilkan data pribadi lengkap.
require __DIR__ . '/src/core.php';
require __DIR__ . '/src/domain.php';
$no = strtoupper(preg_replace('/[^A-Za-z0-9\-]/', '', (string)($_GET['no'] ?? '')) ?? '');
$o = $no !== '' ? row('SELECT o.*, u.name AS cname FROM orders o JOIN users u ON u.id=o.user_id WHERE o.invoice=?', [$no]) : null;
$steps = ['Menunggu Penjemputan / Drop-off', 'Tiba di Outlet & Timbang Ulang', 'Proses Cuci & Pengeringan', 'Proses Setrika & Quality Control', 'Packing & Siap Kirim / Diantar Kurir', 'Selesai'];
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$logs = [];
if ($o) {
    foreach (rows('SELECT status, text, created_at FROM order_logs WHERE order_id=? ORDER BY id', [$o['id']]) as $l) {
        $logs[(int)$l['status']] = $l;
    }
}
header('X-Robots-Tag: noindex');
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Lacak pesanan · Laundry Gen Z</title>
<style>
body{margin:0;font-family:system-ui,-apple-system,'Segoe UI',sans-serif;color:#1E1B1F;background:#fff}
header{background:#FF007F;color:#fff;padding:18px 16px}header b{font-size:20px}
main{max-width:520px;margin:0 auto;padding:20px 16px 48px}
h1{font-size:26px;margin:0 0 4px}.m{color:#625E68}
ol{list-style:none;padding:0;margin:22px 0 0}li{position:relative;padding:0 0 22px 44px;min-height:46px}
li::before{content:'';position:absolute;left:13px;top:28px;bottom:-2px;width:2px;background:#E2E1E7}li:last-child::before{display:none}
li.d::before{background:#FF007F}.n{position:absolute;left:0;top:0;width:28px;height:28px;border-radius:50%;border:2px solid #bdbbc4;background:#fff}
li.d .n{background:#D80067;border-color:#D80067}li.c .n{border-color:#D80067;box-shadow:0 0 0 5px #FFE3F1}
li:not(.d):not(.c) b{color:#625E68;font-weight:600}.s{display:block;font-size:13.5px;color:#625E68}
.box{border:1.5px dashed #bdbbc4;border-radius:14px;padding:24px;text-align:center}
</style></head><body>
<header><b>Laundry Gen Z</b></header>
<main>
<?php if (!$o): ?>
  <div class="box"><h1>Pesanan tidak ditemukan</h1><p class="m">Periksa lagi nomor nota atau pindai ulang QR di struk.</p></div>
<?php else:
    $st = (int)$o['status'];
    $canc = (bool)$o['cancelled_at'];
    $parts = preg_split('/\s+/', trim((string)$o['cname'])) ?: [''];
    $who = mb_substr($parts[0], 0, 1) . str_repeat('*', 4); ?>
  <h1><?= $h($o['invoice']) ?></h1>
  <p class="m">Atas nama <?= $h($who) ?> · dibuat <?= $h(date('d M Y H:i', strtotime((string)$o['created_at']))) ?></p>
  <?php if ($canc): ?><p><b>Pesanan dibatalkan.</b></p><?php endif; ?>
  <ol>
  <?php foreach ($steps as $i => $s):
      $done = $i < $st || $st === 5;
      $cur = !$done && $i === $st && !$canc; ?>
    <li class="<?= $done ? 'd' : ($cur ? 'c' : '') ?>"><span class="n"></span><b><?= $h($s) ?></b>
      <?php if (isset($logs[$i])): ?><span class="s"><?= $h(date('d M H:i', strtotime((string)$logs[$i]['created_at']))) ?> · <?= $h($logs[$i]['text']) ?></span><?php endif; ?>
    </li>
  <?php endforeach; ?>
  </ol>
  <p class="m">Untuk melihat struk lengkap dan membayar, masuk ke akunmu di aplikasi.</p>
<?php endif; ?>
</main></body></html>
