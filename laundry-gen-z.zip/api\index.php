<?php
declare(strict_types=1);
require __DIR__ . '/../src/core.php';
require __DIR__ . '/../src/domain.php';

$routes = [
    'state'                => 'r_state',
    'auth/register'        => 'r_register',
    'auth/verify'          => 'r_verify',
    'auth/login'           => 'r_login',
    'auth/otp-login'       => 'r_otp_login',
    'auth/forgot'          => 'r_forgot',
    'auth/resend'          => 'r_resend',
    'auth/reset'           => 'r_reset',
    'auth/logout'          => 'r_logout',
    'profile/save'         => 'r_profile_save',
    'orders/create'        => 'r_orders_create',
    'orders/cancel'        => 'r_orders_cancel',
    'orders/weigh'         => 'r_orders_weigh',
    'orders/advance'       => 'r_orders_advance',
    'orders/picked'        => 'r_orders_picked',
    'orders/deliver'       => 'r_orders_deliver',
    'orders/review'        => 'r_orders_review',
    'orders/send-receipt'  => 'r_orders_send_receipt',
    'pay/start'            => 'r_pay_start',
    'pay/cancel'           => 'r_pay_cancel',
    'pay/simulate'         => 'r_pay_simulate',
    'admin/staff'          => 'r_admin_staff',
    'admin/service'        => 'r_admin_service',
];

try {
    start_session();
    $r = (string)($_GET['r'] ?? '');
    if (!isset($routes[$r])) {
        fail('Endpoint tidak ditemukan.', 404);
    }
    $isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    if ($r === 'state') {
        if ($isPost) {
            fail('Metode tidak diizinkan.', 405);
        }
    } else {
        if (!$isPost) {
            fail('Metode tidak diizinkan.', 405);
        }
        csrf_check();
    }
    out(($routes[$r])());
} catch (ApiError $e) {
    out(['error' => $e->getMessage(), 'field' => $e->field], $e->getCode() ?: 400);
} catch (Throwable $e) {
    error_log('LGZ: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    out(['error' => cfg('app_env', 'prod') === 'dev' ? $e->getMessage() : 'Terjadi kesalahan di server.'], 500);
}
