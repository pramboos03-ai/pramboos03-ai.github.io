<?php
declare(strict_types=1);
// Jalankan tiap 5 menit lewat cron / Task Scheduler:  php cron/outbox.php
// Mengirim ulang pesan WA/email yang gagal, dan menandai pembayaran yang kedaluwarsa.
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only');
}
require __DIR__ . '/../src/core.php';
foreach (rows('SELECT id FROM outbox WHERE status="pending" AND tries<5 ORDER BY id LIMIT 50') as $m) {
    send_outbox((int)$m['id']);
}
q('UPDATE payments SET status="expired" WHERE status="pending" AND expires_at IS NOT NULL AND expires_at<?', [now()]);
q('DELETE FROM throttle WHERE at<?', [date('Y-m-d H:i:s', time() - 86400)]);
echo "OK\n";
